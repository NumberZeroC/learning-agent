#!/usr/bin/env python3
"""
验证 Agent 系统提示词和工具配置
"""

import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

from agents.config_manager import get_config_manager
from agents.agent_tools import get_tool_registry

def test_agent_prompts():
    """测试 Agent 系统提示词"""
    print("="*60)
    print("📝 Agent 系统提示词验证")
    print("="*60)
    
    manager = get_config_manager()
    agents = manager.get_config("agents", {})
    
    for agent_name, config in agents.items():
        if not config.get('enabled', False):
            continue
        
        print(f"\n🤖 {agent_name}")
        print(f"   角色：{config.get('role', 'N/A')}")
        print(f"   层级：{config.get('layer', 'N/A')}")
        print(f"   模型：{config.get('model', 'N/A')}")
        
        # 检查系统提示词
        system_prompt = config.get('system_prompt', '')
        if system_prompt:
            lines = system_prompt.strip().split('\n')
            print(f"   提示词长度：{len(lines)} 行")
            
            # 提取关键部分
            if '## 你的身份' in system_prompt:
                print(f"   ✅ 包含身份说明")
            if '## 你的职责' in system_prompt:
                print(f"   ✅ 包含职责说明")
            if '## 你的专业领域' in system_prompt:
                print(f"   ✅ 包含专业领域")
            if '## 输出要求' in system_prompt or '## 输出格式' in system_prompt:
                print(f"   ✅ 包含输出要求")
        else:
            print(f"   ❌ 缺少系统提示词")
        
        # 检查工具配置
        tools = config.get('tools', [])
        if tools:
            print(f"   工具：{', '.join(tools)}")
        else:
            print(f"   工具：无")
    
    return True


def test_tools():
    """测试工具功能"""
    print("\n" + "="*60)
    print("🔧 工具功能验证")
    print("="*60)
    
    manager = get_config_manager()
    tools_config = manager.get_config("tools", {})
    
    registry = get_tool_registry(tools_config)
    
    # 列出所有可用工具
    print(f"\n📦 可用工具:")
    for name, tool in registry.tools.items():
        print(f"   ✅ {name}")
    
    # 测试计算器
    print(f"\n🧮 测试计算器:")
    if "calculator" in registry.tools:
        calc = registry.get_tool("calculator")
        result = calc.calculate("2 + 3 * 4")
        if result.get("success"):
            print(f"   ✅ 2 + 3 * 4 = {result.get('result')}")
        else:
            print(f"   ❌ 计算失败：{result.get('error')}")
    else:
        print(f"   ⚠️ 计算器工具未启用")
    
    # 测试文件操作
    print(f"\n📁 测试文件操作:")
    if "file_operations" in registry.tools:
        file_ops = registry.get_tool("file_operations")
        
        # 写入测试文件
        test_content = "# Agent 工具测试\n\n这是一个测试文件。"
        write_result = file_ops.write_file("test_tool.md", test_content)
        
        if write_result.get("success"):
            print(f"   ✅ 写入文件成功")
            
            # 读取测试文件
            read_result = file_ops.read_file("test_tool.md")
            if read_result.get("success"):
                print(f"   ✅ 读取文件成功 ({read_result.get('size')} 字节)")
            else:
                print(f"   ❌ 读取失败：{read_result.get('error')}")
        else:
            print(f"   ❌ 写入失败：{write_result.get('error')}")
    else:
        print(f"   ⚠️ 文件操作工具未启用")
    
    # 获取所有工具定义
    print(f"\n📋 工具定义:")
    all_tools = registry.get_all_tools()
    print(f"   共 {len(all_tools)} 个工具函数")
    
    for tool_def in all_tools[:5]:  # 只显示前 5 个
        func = tool_def.get("function", {})
        print(f"   - {func.get('name', 'unknown')}: {func.get('description', '')[:50]}...")
    
    return True


def main():
    """主函数"""
    print("\n" + "="*60)
    print("🤖 Learning Agent - Agent 配置验证")
    print("="*60)
    
    # 测试 1: Agent 提示词
    prompts_ok = test_agent_prompts()
    
    # 测试 2: 工具功能
    tools_ok = test_tools()
    
    # 总结
    print("\n" + "="*60)
    print("📊 验证总结")
    print("="*60)
    print(f"   Agent 提示词：{'✅ 通过' if prompts_ok else '❌ 失败'}")
    print(f"   工具功能：{'✅ 通过' if tools_ok else '❌ 失败'}")
    
    if prompts_ok and tools_ok:
        print(f"\n🎉 所有验证通过！系统已就绪")
        return 0
    else:
        print(f"\n⚠️ 部分验证失败，请检查配置")
        return 1


if __name__ == "__main__":
    sys.exit(main())
