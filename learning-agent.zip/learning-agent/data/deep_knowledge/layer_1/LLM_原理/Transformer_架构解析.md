# Transformer 架构解析

**生成时间：** 2026-03-29T23:30:12.642004

**类型：** practice

---

## 1. 实践目标

本实践旨在帮助学习者深入理解 Transformer 架构的核心机制，而非仅仅调用现成库。通过从零构建简化版 Transformer，学员将掌握自注意力机制（Self-Attention）、位置编码（Positional Encoding）及残差连接等关键概念。最终目标是能够独立编写可运行的 Transformer 代码，理解大语言模型（LLM）的底层原理，为后续微调或架构创新打下坚实基础。

## 2. 背景介绍

2017 年，Google 提出"Attention is All You Need"，Transformer 架构横空出世，彻底改变了 NLP 领域。它摒弃了传统的 RNN 和 CNN 结构，凭借并行计算能力和强大的长距离依赖捕捉能力，成为当今 LLM（如 GPT、BERT）的基石。在实际场景中，Transformer 广泛应用于机器翻译、文本生成、情感分析等领域。理解其内部构造，是进入 AI 核心领域的必经之路。

## 3. 技术选型

-   **Python**: 主流 AI 开发语言，生态丰富。
-   **PyTorch**: 选择因其动态图机制，调试友好，代码直观，适合教学与研究。
-   **NumPy**: 用于基础数值计算辅助。
-   **Matplotlib**: 用于可视化注意力权重和损失曲线。

**选型理由**：PyTorch 社区活跃，文档完善，能够清晰地展示张量操作过程，非常适合用于解析复杂的模型架构。

## 4. 架构设计

Transformer 采用 Encoder-Decoder 结构，本实践聚焦于 Encoder 部分的核心模块。主要包含多头注意力机制、前馈神经网络、层归一化和残差连接。

```mermaid
graph TD
    Input[输入序列] --> Embedding[词嵌入]
    Embedding --> PE[位置编码]
    PE --> MHA[多头自注意力]
    MHA --> Add1[残差连接]
    Add1 --> Norm1[层归一化]
    Norm1 --> FFN[前馈神经网络]
    FFN --> Add2[残差连接]
    Add2 --> Norm2[层归一化]
    Norm2 --> Output[输出特征]
```

**设计说明**：数据流经过嵌入层后，叠加位置信息以保留顺序特征。随后进入 N 个堆叠的 Encoder 层，每层通过多头注意力捕捉全局依赖，再经 FFN 进行非线性变换，残差连接防止梯度消失。

## 5. 实现步骤

1.  **环境准备**：安装 PyTorch 及相关依赖库。
2.  **数据模拟**：构造简单的输入序列和张量掩码（Mask）。
3.  **嵌入层定义**：实现词向量嵌入（Embedding）。
4.  **位置编码**：编写正弦/余弦位置编码函数。
5.  **缩放点积注意力**：实现核心的 Scaled Dot-Product Attention。
6.  **多头注意力**：将注意力机制扩展为多頭并行计算。
7.  **前馈网络**：构建两层全连接网络带 ReLU 激活。
8.  **编码器层**：整合注意力、FFN、残差和归一化。
9.  **模型组装**：堆叠多个编码器层形成完整模型。
10. **前向传播测试**：输入 dummy 数据验证维度流转是否正确。

## 6. 核心代码

以下是基于 PyTorch 的核心实现，包含多头注意力和 Encoder 层。

```python
import torch
import torch.nn as nn
import math

# 1. 缩放点积注意力
class ScaledDotProductAttention(nn.Module):
    def __init__(self, dropout=0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        self.scale = 1 / math.sqrt(512)  # 假设 d_k=512

    def forward(self, q, k, v, mask=None):
        # 计算注意力分数：Q * K^T
        scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)  # 掩码填充负无穷
        attn = self.dropout(torch.softmax(scores, dim=-1))
        return torch.matmul(attn, v)  # 加权求和

# 2. 多头注意力机制
class MultiHeadAttention(nn.Module):
    def __init__(self, d_model=512, n_heads=8):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        self.W_q = nn.Linear(d_model, d_model)
        self.W_k = nn.Linear(d_model, d_model)
        self.W_v = nn.Linear(d_model, d_model)
        self.W_o = nn.Linear(d_model, d_model)
        self.attn = ScaledDotProductAttention()

    def forward(self, x, mask=None):
        batch_size = x.size(0)
        # 线性映射并拆分多头
        q = self.W_q(x).view(batch_size, -1, self.n_heads, self.d_k).transpose(1, 2)
        k = self.W_k(x).view(batch_size, -1, self.n_heads, self.d_k).transpose(1, 2)
        v = self.W_v(x).view(batch_size, -1, self.n_heads, self.d_k).transpose(1, 2)
        
        # 注意力计算
        out = self.attn(q, k, v, mask)
        # 合并多头
        out = out.transpose(1, 2).contiguous().view(batch_size, -1, self.d_model)
        return self.W_o(out)

# 3. 前馈神经网络
class FeedForward(nn.Module):
    def __init__(self, d_model=512, d_ff=2048):
        super().__init__()
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)
        self.relu = nn.ReLU()

    def forward(self, x):
        return self.linear2(self.relu(self.linear1(x)))

# 4. 编码器层
class EncoderLayer(nn.Module):
    def __init__(self, d_model=512, n_heads=8):
        super().__init__()
        self.mha = MultiHeadAttention(d_model, n_heads)
        self.ffn = FeedForward(d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x, mask=None):
        # 残差连接 + 归一化
        x = self.norm1(x + self.mha(x, mask))
        x = self.norm2(x + self.ffn(x))
        return x

# 测试运行
if __name__ == "__main__":
    dummy_input = torch.randn(2, 10, 512)  # Batch=2, Seq=10, Dim=512
    model = EncoderLayer()
    output = model(dummy_input)
    print(f"输入形状：{dummy_input.shape}, 输出形状：{output.shape}")
```

## 7. 测试验证

1.  **维度检查**：运行核心代码中的 `__main__` 部分，确保输入输出维度一致（如 `(2, 10, 512)`）。
2.  **损失收敛**：连接实际任务（如翻译），训练 10 个 Epoch，观察 Loss 是否呈下降趋势。
3.  **注意力可视化**：提取 `MultiHeadAttention` 中的 `attn` 权重，使用热力图展示，验证模型是否关注到了关键词语。
4.  **梯度检查**：使用 `torch.autograd.gradcheck` 确保反向传播无误。

## 8. 部署上线

1.  **模型保存**：使用 `torch.save(model.state_dict(), 'transformer.pth')` 保存权重。
2.  **格式转换**：如需高性能推理，可导出为 ONNX 格式：`torch.onnx.export`。
3.  **API 封装**：使用 FastAPI 封装推理接口，接收文本输入，返回预测结果。
4.  **注意事项**：部署时需确保预处理（分词、位置编码）与训练时完全一致；注意显存管理，设置 `batch_size` 上限。

## 9. 经验总结

1.  **缩放因子至关重要**：Self-Attention 中必须除以 $\sqrt{d_k}$，否则梯度容易消失，导致模型不收敛。
2.  **掩码机制**：在 Decoder 或Padding 处理中，Mask 的设置必须准确，否则模型会“偷看”未来信息。
3.  **学习率预热**：Transformer 对学习率敏感，建议使用 Warmup 策略，先升后降。
4.  **调试技巧**：遇到 NaN 损失时，优先检查 LayerNorm 位置和梯度裁剪（Gradient Clipping）。
5.  **最佳实践**：先在小数据集上过拟合，验证模型容量，再扩展到大数据训练。

通过本实践，学员不仅能写出代码，更能理解为何这样设计，从而具备优化和改造架构的能力。