# LangChain 框架实战

**生成时间：** 2026-03-29T23:47:35.386308

**类型：** tool

---

## 1. 工具介绍

LangChain 是一个用于开发由语言模型驱动的应用程序的开源框架。在 Agent 框架主题下，它主要解决大语言模型（LLM）“无法行动”和“缺乏记忆”的问题。原生 LLM 通常是被动的问答机器，而 LangChain 通过构建“智能体（Agent）”，赋予 LLM 自主决策能力。它允许模型根据用户指令，自主判断是否需要调用外部工具（如搜索引擎、计算器、数据库），并按顺序执行任务。简单来说，LangChain 是将 LLM 的大脑与外部世界的手脚连接起来的“神经系统”，让 AI 从“聊天机器人”进化为“任务执行者”。

## 2. 核心功能

1.  **智能体（Agents）**：这是核心引擎。它允许 LLM 选择执行哪些动作以及以什么顺序执行。基于 ReAct（Reasoning + Acting）范式，模型可以先思考再行动，处理多步骤任务。
2.  **工具（Tools）**：Agent 的手脚。LangChain 内置了数十种工具（如 Google Search、Wikipedia、Python REPL），也支持开发者自定义函数作为工具，让 Agent 能获取实时数据或执行代码。
3.  **记忆（Memory）**：让 Agent 拥有短期或长期记忆。通过 `ConversationBufferMemory` 等模块，Agent 能在多轮对话中记住上下文，避免“健忘”，实现连贯的任务处理。
4.  **链（Chains）**：将多个组件串联。虽然 Agent 是高级功能，但它底层依赖 Chains 将提示词、模型和输出解析器连接起来，形成标准化的处理流程。

## 3. 安装配置

使用前需确保 Python 版本为 3.8+。建议创建虚拟环境。

**安装依赖：**
```bash
pip install langchain langchain-openai langchain-community python-dotenv
```

**配置环境变量：**
在项目根目录创建 `.env` 文件，存入 API Key：
```bash
OPENAI_API_KEY=sk-your-api-key-here
```

**Python 加载配置：**
```python
from dotenv import load_dotenv
load_dotenv()
```

## 4. 基本用法

以下是一个最简单的 Zero-shot React Agent 示例，它能自主决定何时搜索信息。

```python
from langchain.agents import create_react_agent, AgentExecutor
from langchain_openai import ChatOpenAI
from langchain_community.tools import DuckDuckGoSearchRun
from langchain import hub

# 1. 初始化模型
llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)

# 2. 定义工具
search = DuckDuckGoSearchRun()
tools = [search]

# 3. 获取提示词模板
prompt = hub.pull("hwchase17/react")

# 4. 创建 Agent
agent = create_react_agent(llm, tools, prompt)

# 5. 执行代理
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
result = agent_executor.invoke({"input": "2024 年奥运会主办城市是哪里？"})
print(result["output"])
```
*注：`verbose=True` 可打印思考过程，便于调试。*

## 5. 高级用法

1.  **自定义工具（Custom Tools）**：
    当内置工具不满足需求时，可使用 `@tool` 装饰器将普通函数转化为 Agent 可调用的工具。需明确定义函数文档字符串（docstring），因为 Agent 依赖它来理解工具用途。
    ```python
    from langchain.tools import tool
    @tool
    def get_weather(city: str) -> str:
        """查询指定城市的天气情况"""
        return f"{city} 天气晴朗，25 度"
    ```

2.  **带记忆的 Agent（Memory in Agents）**：
    默认 Agent 是无状态的。引入 `ConversationBufferMemory` 后，Agent 可记住之前的对话内容，适用于多轮任务交互。
    ```python
    from langchain.memory import ConversationBufferMemory
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    agent_executor = AgentExecutor(agent=agent, tools=tools, memory=memory, verbose=True)
    ```

3.  **控制执行策略**：
    通过 `AgentExecutor` 参数控制行为。例如设置 `max_iterations=5` 防止死循环，或设置 `handle_parsing_errors=True` 让模型在输出格式错误时自动修正，提高鲁棒性。

## 6. 实际案例

**场景：金融研究助手**
需求：用户询问某公司股价，Agent 需先搜索最新股价，再计算投资回报。

```python
from langchain.agents import load_tools
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(temperature=0)
# 加载搜索工具和计算工具
tools = load_tools(["duckduckgo-search", "llm-math"], llm=llm)

# 初始化带工具的 Agent
agent = initialize_agent(
    tools, 
    llm, 
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, 
    verbose=True
)

# 任务：查询特斯拉股价并计算投资 100 股的总价
agent.run("查询特斯拉当前股价，并计算购买 100 股需要多少钱？")
```
**执行逻辑：**
1.  Agent 思考：需要知道股价 -> 调用搜索工具。
2.  获取结果：假设股价为 200 美元。
3.  Agent 思考：需要计算总价 -> 调用计算器工具 (200 * 100)。
4.  输出最终答案：20000 美元。

## 7. 替代方案

1.  **LlamaIndex**：
    *   **优点**：专注于数据索引和 RAG（检索增强生成），在处理私有知识库查询上比 LangChain 更高效。
    *   **缺点**：通用 Agent 编排能力略弱于 LangChain，生态组件较少。
2.  **AutoGen (Microsoft)**：
    *   **优点**：主打多 Agent 协作，支持代码执行沙箱，适合复杂编程任务。
    *   **缺点**：配置复杂，资源消耗大，适合高级开发者而非快速原型。
3.  **Haystack**：
    *   **优点**：模块化设计，生产环境稳定性高，适合构建搜索系统。
    *   **缺点**：对最新 LLM 特性支持稍慢，灵活性不如 LangChain。

## 8. 参考文档

*   **官方文档**：[https://python.langchain.com/docs/modules/agents/](https://python.langchain.com/docs/modules/agents/)
    *   最权威的 API 参考和概念解释，更新及时。
*   **GitHub 仓库**：[https://github.com/langchain-ai/langchain](https://github.com/langchain-ai/langchain)
    *   查看源码、提交 Issue 或寻找社区示例。
*   **优质教程**：LangChain 官方 YouTube 频道及 Hugging Face 社区教程。
    *   适合视觉学习者，包含大量实战演示视频。