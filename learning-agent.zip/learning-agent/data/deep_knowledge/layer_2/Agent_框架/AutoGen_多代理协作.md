# AutoGen 多代理协作

**生成时间：** 2026-03-29T23:48:46.716774

**类型：** practice

---

## 1. 实践目标

本实践旨在帮助开发者掌握微软 AutoGen 框架的核心用法，构建一个具备多代理协作能力的智能系统。通过本实践，学员将学会如何定义不同角色的 Agent（如 coder、reviewer、user proxy），配置大模型连接，并实现代理间的自动对话与任务协作。最终目标是完成一个“代码生成与自动审查”的最小可行产品（MVP），理解多代理系统如何通过对话解决复杂任务，为构建更高级的自动化工作流打下坚实基础。

## 2. 背景介绍

随着大语言模型（LLM）能力的提升，单一 Agent 在处理复杂任务时往往面临上下文限制、专业度不足及幻觉问题。实际业务场景（如软件开发、数据分析、客户服务）通常需要多个角色协作完成。例如，开发软件需要产品经理定义需求、程序员编写代码、测试员验证功能。

AutoGen 是一个开源的多代理对话框架，它允许开发者通过自然语言对话的方式编排多个 Agent。本实践模拟一个微型软件开发团队，通过多代理协作来提高任务完成的质量和效率，解决单模型难以兼顾代码生成与安全审查的痛点。

## 3. 技术选型

- **核心框架：AutoGen**
  - 选择理由：微软出品，社区活跃，支持灵活的对话模式（如顺序、群聊），原生支持代码执行，易于扩展。
- **编程语言：Python 3.8+**
  - 选择理由：AI 生态最丰富的语言，AutoGen 官方首选支持语言。
- **大模型接口：OpenAI API (或兼容接口)**
  - 选择理由：性能稳定，工具调用能力强，便于验证框架效果。
- **运行环境：Docker (可选)**
  - 选择理由：隔离代码执行环境，确保安全性，便于部署。

## 4. 架构设计

系统采用基于对话的协作架构，主要包含三个核心角色代理。

```mermaid
graph TD
    User[用户] --> Proxy[UserProxyAgent<br>执行者/人类代表]
    Proxy <--> Coder[AssistantAgent<br>代码生成者]
    Proxy <--> Reviewer[AssistantAgent<br>代码审查者]
    Coder -.-> Reviewer
    Reviewer -.-> Coder
    Proxy --> Output[最终结果]
```

**设计说明：**
1.  **UserProxyAgent**：作为入口，负责接收用户任务，并在必要时执行代码或请求人类输入。它是对话的发起者和终止者。
2.  **AssistantAgent (Coder)**：专注于编写代码，接收任务后生成 Python 脚本。
3.  **AssistantAgent (Reviewer)**：专注于审查代码，检查安全性、逻辑错误，并提供反馈。
4.  **协作流程**：用户提出需求 -> Coder 生成代码 -> Reviewer 审查 -> 若有问题反馈给 Coder 修改 -> 最终由 Proxy 执行并输出结果。

## 5. 实现步骤

1.  **环境准备**：安装 Python 3.8+，创建虚拟环境 `python -m venv venv` 并激活。
2.  **安装依赖**：使用 pip 安装 AutoGen 及相关库 `pip install pyautogen docker`。
3.  **配置 API Key**：创建 `OAI_CONFIG_LIST` 文件或直接在代码中配置 OpenAI API Key。
4.  **定义 LLM 配置**：在代码中构建 `llm_config` 字典，指定模型名称（如 gpt-3.5-turbo）和温度参数。
5.  **创建 UserProxyAgent**：实例化代理，设置 `human_input_mode` 为 "NEVER" 以实现全自动，或 "TERMINATE" 允许人工干预。
6.  **创建 Coder Agent**：实例化 AssistantAgent，系统提示词设定为“你是一个高效的 Python 程序员”。
7.  **创建 Reviewer Agent**：实例化 AssistantAgent，系统提示词设定为“你是一个严格的代码审查员，关注安全与效率”。
8.  **注册回复函数**：为 Agent 注册必要的工具调用函数（如代码执行器），确保生成的代码可运行。
9.  **发起对话**：调用 `user_proxy.initiate_chat()` 方法，传入任务描述和其他参与代理。
10. **运行与监控**：执行脚本，观察控制台输出的对话日志，确认任务是否以 "TERMINATE" 结束。

## 6. 核心代码

以下代码实现了一个简单的代码生成与审查流程。

```python
import autogen

# 1. 配置大模型连接信息
llm_config = {
    "config_list": [
        {
            "model": "gpt-3.5-turbo",
            "api_key": "YOUR_OPENAI_API_KEY",  # 请替换为真实 Key
        }
    ],
    "temperature": 0.7,
}

# 2. 创建用户代理 (执行者)
# human_input_mode="TERMINATE" 表示只在需要终止时询问人类
user_proxy = autogen.UserProxyAgent(
    name="UserProxy",
    system_message="一个执行人类命令的代理。",
    code_execution_config={"work_dir": "coding", "use_docker": False},
    human_input_mode="TERMINATE",
    max_consecutive_auto_reply=10,
)

# 3. 创建代码生成代理
coder = autogen.AssistantAgent(
    name="Coder",
    llm_config=llm_config,
    system_message="你是一个 Python 程序员。只输出代码块，确保代码可运行。",
)

# 4. 创建代码审查代理
reviewer = autogen.AssistantAgent(
    name="Reviewer",
    llm_config=llm_config,
    system_message="你是一个代码审查员。检查代码错误、安全风险，若没问题则说 APPROVED。",
)

# 5. 定义任务
task = "计算斐波那契数列的前 10 项，并保存到 result.txt 文件中。"

# 6. 启动群聊协作
# 这里简化为 UserProxy 与 Coder 直接对话，实际可加入 GroupChat
user_proxy.initiate_chat(
    coder,
    message=task,
)

# 注意：实际多代理协作通常使用 GroupChatManager 来协调 Coder 和 Reviewer
# 此处为简化演示核心交互逻辑
```

## 7. 测试验证

验证实践成果需从功能性和稳定性两方面入手：

1.  **功能测试**：输入明确的编程任务（如“计算斐波那契数列”），检查生成的 `result.txt` 文件是否存在且内容正确。
2.  **对话逻辑测试**：观察控制台日志，确认 Coder 生成了代码，且如果有错误，代理是否进行了自我修正或循环讨论。
3.  **终止条件测试**：确保对话在任务完成后能自动停止，避免无限循环消耗 Token。检查最后一条消息是否包含 "TERMINATE"。
4.  **异常测试**：输入模糊指令，观察 Agent 是否具备追问澄清的能力，而非胡乱生成代码。

## 8. 部署上线

将实践项目转化为生产服务需注意以下步骤：

1.  **容器化**：编写 `Dockerfile`，将 Python 环境、依赖库及代码打包，确保环境一致性。
2.  **安全管理**：严禁将 API Key 硬编码在代码中，使用环境变量注入。限制 Agent 的文件系统访问权限，防止恶意代码执行。
3.  **API 封装**：使用 FastAPI 或 Flask 将对话接口封装为 HTTP 服务，供前端调用。
4.  **成本监控**：接入 Token 计数逻辑，设置单次任务的最大 Token 消耗上限，防止费用失控。
5.  **日志记录**：记录所有代理间的对话历史，便于后续审计和问题排查。

## 9. 经验总结

通过本次实践，总结出以下关键经验与最佳实践：

1.  **提示词工程至关重要**：Agent 的行为高度依赖 System Message。明确的角色定义（如“你只负责写代码，不负责解释”）能显著减少无效对话。
2.  **控制循环次数**：多代理协作容易陷入“互相指责”的死循环。务必设置 `max_consecutive_auto_reply` 限制最大自动回复次数。
3.  **人类在环（Human-in-the-loop）**：对于高风险操作（如删除文件、支付），务必将 `human_input_mode` 设为 "ALWAYS" 或 "TERMINATE"，保留最终确认权。
4.  **代码执行安全**：在生产环境中，代码执行必须在沙箱（如 Docker）中进行，避免宿主机器受到威胁。
5.  **调试技巧**：AutoGen 的对话日志非常详细，调试时重点关注 `summary` 字段和最后一条消息，快速定位任务失败原因。

通过掌握 AutoGen 多代理协作，开发者能够从单一调用大模型转向构建复杂的自动化智能系统，大幅提升任务解决的鲁棒性与专业性。