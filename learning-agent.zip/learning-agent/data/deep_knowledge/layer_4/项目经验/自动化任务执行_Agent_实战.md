# 自动化任务执行 Agent 实战

**生成时间：** 2026-03-30T00:16:30.212298

**类型：** practice

---

## 1. 实践目标

本实践旨在构建一个具备自主感知、规划与执行能力的自动化任务 Agent。目标是通过大语言模型（LLM）理解自然语言指令，自动拆解复杂任务，调用预设工具（如数据库查询、API 请求、文件处理）完成闭环操作。最终实现减少人工重复劳动，提升运维与业务流程效率，确保任务执行的可追溯性与安全性，为企业级自动化场景提供可复用的技术范本。

## 2. 背景介绍

在日常运维与业务运营中，存在大量重复性高、规则明确但流程繁琐的任务，例如每日数据报表生成、系统健康检查、自动回复客户咨询等。传统自动化脚本缺乏灵活性，难以应对非结构化指令。随着 LLM 技术的发展，赋予 Agent“大脑”成为可能。本实践源于实际运维痛点，希望打造一个能听懂人话、能操作系统的智能助手，降低使用门槛，解放人力。

## 3. 技术选型

- **编程语言**: Python，生态丰富，AI 库支持最好。
- **Agent 框架**: LangChain，提供标准的 Agent 接口与工具链管理，开发效率高。
- **大模型**: OpenAI GPT-4 或 通义千问，具备强大的推理与代码生成能力。
- **任务调度**: Celery + Redis，支持异步任务队列，防止阻塞主线程。
- **数据存储**: SQLite（开发期）/ PostgreSQL（生产期），存储任务日志与执行记录。
- **容器化**: Docker，确保环境一致性，便于部署。

选择上述技术是因为它们社区活跃、文档完善，且能快速构建原型并平滑过渡到生产环境。

## 4. 架构设计

系统采用分层架构，确保模块解耦与可扩展性。

```mermaid
graph TD
    User[用户/触发器] --> API[API 网关]
    API --> AgentCore[Agent 核心引擎]
    AgentCore --> LLM[大语言模型]
    AgentCore --> Planner[任务规划器]
    Planner --> Tools[工具库]
    Tools --> DB[(数据库)]
    Tools --> External[外部 API]
    AgentCore --> Memory[记忆/日志模块]
    Memory --> Dashboard[监控看板]
```

**设计说明：**
1. **接入层**：接收 HTTP 请求或定时触发信号。
2. **核心层**：Agent 负责解析意图，Planner 拆解步骤。
3. **工具层**：封装具体执行逻辑，如 SQL 执行、邮件发送。
4. **记忆层**：记录执行轨迹，支持断点续传与审计。

## 5. 实现步骤

1.  **环境初始化**：创建 Python 虚拟环境，安装 `langchain`, `openai`, `celery` 等依赖。
2.  **配置管理**：建立 `.env` 文件，管理 API Key 与数据库连接串，确保敏感信息不硬编码。
3.  **定义工具接口**：抽象基类 `BaseTool`，规定每个工具必须具备 `name`, `description`, `run` 方法。
4.  **实现具体工具**：编写 `QueryDBTool` 查询数据，`SendEmailTool` 发送通知，确保异常捕获。
5.  **构建 Agent 核心**：初始化 LLM 实例，绑定工具列表，设置 `zero-shot-react-description` 模式。
6.  **设计记忆模块**：使用 `ConversationBufferMemory` 保存上下文，支持多轮对话修正。
7.  **任务解析逻辑**：编写 Prompt 模板，引导模型输出标准化的思考 - 行动 - 观察链条。
8.  **执行循环控制**：设置最大迭代次数（如 5 次），防止死循环，增加超时机制。
9.  **日志与审计**：记录每一步的输入输出至数据库，便于故障排查。
10. **接口封装**：使用 FastAPI 暴露 `/execute_task` 接口，接收 JSON 任务指令。

## 6. 核心代码

以下是 Agent 核心逻辑的简化实现，展示了工具绑定与执行流程。

```python
import os
from langchain.agents import initialize_agent, Tool
from langchain.llms import OpenAI
from langchain.memory import ConversationBufferMemory

# 1. 定义具体工具函数
def query_database(query: str) -> str:
    """模拟查询数据库，实际应连接 DB"""
    return f"查询结果：{query} 的数据为 100"

def send_email(content: str) -> str:
    """模拟发送邮件"""
    return f"邮件已发送：{content}"

# 2. 封装工具列表
tools = [
    Tool(name="DB_Query", func=query_database, description="用于查询业务数据"),
    Tool(name="Email_Sender", func=send_email, description="用于发送通知邮件")
]

# 3. 初始化 Agent
def run_agent_task(task_instruction: str):
    llm = OpenAI(temperature=0, openai_api_key=os.getenv("OPENAI_API_KEY"))
    memory = ConversationBufferMemory(memory_key="chat_history")
    
    # 初始化 Zero-Shot Agent
    agent = initialize_agent(
        tools, 
        llm, 
        agent="zero-shot-react-description", 
        verbose=True, 
        memory=memory
    )
    
    try:
        # 4. 执行任务
        response = agent.run(task_instruction)
        return {"status": "success", "result": response}
    except Exception as e:
        return {"status": "failed", "error": str(e)}

# 示例调用
if __name__ == "__main__":
    # 需设置环境变量 OPENAI_API_KEY
    task = "查询今日订单量并发送邮件给管理员"
    print(run_agent_task(task))
```

## 7. 测试验证

测试分为单元测试与集成测试。
1.  **工具测试**：Mock 外部依赖，验证 `query_database` 等函数在输入异常参数时是否抛出预期错误。
2.  **意图识别测试**：构造模糊指令（如“看看今天数据咋样”），验证 Agent 是否能正确映射到 `DB_Query` 工具。
3.  **压力测试**：并发发送 50 个任务请求，监测响应时间与内存占用，确保无泄漏。
4.  **人工验收**：邀请业务人员试用，收集反馈优化 Prompt 描述，确保执行结果符合业务预期。

## 8. 部署上线

1.  **容器化**：编写 `Dockerfile`，复制代码并安装依赖，设置启动命令。
2.  **安全配置**：在生产环境使用 Secrets Manager 管理 API Key，禁止明文存储。
3.  **服务编排**：使用 Docker Compose 编排 Agent 服务、Redis 队列与数据库。
4.  **监控告警**：接入 Prometheus + Grafana，监控任务失败率与 LLM Token 消耗，设置阈值告警。
5.  **灰度发布**：先对内部用户开放，观察稳定后再全量推送，保留回滚机制。

## 9. 经验总结

1.  **Prompt 工程至关重要**：工具的描述信息（Description）必须清晰准确，否则模型无法正确调用。
2.  **安全边界**：严禁 Agent 直接拥有删除数据或执行系统命令的权限，必须经过人工确认或沙箱隔离。
3.  **成本控制**：LLM 调用成本高，需设置 Token 上限，并对常用任务缓存结果。
4.  **人机协同**：自动化不是完全无人化，关键步骤应设计“人类确认”环节（Human-in-the-loop），确保可靠性。
5.  **错误处理**：网络波动或 API 限流常见，必须实现指数退避重试机制，保证任务最终一致性。