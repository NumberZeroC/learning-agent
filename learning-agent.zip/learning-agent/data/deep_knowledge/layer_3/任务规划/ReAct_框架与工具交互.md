# ReAct 框架与工具交互

**生成时间：** 2026-03-29T23:58:40.677582

**类型：** tool

---

## 1. 工具介绍

ReAct（Reasoning + Acting）框架并不是一款独立的软件，而是一种大型语言模型（LLM）的提示工程范式与交互架构。它核心解决了传统 LLM 在面对复杂任务时“只会空想（幻觉）”或“只会盲动（错误调用）”的问题。

通过将“推理（Reasoning）”与“行动（Acting）”交织在一起，ReAct 让模型在执行任务前先思考步骤，调用工具后观察结果，再基于结果调整下一步计划。这种机制显著提升了模型在任务规划、事实核查及多步问题解决中的准确率，是构建自主 Agent（智能体）的基石。

## 2. 核心功能

1.  **思维链与行动交织（Interleaved CoT & Actions）**
    模型不再一次性生成所有文本，而是生成“思考 - 行动 - 观察”的循环。每一步行动都基于前一步的推理，确保逻辑连贯。
2.  **动态工具调用（Dynamic Tool Invocation）**
    支持模型根据当前需求自主选择工具（如搜索引擎、计算器、数据库），而非硬编码流程，增强了灵活性。
3.  **环境观察反馈（Observation Feedback）**
    工具执行后的结果会作为新的上下文返回给模型，模型据此判断任务是否完成或是否需要修正策略。
4.  **自我修正能力（Self-Correction）**
    当工具返回错误或无效信息时，ReAct 框架允许模型通过推理识别错误，并尝试更换工具或调整参数重试。
5.  **任务状态追踪（Task State Tracking）**
    在多轮交互中，框架维护当前任务进度，防止模型在长任务中迷失目标或重复操作。

## 3. 安装配置

由于 ReAct 是一种范式，通常通过代理框架（如 LangChain）实现。以下是基于 Python 和 LangChain 的环境配置步骤：

1.  **安装依赖库**
    打开终端，执行以下命令安装核心库：
    ```bash
    pip install langchain langchain-openai langchain-community python-dotenv
    ```

2.  **配置环境变量**
    在项目根目录创建 `.env` 文件，配置 LLM API 密钥：
    ```bash
    OPENAI_API_KEY=your_sk_key_here
    ```

3.  **初始化配置**
    在代码中加载环境变量并设置 LLM 模型，确保网络可访问 API 服务。

## 4. 基本用法

以下是一个使用 LangChain 实现 ReAct 代理的最小化示例，让它通过搜索工具回答问题：

```python
from langchain.agents import initialize_agent, Tool
from langchain.agents import AgentType
from langchain_community.utilities import DuckDuckGoSearchAPIWrapper
from langchain_openai import ChatOpenAI

# 1. 初始化搜索工具
search = DuckDuckGoSearchAPIWrapper()
tools = [
    Tool(
        name="Current Search",
        func=search.run,
        description="用于搜索最新的时事信息或未知事实"
    )
]

# 2. 初始化 LLM
llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo")

# 3. 初始化 ReAct 代理
agent = initialize_agent(
    tools, 
    llm, 
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, 
    verbose=True
)

# 4. 运行任务
agent.run("2024 年诺贝尔物理学奖得主是谁？")
```
**输出解析：** 终端将显示 `Thought`（思考）、`Action`（调用搜索）、`Observation`（搜索结果）的完整循环，最终输出答案。

## 5. 高级用法

1.  **自定义工具集成**
    除了搜索，你可以将内部 API 封装为 Tool。例如，编写一个 Python 函数查询公司数据库，并通过 `@tool` 装饰器注册给 ReAct 代理，使其能处理私有数据。
2.  **增加记忆模块（Memory）**
    在初始化 agent 时加入 `memory=ConversationBufferMemory()`。这样代理能记住多轮对话的历史，适用于需要上下文关联的复杂任务规划，如连续的数据分析任务。
3.  **少样本提示（Few-Shot Prompting）**
    通过 `FewShotAgent` 提供示例对话，教导模型在特定领域（如医疗或法律）如何更规范地进行思考和调用工具，减少格式错误。

## 6. 实际案例

**场景：智能旅行规划助手**

**用户请求：** “帮我计划一个去京都的 3 天行程，需要知道下周天气和推荐景点。”

**ReAct 执行流程：**
1.  **Thought:** 用户需要天气和景点信息。我需要先查天气，再查景点。
2.  **Action:** 调用 `WeatherTool`, 参数：{location: "Kyoto", date: "next week"}。
3.  **Observation:** 返回“下周京都多云，气温 15-20 度”。
4.  **Thought:** 天气适宜户外。现在需要查找京都热门景点。
5.  **Action:** 调用 `SearchTool`, 参数：{query: "Kyoto top 3 attractions"}。
6.  **Observation:** 返回“清水寺、伏见稻荷大社、金阁寺”。
7.  **Thought:** 信息已收集完整，可以生成行程。
8.  **Final Answer:** 生成包含天气提示和景点安排的 3 天行程表。

此案例展示了 ReAct 如何将模糊需求拆解为具体的工具调用序列。

## 7. 替代方案

1.  **Chain of Thought (CoT)**
    *   **优点：** 简单，无需外部工具，推理能力强。
    *   **缺点：** 无法获取实时信息，容易产生事实幻觉，无法执行实际操作。
2.  **Native Function Calling (原生函数调用)**
    *   **优点：** 模型直接输出结构化 JSON，速度快，延迟低。
    *   **缺点：** 推理过程不透明，难以处理需要多步反思的复杂任务。
3.  **Plan-and-Solve**
    *   **优点：** 先生成完整计划再执行，适合长流程。
    *   **缺点：** 灵活性差，若中间步骤出错，难以动态调整计划。

**对比总结：** ReAct 在需要“边想边做”且依赖外部信息的场景中表现最佳。

## 8. 参考文档

*   **原始论文：** [ReAct: Synergizing Reasoning and Acting in Language Models](https://arxiv.org/abs/2210.03629) (Arxiv)
*   **LangChain 官方文档：** [LangChain Agents & Tools](https://python.langchain.com/docs/modules/agents/)
*   **优质教程：** LangChain 官方 Blog 关于 ReAct Agent 的实战指南。

通过掌握 ReAct 框架，开发者可以构建出不仅“能说”而且“能做”的真正智能应用。