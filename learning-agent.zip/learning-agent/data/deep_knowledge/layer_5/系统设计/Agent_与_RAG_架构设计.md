# Agent 与 RAG 架构设计

**生成时间：** 2026-03-30T00:36:31.088683

**类型：** practice

---

## 1. 实践目标

本实践旨在构建一个融合检索增强生成（RAG）与智能体（Agent）能力的智能问答系统。核心目标是让大模型不仅能基于私有知识库准确回答事实性问题，还能通过调用外部工具完成复杂任务。学员将通过本实践掌握从数据清洗、向量存储到 Agent 路由决策的全流程系统设计能力。最终实现一个具备“记忆、检索、行动”三位一体能力的智能助手，有效解决大模型存在的幻觉问题与知识滞后痛点，为企业级 AI 应用落地提供标准化范式。

## 2. 背景介绍

随着大语言模型（LLM）技术的爆发，企业急需将 AI 能力融入业务流程。然而，通用大模型存在两大局限：一是缺乏企业内部私有数据，无法回答特定业务问题；二是无法直接执行实际操作，如查询数据库或调用 API。传统的 RAG 架构虽能补充知识，但缺乏主动规划能力；纯 Agent 架构虽能行动，但易产生幻觉。本实践适用于企业智能客服、内部知识助手等场景。例如，员工询问“公司差旅标准是多少？”（需 RAG 检索文档）或“帮我预订下周会议室”（需 Agent 调用日历 API）。结合两者可打造既懂知识又能办事的超级员工，显著提升工作效率。

## 3. 技术选型

为确保系统的可扩展性与开发效率，本实践采用以下技术栈：
*   **开发框架：LangChain**。因其生态丰富，提供了标准的 Agent 与 RAG 组件，简化了编排逻辑。
*   **向量数据库：Chroma**。轻量级、无需额外部署服务器，支持本地持久化，适合快速原型开发与中小规模数据。
*   **大语言模型：OpenAI GPT-4 或兼容接口**。保证强大的推理与工具调用能力，支持 Function Calling。
*   **Embedding 模型：text-embedding-ada-002 或 BGE**。确保语义匹配的精度，提升检索相关性。
*   **开发语言：Python 3.9+**。AI 生态最完善的语言，便于库集成与快速迭代。

## 4. 架构设计

系统采用分层架构设计，确保模块解耦与灵活扩展。

```mermaid
graph TD
    User[用户终端] --> API[API 网关]
    API --> Agent[Agent 控制器]
    Agent --> LLM[大语言模型]
    Agent --> Router{路由决策}
    Router -->|知识查询 | RAG[RAG 检索模块]
    Router -->|任务执行 | Tools[外部工具集]
    RAG --> VectorDB[(向量数据库)]
    Tools --> External[外部 API/DB]
    LLM --> Response[最终响应]
```

**设计说明：**
1.  **用户层**：通过 Web 或 IM 接口发起请求。
2.  **网关层**：负责鉴权、限流与请求转发。
3.  **Agent 核心**：大脑中枢，解析用户意图，决定是检索知识还是调用工具。
4.  **RAG 模块**：负责将用户问题转化为向量，在向量库中检索相关文档片段。
5.  **工具集**：封装具体的业务逻辑，如数据库查询、API 调用等。
6.  **数据层**：包含向量数据库与外部业务数据源。

## 5. 实现步骤

1.  **环境初始化**：安装 LangChain、Chroma 及相关依赖，配置 API Key 环境变量。
2.  **数据收集与清洗**：收集企业文档（PDF/Markdown），去除无关字符与乱码。
3.  **文本分块策略**：使用 `RecursiveCharacterTextSplitter` 按段落分块，设置 chunk_size=500。
4.  **生成 Embedding**：调用 Embedding 模型将文本块转化为向量表示。
5.  **存入向量库**：将向量与元数据存入 Chroma 集合，建立索引。
6.  **定义检索工具**：封装向量检索逻辑为 LangChain Tool，供 Agent 调用。
7.  **定义外部工具**：编写函数模拟预订会议室等操作，并注册为 Tool。
8.  **构建 Agent 提示词**：设计 System Prompt，明确 Agent 的角色与工具使用规范。
9.  **组装执行链**：使用 `initialize_agent` 将 LLM、工具链与记忆模块组装。
10. **接口封装**：使用 FastAPI 封装调用接口，支持异步请求。
11. **异常处理**：增加重试机制与超时处理，确保系统稳定性。
12. **日志监控**：记录 Token 消耗与响应延迟，便于后续优化。

## 6. 核心代码

以下是基于 LangChain 的核心实现代码，包含 RAG 检索与 Agent 工具绑定。

```python
import os
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings
from langchain.chat_models import ChatOpenAI
from langchain.agents import initialize_agent, Tool, AgentType
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import TextLoader

# 1. 初始化环境与模型
os.environ["OPENAI_API_KEY"] = "your-api-key"
llm = ChatOpenAI(temperature=0, model="gpt-4")
embeddings = OpenAIEmbeddings()

# 2. 数据处理与向量存储构建
def build_vector_store(file_path):
    loader = TextLoader(file_path)
    documents = loader.load()
    # 文本分块，避免超出 Context 限制
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    texts = text_splitter.split_documents(documents)
    # 存入 Chroma 向量库
    db = Chroma.from_documents(texts, embeddings, persist_directory="./db")
    return db

# 3. 定义检索工具
def search_knowledge(query):
    db = Chroma(persist_directory="./db", embedding_function=embeddings)
    docs = db.similarity_search(query, k=3)
    return "\n".join([doc.page_content for doc in docs])

# 4. 定义外部业务工具 (示例：查询天气)
def check_weather(location):
    return f"{location} 天气晴朗，温度 25 度"

# 5. 工具列表注册
tools = [
    Tool(name="Knowledge Search", func=search_knowledge, description="用于查询公司内部知识库"),
    Tool(name="Weather Check", func=check_weather, description="用于查询某地天气")
]

# 6. 初始化 Agent
agent = initialize_agent(
    tools, 
    llm, 
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, 
    verbose=True,
    handle_parsing_errors=True
)

# 7. 执行请求
if __name__ == "__main__":
    # 测试检索能力
    # agent.run("公司的差旅标准是什么？") 
    # 测试工具调用能力
    agent.run("北京天气怎么样？")
```

## 7. 测试验证

为确保系统可靠性，需进行多维度测试：
1.  **单元测试**：针对每个 Tool 函数编写断言，确保输入输出符合预期。
2.  **检索准确率测试**：构建标准问答对（QA Pair），计算检索文档与标准答案的语义相似度（Recall@K）。
3.  **幻觉评估**：人工抽检或采用 LLM 自评，检查回答是否基于检索内容，有无捏造事实。
4.  **压力测试**：使用 JMeter 模拟并发请求，观察系统延迟与错误率，确保 API 网关稳定。
5.  **边界测试**：输入无关问题或恶意提示，验证 Agent 是否能正确拒绝或引导。

## 8. 部署上线

1.  **容器化**：编写 `Dockerfile`，将依赖环境与代码打包，确保环境一致性。
2.  **服务编排**：使用 Docker Compose 编排 App、Chroma 与 Redis 服务。
3.  **网关配置**：前置 Nginx 进行反向代理，配置 HTTPS 证书保障传输安全。
4.  **密钥管理**：敏感信息（API Key）通过环境变量或 Vault 注入，严禁硬编码。
5.  **监控告警**：集成 Prometheus + Grafana，监控 CPU、内存及 Token 消耗，设置阈值告警。
6.  **灰度发布**：先向内部用户开放，收集反馈修复 Bug 后再全量上线。

## 9. 经验总结

在本实践中，我们积累了以下关键经验：
1.  **分块策略至关重要**：Chunk 大小直接影响检索效果。过大包含噪声，过小丢失语境。建议根据文档结构动态调整，通常 500-800 tokens 为宜。
2.  **Prompt 工程需迭代**：Agent 的行为高度依赖 System Prompt。需明确界定工具使用边界，防止模型滥用工具或陷入循环。
3.  **延迟优化**：RAG 检索与 LLM 生成均耗时。可采用流式输出（Streaming）提升用户体验，或对高频问题建立缓存。
4.  **成本控制**：Token 消耗是主要成本。建议在检索阶段进行重排序（Rerank），只将最相关的片段送入 LLM，减少输入长度。
5.  **安全合规**：务必在检索层增加权限控制，确保用户只能查询其权限范围内的知识库内容，防止数据泄露。

通过本实践，学员不仅能掌握技术实现，更能理解系统设计的权衡之道，为构建生产级 AI 应用打下坚实基础。