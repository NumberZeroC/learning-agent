#!/usr/bin/env python3
"""
Qwen3.5-Plus API 连接测试

测试配置：
- Base URL: https://coding.dashscope.aliyuncs.com/v1
- Model: qwen3.5-plus
- API Key: sk-sp-1103f012953e45d984ab8fbd486e6e16
"""

import os
import sys
import json
import requests
from pathlib import Path
from datetime import datetime

# 配置
BASE_URL = "https://coding.dashscope.aliyuncs.com/v1"
API_KEY = "sk-sp-1103f012953e45d984ab8fbd486e6e16"
MODEL = "qwen3.5-plus"

def test_api_connection():
    """测试 API 连接"""
    print("="*60)
    print("🧪 Qwen3.5-Plus API 连接测试")
    print("="*60)
    print(f"\n📋 测试配置:")
    print(f"   Base URL: {BASE_URL}")
    print(f"   Model: {MODEL}")
    print(f"   API Key: {API_KEY[:20]}...{API_KEY[-10:]}")
    
    # 构建请求
    url = f"{BASE_URL}/chat/completions"
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }
    
    payload = {
        "model": MODEL,
        "messages": [
            {
                "role": "system",
                "content": "你是一个有帮助的 AI 助手。"
            },
            {
                "role": "user",
                "content": "你好，请介绍一下你自己。请用简短的几句话回答。"
            }
        ],
        "temperature": 0.7,
        "max_tokens": 500
    }
    
    print(f"\n🚀 发送请求...")
    start_time = datetime.now()
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        print(f"⏱️ 响应时间：{duration:.2f}秒")
        print(f"📊 状态码：{response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            
            print(f"\n✅ API 连接成功！")
            print(f"\n📝 响应内容:")
            print(f"   ID: {result.get('id', 'N/A')}")
            print(f"   模型：{result.get('model', 'N/A')}")
            print(f"   使用 tokens: {result.get('usage', {}).get('total_tokens', 'N/A')}")
            
            if 'choices' in result and len(result['choices']) > 0:
                content = result['choices'][0]['message']['content']
                print(f"\n💬 AI 回复:")
                print(f"   {content[:200]}{'...' if len(content) > 200 else ''}")
            
            return True
        else:
            print(f"\n❌ API 请求失败")
            print(f"   错误信息：{response.text}")
            return False
            
    except requests.exceptions.Timeout:
        print(f"\n❌ 请求超时（>30 秒）")
        return False
    except requests.exceptions.ConnectionError as e:
        print(f"\n❌ 连接错误：{e}")
        return False
    except Exception as e:
        print(f"\n❌ 未知错误：{e}")
        return False


def test_config_manager():
    """测试配置管理器"""
    print("\n" + "="*60)
    print("🔧 配置管理器测试")
    print("="*60)
    
    # 添加项目路径
    sys.path.insert(0, str(Path(__file__).parent))
    
    try:
        from agents.config_manager import get_config_manager
        
        manager = get_config_manager()
        
        print(f"\n✅ 配置管理器已加载")
        print(f"   配置文件：{manager.config_path}")
        print(f"   配置哈希：{manager.config_hash[:8]}")
        
        # 测试获取 Agent 配置
        print(f"\n📊 Agent 配置:")
        agents = manager.get_all_agents_config()
        
        for name, config in agents.items():
            llm_config = config.get('llm_config', {})
            config_list = llm_config.get('config_list', [{}])
            first_config = config_list[0] if config_list else {}
            
            print(f"\n   {name}:")
            print(f"      模型：{config.get('model', 'N/A')}")
            print(f"      提供商：{config.get('provider', 'N/A')}")
            print(f"      Base URL: {first_config.get('base_url', 'N/A')[:50]}...")
            print(f"      API Key: {first_config.get('api_key', 'N/A')[:20]}...")
            print(f"      温度：{llm_config.get('temperature', 0.7)}")
            print(f"      Max Tokens: {llm_config.get('max_tokens', 4000)}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 配置管理器测试失败：{e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """主函数"""
    print("\n" + "="*60)
    print("🤖 Learning Agent - Qwen3.5-Plus 配置测试")
    print("="*60)
    
    # 测试 1: API 连接
    api_ok = test_api_connection()
    
    # 测试 2: 配置管理器
    config_ok = test_config_manager()
    
    # 总结
    print("\n" + "="*60)
    print("📊 测试总结")
    print("="*60)
    print(f"   API 连接：{'✅ 成功' if api_ok else '❌ 失败'}")
    print(f"   配置管理：{'✅ 成功' if config_ok else '❌ 失败'}")
    
    if api_ok and config_ok:
        print(f"\n🎉 所有测试通过！系统已就绪")
        print(f"\n📝 下一步:")
        print(f"   1. 运行多模型 AutoGen: python3 multimodel_autogen.py")
        print(f"   2. 访问 Web 界面：http://localhost:5001/config")
        print(f"   3. 查看学习路线：http://localhost:5001/")
        return 0
    else:
        print(f"\n⚠️ 部分测试失败，请检查配置")
        return 1


if __name__ == "__main__":
    sys.exit(main())
