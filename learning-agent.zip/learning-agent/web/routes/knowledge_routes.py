#!/usr/bin/env python3
"""
知识生成 API

支持：
- 触发知识生成任务
- 查看生成进度
- 获取生成的知识点
"""

from flask import Blueprint, jsonify, request
from pathlib import Path
import sys
import json
import asyncio
from datetime import datetime

# 添加项目路径
web_dir = Path(__file__).parent.parent
project_dir = web_dir.parent
sys.path.insert(0, str(project_dir))

knowledge_bp = Blueprint('knowledge', __name__, url_prefix='/api/knowledge')

# 任务状态存储
task_status = {
    "running": False,
    "progress": 0,
    "current_layer": 0,
    "message": "",
    "result": None
}


@knowledge_bp.route('/generate', methods=['POST'])
def trigger_generation():
    """触发知识生成任务"""
    global task_status
    
    if task_status['running']:
        return jsonify({
            "success": False,
            "error": "已有任务正在运行"
        }), 400
    
    # 获取请求参数
    data = request.get_json() or {}
    architecture = data.get('architecture', 'default')
    
    # 启动异步任务
    def run_generation():
        global task_status
        task_status['running'] = True
        task_status['progress'] = 0
        task_status['message'] = "正在启动任务..."
        
        try:
            # 导入并运行生成器
            sys.path.insert(0, str(project_dir))
            from knowledge_generator import TaskExecutor, LEARNING_ARCHITECTURE
            
            executor = TaskExecutor()
            
            # 选择架构图
            if architecture == 'custom' and 'custom_architecture' in data:
                arch = data['custom_architecture']
            else:
                arch = LEARNING_ARCHITECTURE
            
            # 执行任务
            result = asyncio.run(executor.execute_task(arch))
            
            task_status['result'] = result
            task_status['progress'] = 100
            task_status['message'] = "任务完成"
            
        except Exception as e:
            task_status['message'] = f"任务失败：{str(e)}"
            import traceback
            task_status['error'] = traceback.format_exc()
        
        finally:
            task_status['running'] = False
    
    # 在新线程中运行
    import threading
    thread = threading.Thread(target=run_generation)
    thread.start()
    
    return jsonify({
        "success": True,
        "message": "任务已启动",
        "task_id": datetime.now().strftime('%Y%m%d_%H%M%S')
    })


@knowledge_bp.route('/status', methods=['GET'])
def get_status():
    """获取任务状态"""
    return jsonify({
        "success": True,
        "data": task_status
    })


@knowledge_bp.route('/layers', methods=['GET'])
def get_generated_layers():
    """获取已生成的层级列表"""
    output_dir = project_dir / "data" / "generated_knowledge"
    
    if not output_dir.exists():
        return jsonify({
            "success": True,
            "data": {
                "layers": [],
                "total": 0
            }
        })
    
    layers = []
    for file in output_dir.glob("layer_*_generated.json"):
        try:
            with open(file, 'r', encoding='utf-8') as f:
                layer_data = json.load(f)
            
            layers.append({
                "layer": layer_data.get('layer', 0),
                "name": layer_data.get('layer_name', ''),
                "agent": layer_data.get('agent', ''),
                "topics_count": len(layer_data.get('topics', [])),
                "status": layer_data.get('status', ''),
                "generated_at": layer_data.get('end_time', ''),
                "file": file.name
            })
        except:
            pass
    
    layers.sort(key=lambda x: x['layer'])
    
    return jsonify({
        "success": True,
        "data": {
            "layers": layers,
            "total": len(layers)
        }
    })


@knowledge_bp.route('/layer/<int:layer_num>', methods=['GET'])
def get_layer_detail(layer_num: int):
    """获取指定层级的详细知识"""
    output_dir = project_dir / "data" / "generated_knowledge"
    layer_file = output_dir / f"layer_{layer_num}_generated.json"
    
    if not layer_file.exists():
        return jsonify({
            "success": False,
            "error": f"第{layer_num}层知识未生成"
        }), 404
    
    try:
        with open(layer_file, 'r', encoding='utf-8') as f:
            layer_data = json.load(f)
        
        return jsonify({
            "success": True,
            "data": layer_data
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"读取失败：{str(e)}"
        }), 500


@knowledge_bp.route('/topic/<int:layer_num>/<int:topic_index>', methods=['GET'])
def get_topic_detail(layer_num: int, topic_index: int):
    """获取指定主题的详细知识"""
    output_dir = project_dir / "data" / "generated_knowledge"
    layer_file = output_dir / f"layer_{layer_num}_generated.json"
    
    if not layer_file.exists():
        return jsonify({
            "success": False,
            "error": f"第{layer_num}层知识未生成"
        }), 404
    
    try:
        with open(layer_file, 'r', encoding='utf-8') as f:
            layer_data = json.load(f)
        
        topics = layer_data.get('topics', [])
        
        if topic_index < 1 or topic_index > len(topics):
            return jsonify({
                "success": False,
                "error": f"主题索引超出范围 (1-{len(topics)})"
            }), 404
        
        topic = topics[topic_index - 1]
        
        return jsonify({
            "success": True,
            "data": topic
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"读取失败：{str(e)}"
        }), 500


@knowledge_bp.route('/summary', methods=['GET'])
def get_learning_summary():
    """获取学习总结"""
    summary_file = project_dir / "data" / "knowledge" / "learning_summary.json"
    
    if not summary_file.exists():
        return jsonify({
            "success": True,
            "data": {
                "total_layers": 0,
                "total_topics": 0,
                "total_hours": 0,
                "layers": {}
            }
        })
    
    try:
        with open(summary_file, 'r', encoding='utf-8') as f:
            summary = json.load(f)
        
        return jsonify({
            "success": True,
            "data": summary
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"读取失败：{str(e)}"
        }), 500


# 注册蓝图
def register_blueprint(app):
    """注册蓝图到 Flask 应用"""
    app.register_blueprint(knowledge_bp)
