#!/usr/bin/env python3
"""
配置管理 API

支持：
- 查看当前配置
- 更新配置
- 热重载配置
- 查看配置历史
"""

from flask import Blueprint, jsonify, request
from pathlib import Path
import sys

# 导入配置管理器
web_dir = Path(__file__).parent.parent
project_dir = web_dir.parent
sys.path.insert(0, str(project_dir))

from agents.config_manager import get_config_manager

config_bp = Blueprint('config', __name__, url_prefix='/api/config')


@config_bp.route('/status', methods=['GET'])
def get_config_status():
    """获取配置状态"""
    manager = get_config_manager()
    
    return jsonify({
        "success": True,
        "data": {
            "config_file": str(manager.config_path.absolute()),
            "config_hash": manager.config_hash[:8],
            "hot_reload_enabled": manager.get_config("hot_reload.enabled", True),
            "watching": manager._watching,
            "agents_count": len(manager.get_config("agents", {})),
            "providers": list(manager.get_config("providers", {}).keys())
        }
    })


@config_bp.route('/agents', methods=['GET'])
def get_agents_config():
    """获取所有 Agent 配置"""
    manager = get_config_manager()
    
    agents = manager.get_all_agents_config()
    
    return jsonify({
        "success": True,
        "data": {
            "agents": agents,
            "total": len(agents)
        }
    })


@config_bp.route('/agents/<agent_name>', methods=['GET'])
def get_agent_config(agent_name: str):
    """获取指定 Agent 配置"""
    manager = get_config_manager()
    
    config = manager.get_agent_config(agent_name)
    llm_config = manager.get_llm_config(agent_name)
    
    if not config:
        return jsonify({
            "success": False,
            "error": f"Agent {agent_name} 不存在"
        }), 404
    
    return jsonify({
        "success": True,
        "data": {
            "agent": {
                "name": agent_name,
                "config": config,
                "llm_config": llm_config
            }
        }
    })


@config_bp.route('/agents/<agent_name>/model', methods=['PUT'])
def update_agent_model(agent_name: str):
    """更新 Agent 模型配置"""
    manager = get_config_manager()
    
    data = request.get_json()
    
    if not data:
        return jsonify({
            "success": False,
            "error": "请求数据为空"
        }), 400
    
    # 更新配置
    if 'provider' in data:
        manager.update_config(f"agents.{agent_name}.provider", data['provider'])
    
    if 'model' in data:
        manager.update_config(f"agents.{agent_name}.model", data['model'])
    
    if 'temperature' in data:
        manager.update_config(f"agents.{agent_name}.llm_config.temperature", data['temperature'])
    
    if 'max_tokens' in data:
        manager.update_config(f"agents.{agent_name}.llm_config.max_tokens", data['max_tokens'])
    
    return jsonify({
        "success": True,
        "message": f"Agent {agent_name} 配置已更新",
        "hot_reload": manager.get_config(f"agents.{agent_name}.hot_reload", True)
    })


@config_bp.route('/reload', methods=['POST'])
def reload_config():
    """热重载配置"""
    manager = get_config_manager()
    
    old_hash = manager.config_hash
    manager.reload_config()
    new_hash = manager.config_hash
    
    return jsonify({
        "success": True,
        "message": "配置已重载",
        "old_hash": old_hash[:8],
        "new_hash": new_hash[:8],
        "changed": old_hash != new_hash
    })


@config_bp.route('/history', methods=['GET'])
def get_config_history():
    """获取配置变更历史"""
    manager = get_config_manager()
    
    limit = request.args.get('limit', 10, type=int)
    history = manager.get_change_history(limit)
    
    return jsonify({
        "success": True,
        "data": {
            "history": history,
            "total": len(manager.change_history)
        }
    })


@config_bp.route('/providers', methods=['GET'])
def get_providers():
    """获取所有大模型提供商"""
    manager = get_config_manager()
    
    providers = manager.get_config("providers", {})
    
    result = {}
    for name, config in providers.items():
        if config.get('enabled', False):
            result[name] = {
                "base_url": config.get('base_url', ''),
                "models": list(config.get('models', {}).keys())
            }
    
    return jsonify({
        "success": True,
        "data": {
            "providers": result,
            "total": len(result)
        }
    })


@config_bp.route('/validate', methods=['GET'])
def validate_config():
    """验证配置有效性"""
    manager = get_config_manager()
    
    issues = []
    warnings = []
    
    # 检查配置文件是否存在
    if not manager.config_path.exists():
        issues.append(f"配置文件不存在：{manager.config_path}")
    
    # 检查 Agent 配置
    agents = manager.get_config("agents", {})
    for agent_name, config in agents.items():
        if config.get('enabled', False):
            # 检查提供商
            provider = config.get('provider')
            if not manager.get_config(f"providers.{provider}.enabled"):
                warnings.append(f"Agent {agent_name} 使用未启用的提供商：{provider}")
            
            # 检查模型
            model = config.get('model')
            models = manager.get_config(f"providers.{provider}.models", {})
            if model not in models:
                warnings.append(f"Agent {agent_name} 使用未知模型：{model}")
    
    # 检查热更新配置
    if not manager.get_config("hot_reload.enabled"):
        warnings.append("热更新已禁用")
    
    return jsonify({
        "success": True,
        "data": {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
            "issues_count": len(issues),
            "warnings_count": len(warnings)
        }
    })
