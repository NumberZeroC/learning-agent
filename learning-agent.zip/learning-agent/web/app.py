#!/usr/bin/env python3
"""
Learning Agent Web 应用

支持两种运行模式：
- Ask 模式：Web 问答助手，实时对话交互
- Task 模式：后台任务执行，批量知识生成（通过 cli.py）
"""

import os
import sys
import json
from pathlib import Path
from flask import Flask, render_template, jsonify, send_from_directory

# 添加项目路径
project_dir = Path(__file__).parent.parent
sys.path.insert(0, str(project_dir))

app = Flask(__name__)

# 数据目录
DATA_DIR = project_dir / "data" / "knowledge"

# 注册路由蓝图
from routes.config_routes import config_bp
from routes.chat_routes import chat_bp
from routes.knowledge_routes import knowledge_bp, register_blueprint as register_knowledge_bp

app.register_blueprint(config_bp)
app.register_blueprint(chat_bp)
register_knowledge_bp(app)


# ==================== 页面路由 ====================

@app.route('/')
def index():
    """首页 - 学习路线总览"""
    return render_template('index.html')


@app.route('/layer/<int:layer_id>')
def layer_detail(layer_id):
    """层级详情页"""
    return render_template('layer.html', layer_id=layer_id)


@app.route('/topic/<int:layer_id>/<int:topic_index>')
def topic_detail(layer_id, topic_index):
    """知识点详情页"""
    return render_template('topic.html', layer_id=layer_id, topic_index=topic_index)


@app.route('/config')
def config_page():
    """配置管理页"""
    return render_template('config.html')


@app.route('/chat')
def chat_page():
    """与主 Agent 对话页 - Ask 模式"""
    return render_template('chat.html')


@app.route('/knowledge')
def knowledge_page():
    """知识库页面"""
    return render_template('knowledge.html')


# ==================== API 路由 ====================

@app.route('/api/summary')
def api_summary():
    """获取学习总结"""
    summary_file = DATA_DIR / "learning_summary.json"
    
    if summary_file.exists():
        with open(summary_file, 'r', encoding='utf-8') as f:
            return jsonify(json.load(f))
    
    return jsonify({"error": "Summary not found"}), 404


@app.route('/api/layer/<int:layer_id>')
def api_layer(layer_id):
    """获取层级知识数据"""
    layer_file = DATA_DIR / f"layer_{layer_id}_knowledge.json"
    
    if layer_file.exists():
        with open(layer_file, 'r', encoding='utf-8') as f:
            return jsonify(json.load(f))
    
    return jsonify({"error": "Layer not found"}), 404


@app.route('/api/all')
def api_all_layers():
    """获取所有层级数据"""
    all_data = {}
    
    for i in range(1, 6):
        layer_file = DATA_DIR / f"layer_{i}_knowledge.json"
        if layer_file.exists():
            with open(layer_file, 'r', encoding='utf-8') as f:
                all_data[str(i)] = json.load(f)
    
    return jsonify(all_data)


@app.route('/api/mode')
def api_mode():
    """获取当前运行模式"""
    return jsonify({
        "mode": "ask",
        "description": "Web 问答助手模式，支持实时对话交互"
    })


@app.route('/static/<path:filename>')
def static_files(filename):
    """静态文件"""
    return send_from_directory(Path(__file__).parent / 'static', filename)


# ==================== 初始化函数 ====================

def initialize_ask_service():
    """
    初始化 Ask 服务
    
    在启动 Web 应用前调用，预加载配置和知识库
    """
    print("\n" + "="*60)
    print("🌐 初始化 Ask 服务...")
    print("="*60)
    
    from services.ask_service import get_ask_service
    
    # 获取 Ask 服务实例（会触发初始化）
    ask_service = get_ask_service()
    
    print(f"✅ Ask 服务初始化完成")
    print(f"   可用 Agent: {len(ask_service.get_available_agents())} 个")
    
    return ask_service


def create_app():
    """创建并配置 Flask 应用"""
    # 初始化 Ask 服务
    initialize_ask_service()
    
    return app


# ==================== 主入口 ====================

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description="Learning Agent Web 应用")
    parser.add_argument('--host', default='0.0.0.0', help='监听地址')
    parser.add_argument('--port', type=int, default=5001, help='监听端口')
    parser.add_argument('--debug', action='store_true', help='调试模式')
    
    args = parser.parse_args()
    
    # 初始化 Ask 服务
    initialize_ask_service()
    
    print(f"\n🚀 启动 Web 服务: http://{args.host}:{args.port}")
    print("="*60 + "\n")
    
    # 启动 Flask
    app.run(host=args.host, port=args.port, debug=args.debug)