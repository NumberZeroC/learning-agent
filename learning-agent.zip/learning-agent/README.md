# 🤖 Learning Agent - 学习架构生成器

使用 AutoGen 多 Agent 协作生成完整的 Agent 开发学习路线，并通过 Web 界面展示。

---

## 📁 项目结构

```
learning-agent/
├── config/                    # 配置文件
│   ├── agent_config.yaml      # Agent 配置
│   └── knowledge_schema.json  # 知识 schema
├── data/
│   └── knowledge/             # 生成的知识数据
├── web/                       # Web 展示
│   ├── app.py                 # Flask 应用
│   └── templates/             # HTML 模板
├── generator.py               # 知识生成器
├── main.py                    # AutoGen 主程序
└── README.md                  # 本文档
```

---

## 🚀 快速开始

### 1. 安装依赖

```bash
cd /home/admin/.openclaw/workspace/autogen-learning-agent
pip install -r requirements.txt
```

### 2. 生成学习路线

```bash
# 简化版（无需 AutoGen）
python3 generator.py

# 完整版（需要 AutoGen 和 API Key）
export DASHSCOPE_API_KEY="your-api-key"
python3 main.py
```

### 3. 启动 Web 服务

```bash
cd web
python3 app.py
```

访问：http://localhost:5001

---

## 📊 生成的知识架构

### 5 个学习层级

| 层级 | 名称 | 主题数 | 预计时长 |
|------|------|--------|---------|
| 1 | 基础理论层 | 4 | 370 小时 |
| 2 | 技术栈层 | 3 | 210 小时 |
| 3 | 核心能力层 | 4 | 225 小时 |
| 4 | 工程实践层 | 3 | 215 小时 |
| 5 | 面试准备层 | 3 | 235 小时 |

**总计：** 17 个主题，1255 小时（约 3 个月）

---

## 🤖 多 Agent 设计

### Agent 角色

| Agent | 负责层级 | 职责 |
|-------|---------|------|
| Theory Agent | 第 1 层 | 基础理论知识生成 |
| Tech Stack Agent | 第 2 层 | 技术栈知识生成 |
| Core Skill Agent | 第 3 层 | 核心能力知识生成 |
| Engineering Agent | 第 4 层 | 工程实践知识生成 |
| Interview Agent | 第 5 层 | 面试准备知识生成 |

### 协作流程

```
User Proxy → Group Chat → 各层 Agent → 知识生成 → 数据保存
```

---

## 📈 Web 功能

### 首页
- 学习路线总览
- 统计数据展示
- 层级卡片导航

### 层级详情页
- 主题列表
- 子主题详情
- 关键知识点
- 学习资源推荐
- 时间估算

---

## 📝 数据格式

### 知识数据结构

```json
{
  "layer": 1,
  "layer_name": "基础理论层",
  "topics": [
    {
      "name": "AI 基础",
      "description": "机器学习和深度学习基础",
      "subtopics": [
        {
          "name": "机器学习基础",
          "key_points": ["知识点 1", "知识点 2"],
          "resources": ["资源链接"],
          "estimated_hours": 40,
          "difficulty": "beginner"
        }
      ],
      "estimated_hours": 150,
      "priority": "high"
    }
  ],
  "total_hours": 370,
  "recommended_order": ["AI 基础", "LLM 原理", ...]
}
```

---

## 🎯 学习建议

1. **按顺序学习** - 从第 1 层到第 5 层
2. **理论与实践结合** - 每层完成后做项目
3. **持续 3 个月** - 每天 2-3 小时
4. **加入社区** - 与其他学习者交流

---

## 📚 扩展功能

- [ ] 学习进度跟踪
- [ ] 测验功能
- [ ] 学习社区
- [ ] 项目实战指导
- [ ] 面试模拟

---

*由 AutoGen Learning Agent 生成*
