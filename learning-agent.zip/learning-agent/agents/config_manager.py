#!/usr/bin/env python3
"""
配置热加载管理器

支持：
- 动态加载配置文件
- 配置文件变更检测
- 自动应用配置更改
- 配置备份和回滚
- 配置变更日志
"""

import os
import sys
import yaml
import json
import time
import shutil
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, Callable, List
from dataclasses import dataclass, field
try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler, FileModifiedEvent
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    Observer = None
    FileSystemEventHandler = None
    FileModifiedEvent = None
import threading


@dataclass
class ConfigChange:
    """配置变更记录"""
    timestamp: str
    agent_name: str
    field: str
    old_value: Any
    new_value: Any


if WATCHDOG_AVAILABLE:
    class ConfigFileHandler(FileSystemEventHandler):
        """配置文件变更处理器"""
        
        def __init__(self, callback: Callable):
            self.callback = callback
            self.last_modified = 0
        
        def on_modified(self, event):
            if isinstance(event, FileModifiedEvent):
                current_time = time.time()
                # 防止重复触发
                if current_time - self.last_modified > 1:
                    self.last_modified = current_time
                    self.callback(event.src_path)


class ConfigManager:
    """配置管理器（支持热更新）"""
    
    def __init__(self, config_path: str = "config/agent_config.yaml"):
        self.config_path = Path(config_path)
        self.config: Dict[str, Any] = {}
        self.config_hash: str = ""
        self.backup_dir = Path("config/backups")
        self.log_file = Path("logs/config_changes.log")
        
        # 回调函数
        self.change_callbacks: Dict[str, List[Callable]] = {}
        
        # 文件监控
        self.observer: Optional[Observer] = None
        self._watching = False
        
        # 变更记录
        self.change_history: List[ConfigChange] = []
        
        # 初始化
        self._ensure_directories()
        self.load_config()
    
    def _ensure_directories(self):
        """确保目录存在"""
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
    
    def _calculate_hash(self, content: str) -> str:
        """计算配置内容哈希"""
        return hashlib.md5(content.encode()).hexdigest()
    
    def load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        if not self.config_path.exists():
            print(f"⚠️ 配置文件不存在：{self.config_path}")
            return {}
        
        with open(self.config_path, 'r', encoding='utf-8') as f:
            content = f.read()
            self.config = yaml.safe_load(content)
            self.config_hash = self._calculate_hash(content)
        
        print(f"✅ 配置已加载：{self.config_path}")
        print(f"   哈希：{self.config_hash[:8]}")
        
        return self.config
    
    def get_config(self, key: str = None, default: Any = None) -> Any:
        """获取配置项"""
        if key is None:
            return self.config
        
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def update_config(self, key: str, value: Any, trigger_callback: bool = True):
        """更新配置项"""
        keys = key.split('.')
        config = self.config
        
        # 获取旧值
        old_value = self.get_config(key)
        
        # 更新配置
        for k in keys[:-1]:
            config = config.setdefault(k, {})
        
        config[keys[-1]] = value
        
        # 记录变更
        if old_value != value:
            change = ConfigChange(
                timestamp=datetime.now().isoformat(),
                agent_name=keys[0] if len(keys) > 0 else "unknown",
                field='.'.join(keys[1:]) if len(keys) > 1 else "",
                old_value=old_value,
                new_value=value
            )
            self.change_history.append(change)
            self._log_change(change)
            
            # 触发回调
            if trigger_callback:
                self._trigger_callbacks(key, old_value, value)
        
        # 保存到文件
        self.save_config()
    
    def save_config(self, backup: bool = True):
        """保存配置文件"""
        if backup:
            self._create_backup()
        
        with open(self.config_path, 'w', encoding='utf-8') as f:
            yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)
        
        print(f"💾 配置已保存：{self.config_path}")
    
    def _create_backup(self):
        """创建配置备份"""
        if not self.config_path.exists():
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = self.backup_dir / f"agent_config_{timestamp}.yaml"
        
        shutil.copy2(self.config_path, backup_file)
        print(f"📋 配置备份：{backup_file}")
        
        # 清理旧备份（保留最近 10 个）
        backups = sorted(self.backup_dir.glob("agent_config_*.yaml"))
        if len(backups) > 10:
            for old_backup in backups[:-10]:
                old_backup.unlink()
    
    def _log_change(self, change: ConfigChange):
        """记录配置变更日志"""
        log_entry = {
            "timestamp": change.timestamp,
            "agent": change.agent_name,
            "field": change.field,
            "old": change.old_value,
            "new": change.new_value
        }
        
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
    
    def register_callback(self, agent_name: str, callback: Callable):
        """注册配置变更回调"""
        if agent_name not in self.change_callbacks:
            self.change_callbacks[agent_name] = []
        self.change_callbacks[agent_name].append(callback)
    
    def _trigger_callbacks(self, key: str, old_value: Any, new_value: Any):
        """触发配置变更回调"""
        agent_name = key.split('.')[0]
        
        if agent_name in self.change_callbacks:
            for callback in self.change_callbacks[agent_name]:
                try:
                    callback(key, old_value, new_value)
                except Exception as e:
                    print(f"❌ 回调执行失败：{e}")
    
    def start_watching(self):
        """开始监控配置文件"""
        if self._watching:
            return
        
        if not WATCHDOG_AVAILABLE:
            print(f"⚠️ watchdog 未安装，配置监控已禁用")
            print(f"   安装：pip install watchdog")
            return
        
        event_handler = ConfigFileHandler(self._on_config_changed)
        self.observer = Observer()
        self.observer.schedule(event_handler, str(self.config_path.parent), recursive=False)
        self.observer.start()
        self._watching = True
        
        print(f"👁️ 开始监控配置变更：{self.config_path}")
    
    def stop_watching(self):
        """停止监控配置文件"""
        if self.observer:
            self.observer.stop()
            self.observer.join()
            self._watching = False
            print(f"⏹️ 停止监控配置变更")
    
    def _on_config_changed(self, file_path: str):
        """配置文件变更回调"""
        print(f"\n🔔 检测到配置文件变更：{file_path}")
        
        # 重新加载配置
        old_hash = self.config_hash
        self.load_config()
        new_hash = self.config_hash
        
        if old_hash != new_hash:
            print("✅ 配置已更新，触发热重载")
            self._trigger_callbacks("global", old_hash, new_hash)
    
    def get_agent_config(self, agent_name: str) -> Dict[str, Any]:
        """获取 Agent 配置"""
        return self.get_config(f"agents.{agent_name}", {})
    
    def get_llm_config(self, agent_name: str) -> Dict[str, Any]:
        """获取 Agent 的 LLM 配置"""
        agent_config = self.get_agent_config(agent_name)
        
        if not agent_config.get('enabled', False):
            return {}
        
        provider = agent_config.get('provider', 'dashscope')
        model = agent_config.get('model', 'qwen3.5-plus')
        
        # 获取提供商配置
        provider_config = self.get_config(f"providers.{provider}", {})
        
        if not provider_config.get('enabled', False):
            print(f"⚠️ 提供商 {provider} 未启用")
            return {}
        
        # 获取 API Key（优先使用配置中的值，其次环境变量）
        api_key = provider_config.get('api_key_value') or os.getenv(provider_config.get('api_key_env', ''))
        
        if not api_key:
            print(f"⚠️ API Key 未配置")
            return {}
        
        # 构建完整配置
        llm_config = {
            "config_list": [{
                "model": model,
                "base_url": provider_config.get('base_url', ''),
                "api_key": api_key
            }],
            "timeout": self.get_config("global.timeout", 60),
            "max_retries": self.get_config("global.max_retries", 3)
        }
        
        # 合并 Agent 特定配置
        agent_llm_config = agent_config.get('llm_config', {})
        llm_config.update(agent_llm_config)
        
        return llm_config
    
    def get_all_agents_config(self) -> Dict[str, Dict]:
        """获取所有 Agent 配置"""
        agents_config = self.get_config("agents", {})
        
        result = {}
        for agent_name, config in agents_config.items():
            if config.get('enabled', False):
                result[agent_name] = {
                    "name": agent_name,
                    "provider": config.get('provider', 'dashscope'),
                    "model": config.get('model', 'qwen-plus'),
                    "layer": config.get('layer'),
                    "role": config.get('role', ''),
                    "llm_config": self.get_llm_config(agent_name),
                    "hot_reload": config.get('hot_reload', True)
                }
        
        return result
    
    def get_change_history(self, limit: int = 10) -> List[Dict]:
        """获取配置变更历史"""
        return [
            {
                "timestamp": c.timestamp,
                "agent": c.agent_name,
                "field": c.field,
                "old": c.old_value,
                "new": c.new_value
            }
            for c in self.change_history[-limit:]
        ]
    
    def reload_config(self):
        """强制重新加载配置"""
        print("🔄 强制重新加载配置...")
        self.load_config()


# 全局配置管理器实例
_config_manager: Optional[ConfigManager] = None


def get_config_manager() -> ConfigManager:
    """获取全局配置管理器实例"""
    global _config_manager
    
    if _config_manager is None:
        _config_manager = ConfigManager()
    
    return _config_manager


def hot_reload_config():
    """热重载配置"""
    manager = get_config_manager()
    manager.reload_config()
    return manager.config


# 使用示例
if __name__ == "__main__":
    print("="*60)
    print("🔧 配置热加载管理器测试")
    print("="*60)
    
    # 获取配置管理器
    manager = get_config_manager()
    
    # 查看所有 Agent 配置
    print("\n📊 Agent 配置:")
    agents = manager.get_all_agents_config()
    for name, config in agents.items():
        print(f"  {name}:")
        print(f"    提供商：{config['provider']}")
        print(f"    模型：{config['model']}")
        print(f"    层级：{config.get('layer', 'N/A')}")
        print(f"    热更新：{config['hot_reload']}")
    
    # 注册回调
    def on_config_change(key, old, new):
        print(f"\n🔔 配置变更：{key}")
        print(f"   旧值：{old}")
        print(f"   新值：{new}")
    
    manager.register_callback("master_agent", on_config_change)
    
    # 开始监控
    manager.start_watching()
    
    print("\n✅ 配置管理器已启动")
    print("按 Ctrl+C 停止监控...")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        manager.stop_watching()
        print("\n✅ 已停止")
