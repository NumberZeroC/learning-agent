#!/usr/bin/env python3
"""
Agents 模块

提供事件驱动的多Agent协作框架:

核心组件:
- event_system: 事件系统和事件总线
- event_driven_agent: 事件驱动Agent基类
- master_agent: 主协调Agent
- worker_agents: 知识层Worker Agent
- coordinator: 任务协调器

工具:
- agent_tools: Agent工具集
- config_manager: 配置管理器

遗留模块:
- autogen_architecture: AutoGen主从架构
- multimodel_autogen: 多模型Agent系统
- run_autogen: 简化演示版
"""

# ==================== 事件驱动架构 ====================
from .event_system import (
    # 枚举和类型
    EventType,
    TaskPriority,
    AgentStatus,
    # 事件类
    Event,
    TaskAssignedEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    AgentStatusEvent,
    ProgressUpdateEvent,
    # 事件总线
    EventBus,
    get_event_bus,
    reset_event_bus
)

from .event_driven_agent import (
    EventDrivenAgent,
    AsyncEventDrivenAgent
)

from .master_agent import (
    MasterCoordinator,
    KNOWLEDGE_FRAMEWORK
)

from .worker_agents import (
    KnowledgeWorkerAgent,
    TheoryWorker,
    TechStackWorker,
    CoreSkillWorker,
    EngineeringWorker,
    InterviewWorker,
    create_all_workers
)

from .coordinator import (
    TaskCoordinator,
    ConcurrentTaskExecutor,
    run_learning_request
)

# ==================== 工具 ====================
from .agent_tools import (
    WebSearchTool,
    FileOperationsTool,
    CodeExecutionTool,
    CalculatorTool,
    ToolRegistry,
    get_tool_registry
)

# ==================== 配置管理 ====================
from .config_manager import (
    ConfigManager,
    ConfigChange,
    get_config_manager,
    hot_reload_config
)


__all__ = [
    # 事件系统
    'EventType',
    'TaskPriority',
    'AgentStatus',
    'Event',
    'TaskAssignedEvent',
    'TaskCompletedEvent',
    'TaskFailedEvent',
    'AgentStatusEvent',
    'ProgressUpdateEvent',
    'EventBus',
    'get_event_bus',
    'reset_event_bus',
    
    # 事件驱动Agent
    'EventDrivenAgent',
    'AsyncEventDrivenAgent',
    
    # 主Agent
    'MasterCoordinator',
    'KNOWLEDGE_FRAMEWORK',
    
    # Worker Agent
    'KnowledgeWorkerAgent',
    'TheoryWorker',
    'TechStackWorker',
    'CoreSkillWorker',
    'EngineeringWorker',
    'InterviewWorker',
    'create_all_workers',
    
    # 协调器
    'TaskCoordinator',
    'ConcurrentTaskExecutor',
    'run_learning_request',
    
    # 工具
    'WebSearchTool',
    'FileOperationsTool',
    'CodeExecutionTool',
    'CalculatorTool',
    'ToolRegistry',
    'get_tool_registry',
    
    # 配置管理
    'ConfigManager',
    'ConfigChange',
    'get_config_manager',
    'hot_reload_config',
]