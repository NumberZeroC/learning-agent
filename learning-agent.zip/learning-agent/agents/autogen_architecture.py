#!/usr/bin/env python3
"""
AutoGen 主从 Agent 架构

架构设计：
- 1 个 Master Agent（主 Agent）- 负责任务分解和协调
- 5 个 Worker Agent（子 Agent）- 每个负责一个知识层
- 所有 Agent 都可独立调用大模型
"""

import os
import sys
import json
import yaml
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

try:
    from autogen import ConversableAgent, UserProxyAgent, GroupChat, GroupChatManager
    AUTOGEN_AVAILABLE = True
except ImportError:
    print("⚠️ 未安装 AutoGen，请运行：pip install pyautogen")
    AUTOGEN_AVAILABLE = False


class LearningAgentArchitecture:
    """Learning Agent 主从架构"""
    
    def __init__(self, config_path: str = "config/agent_config.yaml"):
        self.config = self._load_config(config_path)
        self.data_dir = Path("data/knowledge")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Agent 实例
        self.master_agent = None
        self.worker_agents = {}
        self.user_proxy = None
        self.group_chat = None
        self.group_chat_manager = None
        
        # 知识框架
        self.knowledge_framework = {
            1: {"name": "基础理论层", "agent_name": "theory_worker"},
            2: {"name": "技术栈层", "agent_name": "tech_stack_worker"},
            3: {"name": "核心能力层", "agent_name": "core_skill_worker"},
            4: {"name": "工程实践层", "agent_name": "engineering_worker"},
            5: {"name": "面试准备层", "agent_name": "interview_worker"}
        }
        
        # LLM 配置
        self.llm_config = {
            "config_list": [
                {
                    "model": os.getenv("DASHSCOPE_MODEL", "qwen-plus"),
                    "api_key": os.getenv("DASHSCOPE_API_KEY", "")
                }
            ],
            "temperature": 0.7,
            "max_tokens": 4000
        }
    
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        config_file = Path(config_path)
        if not config_file.exists():
            config_file = Path(__file__).parent / config_path
        
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        return {}
    
    def create_master_agent(self):
        """创建主 Agent"""
        if not AUTOGEN_AVAILABLE:
            return None
        
        system_message = """你是 Learning Agent 系统的主协调者 (Master Agent)。

## 你的职责
1. 接收用户的学习需求
2. 分析需求并分解任务
3. 协调 5 个子 Agent 完成各自负责的知识层
4. 汇总结果并输出完整学习路线

## 子 Agent 列表
- theory_worker: 负责第 1 层（基础理论层）
- tech_stack_worker: 负责第 2 层（技术栈层）
- core_skill_worker: 负责第 3 层（核心能力层）
- engineering_worker: 负责第 4 层（工程实践层）
- interview_worker: 负责第 5 层（面试准备层）

## 工作流程
1. 接收任务 → 2. 任务分解 → 3. 分配给子 Agent → 4. 汇总结果 → 5. 输出

## 输出要求
- 使用 JSON 格式输出学习路线
- 包含所有 5 个层级的详细内容
- 每个主题包含：描述、子主题、知识点、资源、时间估算

记住：你是协调者，不是执行者。将具体任务分配给对应的子 Agent。"""
        
        self.master_agent = ConversableAgent(
            name="master_agent",
            system_message=system_message,
            llm_config=self.llm_config,
            human_input_mode="NEVER",
            max_consecutive_auto_reply=10
        )
        
        print("✅ 创建主 Agent: master_agent")
        return self.master_agent
    
    def create_worker_agents(self):
        """创建子 Agent（Worker Agents）"""
        if not AUTOGEN_AVAILABLE:
            return
        
        worker_configs = [
            {
                "name": "theory_worker",
                "layer": 1,
                "role": "基础理论专家",
                "topics": ["AI 基础", "LLM 原理", "Agent 概念", "架构模式"]
            },
            {
                "name": "tech_stack_worker",
                "layer": 2,
                "role": "技术栈专家",
                "topics": ["Python 编程", "Agent 框架", "向量数据库", "深度学习框架"]
            },
            {
                "name": "core_skill_worker",
                "layer": 3,
                "role": "核心能力专家",
                "topics": ["任务规划", "工具调用", "记忆管理", "多 Agent 协作"]
            },
            {
                "name": "engineering_worker",
                "layer": 4,
                "role": "工程实践专家",
                "topics": ["项目经验", "性能优化", "部署运维", "安全合规"]
            },
            {
                "name": "interview_worker",
                "layer": 5,
                "role": "面试准备专家",
                "topics": ["算法题", "系统设计", "行为面试", "项目阐述"]
            }
        ]
        
        for worker_config in worker_configs:
            system_message = self._create_worker_system_message(worker_config)
            
            agent = ConversableAgent(
                name=worker_config["name"],
                system_message=system_message,
                llm_config=self.llm_config,
                human_input_mode="NEVER",
                max_consecutive_auto_reply=10
            )
            
            self.worker_agents[worker_config["layer"]] = agent
            print(f"✅ 创建子 Agent: {worker_config['name']} (第{worker_config['layer']}层)")
        
        return self.worker_agents
    
    def _create_worker_system_message(self, config: Dict) -> str:
        """创建子 Agent 系统消息"""
        return f"""你是 Learning Agent 系统的{config['role']}。

## 负责层级
第{config['layer']}层：{self.knowledge_framework[config['layer']]['name']}

## 主要主题
{', '.join(config['topics'])}

## 你的职责
1. 接收主 Agent (master_agent) 的任务分配
2. 生成负责层级的详细学习内容
3. 为每个主题提供：
   - 详细描述
   - 3-5 个子主题
   - 每个子主题的关键知识点（至少 3 个）
   - 推荐学习资源（书籍、课程、文档链接）
   - 估算学习时间（小时）
   - 难度级别（beginner/intermediate/advanced）

## 输出格式
请严格按照以下 JSON 格式输出：
{{
    "layer": {config['layer']},
    "layer_name": "{self.knowledge_framework[config['layer']]['name']}",
    "topics": [
        {{
            "name": "主题名称",
            "description": "主题描述",
            "subtopics": [
                {{
                    "name": "子主题",
                    "key_points": ["知识点 1", "知识点 2", "知识点 3"],
                    "resources": ["资源链接 1", "资源链接 2"],
                    "estimated_hours": 10,
                    "difficulty": "intermediate"
                }}
            ],
            "estimated_hours": 40,
            "priority": "high"
        }}
    ],
    "total_hours": 总学习时长，
    "recommended_order": ["推荐学习顺序"]
}}

## 注意事项
- 内容要详细、实用
- 资源链接要真实有效
- 时间估算要合理
- 只输出 JSON，不要其他内容
- 如果主 Agent 没有明确要求，按默认格式输出
"""
    
    def create_user_proxy(self):
        """创建用户代理"""
        if not AUTOGEN_AVAILABLE:
            return None
        
        self.user_proxy = UserProxyAgent(
            name="user_proxy",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=0,
            code_execution_config=False
        )
        
        print("✅ 创建用户代理：user_proxy")
        return self.user_proxy
    
    def create_group_chat(self):
        """创建群聊"""
        if not AUTOGEN_AVAILABLE:
            return None
        
        # 创建群聊（包含主 Agent 和所有子 Agent）
        agents = [self.master_agent] + list(self.worker_agents.values())
        
        self.group_chat = GroupChat(
            agents=agents,
            messages=[],
            max_round=20,
            speaker_selection_method="round_robin"  # 轮流发言
        )
        
        # 创建群聊管理器（由主 Agent 管理）
        self.group_chat_manager = GroupChatManager(
            groupchat=self.group_chat,
            llm_config=self.llm_config
        )
        
        print("✅ 创建群聊和群聊管理器")
        return self.group_chat, self.group_chat_manager
    
    def generate_knowledge(self, task: str = "生成完整的 Agent 开发学习路线"):
        """生成知识内容"""
        if not AUTOGEN_AVAILABLE:
            print("❌ AutoGen 不可用")
            return
        
        print("\n" + "="*60)
        print("🚀 开始生成学习路线...")
        print("="*60)
        print(f"📋 任务：{task}\n")
        
        # 启动群聊
        response = self.user_proxy.initiate_chat(
            self.group_chat_manager,
            message=f"""请生成完整的 Agent 开发学习路线。

要求：
1. 包含所有 5 个层级的详细内容
2. 每个层级由对应的子 Agent 负责生成
3. 主 Agent 负责协调和汇总
4. 最终输出完整的 JSON 格式学习路线

开始执行任务。""",
            max_turns=30,
            summary_method="last_msg"
        )
        
        # 提取并保存结果
        self._process_results(response.chat_history)
        
        print("\n✅ 知识生成完成！")
    
    def _process_results(self, chat_history: List[Dict]):
        """处理聊天历史，提取并保存结果"""
        print("\n📥 处理结果...")
        
        # 按 Agent 分组消息
        agent_messages = {}
        for msg in chat_history:
            sender = msg.get('name', 'unknown')
            content = msg.get('content', '')
            
            if sender not in agent_messages:
                agent_messages[sender] = []
            agent_messages[sender].append(content)
        
        # 提取每个 Worker 的 JSON 数据
        for layer, agent in self.worker_agents.items():
            agent_name = agent.name
            
            if agent_name in agent_messages:
                # 提取 JSON
                knowledge_data = self._extract_json(agent_messages[agent_name])
                
                if knowledge_data:
                    self._save_knowledge(layer, knowledge_data)
                    print(f"✅ 第{layer}层知识已保存")
                else:
                    print(f"⚠️ 第{layer}层知识提取失败")
        
        # 生成总结
        self._generate_summary()
    
    def _extract_json(self, messages: List[str]) -> Dict:
        """从消息中提取 JSON"""
        for msg in reversed(messages):
            content = msg
            
            # 尝试提取 JSON
            start = content.find('{')
            end = content.rfind('}') + 1
            
            if start >= 0 and end > start:
                json_str = content[start:end]
                try:
                    return json.loads(json_str)
                except json.JSONDecodeError:
                    continue
        
        return {}
    
    def _save_knowledge(self, layer: int, data: Dict):
        """保存知识数据"""
        output_file = self.data_dir / f"layer_{layer}_knowledge.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"📄 已保存：{output_file}")
    
    def _generate_summary(self):
        """生成学习路线总结"""
        summary = {
            "generated_at": datetime.now().isoformat(),
            "architecture": "master-worker",
            "total_layers": len(self.knowledge_framework),
            "agents": {
                "master": "master_agent",
                "workers": [agent.name for agent in self.worker_agents.values()]
            },
            "layers": {},
            "total_hours": 0
        }
        
        for layer in sorted(self.knowledge_framework.keys()):
            data_file = self.data_dir / f"layer_{layer}_knowledge.json"
            
            if data_file.exists():
                with open(data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                summary["layers"][str(layer)] = {
                    "name": self.knowledge_framework[layer]["name"],
                    "agent": self.worker_agents[layer].name,
                    "topics_count": len(data.get("topics", [])),
                    "total_hours": data.get("total_hours", 0)
                }
                summary["total_hours"] += data.get("total_hours", 0)
        
        # 保存总结
        summary_file = self.data_dir / "learning_summary.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        print(f"\n📊 学习路线总结已保存：{summary_file}")
        print(f"   架构：Master-Worker")
        print(f"   Agent 数：1 个主 Agent + {len(self.worker_agents)} 个子 Agent")
        print(f"   总层级：{len(self.knowledge_framework)}")
        print(f"   预计总时长：{summary['total_hours']} 小时")
    
    def initialize(self):
        """初始化整个系统"""
        print("="*60)
        print("🤖 Learning Agent - AutoGen 主从架构")
        print("="*60)
        
        # 创建所有 Agent
        self.create_user_proxy()
        self.create_master_agent()
        self.create_worker_agents()
        self.create_group_chat()
        
        print("\n✅ 系统初始化完成！")
        print(f"   主 Agent: 1 个")
        print(f"   子 Agent: {len(self.worker_agents)}个")
        print(f"   知识层级：{len(self.knowledge_framework)}层")


def main():
    """主函数"""
    # 初始化系统
    architecture = LearningAgentArchitecture()
    architecture.initialize()
    
    # 生成知识
    architecture.generate_knowledge()
    
    print("\n" + "="*60)
    print("✅ 任务完成！")
    print("="*60)


if __name__ == "__main__":
    main()
