#!/usr/bin/env python3
"""
事件驱动架构示例和测试

演示如何使用事件驱动架构：
1. 初始化事件总线和Agent
2. 发布任务分配事件
3. 观察Worker处理事件
4. 收集完成结果
"""

import asyncio
import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents import (
    # 事件系统
    EventBus,
    Event,
    EventType,
    TaskAssignedEvent,
    TaskCompletedEvent,
    TaskPriority,
    AgentStatus,
    get_event_bus,
    reset_event_bus,
    
    # Agent
    MasterCoordinator,
    TheoryWorker,
    TechStackWorker,
    CoreSkillWorker,
    EngineeringWorker,
    InterviewWorker,
    create_all_workers,
    
    # 协调器
    TaskCoordinator,
    run_learning_request
)


def example_basic_event_flow():
    """
    示例1: 基本事件流程
    
    演示最简单的事件发布-订阅流程
    """
    print("\n" + "="*60)
    print("📝 示例1: 基本事件流程")
    print("="*60)
    
    # 重置事件总线
    reset_event_bus()
    event_bus = get_event_bus()
    
    # 创建事件接收器
    received_events = []
    
    def event_handler(event: Event):
        print(f"   📨 收到事件: {event.event_type.value}")
        received_events.append(event)
    
    # 订阅事件
    event_bus.subscribe(EventType.TASK_ASSIGNED, event_handler)
    event_bus.subscribe(EventType.TASK_COMPLETED, event_handler)
    
    # 发布任务分配事件
    task_event = TaskAssignedEvent(
        sender="test_user",
        task_id="test_001",
        task_content="测试任务",
        target_agent="theory_worker",
        layer=1
    )
    event_bus.publish(task_event)
    
    # 发布任务完成事件
    completed_event = TaskCompletedEvent(
        sender="theory_worker",
        task_id="test_001",
        result={"status": "done"},
        source_agent="theory_worker",
        layer=1
    )
    event_bus.publish(completed_event)
    
    # 查看事件历史
    print(f"\n📊 事件历史: {len(event_bus.get_history())} 个事件")
    stats = event_bus.get_stats()
    print(f"   总订阅者: {stats['subscriber_count']}")
    
    print(f"\n✅ 示例1完成: 接收了 {len(received_events)} 个事件")


def example_master_worker_interaction():
    """
    示例2: 主Agent与Worker交互
    
    演示主Agent分配任务给Worker的完整流程
    """
    print("\n" + "="*60)
    print("📝 示例2: 主Agent与Worker交互")
    print("="*60)
    
    # 重置
    reset_event_bus()
    
    # 创建事件总线
    event_bus = get_event_bus()
    
    # 创建Worker（只创建第一个用于演示）
    print("\n📦 创建Worker...")
    worker = TheoryWorker(event_bus=event_bus)
    
    # 创建模拟的主Agent（简化版）
    print("\n📦 模拟主Agent发布任务...")
    
    # 发布任务
    task = TaskAssignedEvent(
        sender="master_agent",
        task_id="demo_task_001",
        task_content="生成基础理论层的学习内容",
        target_agent="theory_worker",
        layer=1,
        priority=TaskPriority.HIGH
    )
    
    print(f"\n📤 主Agent发布任务: {task.task_id}")
    event_bus.publish(task)
    
    # 检查Worker状态
    print(f"\n📊 Worker状态: {worker.get_status()}")
    
    # 获取生成的知识
    if worker._knowledge_data:
        print(f"\n📚 Worker生成的知识: {len(worker._knowledge_data)} 条记录")
    
    print(f"\n✅ 示例2完成")


async def example_async_concurrent_execution():
    """
    示例3: 异步并发执行
    
    演示多个Worker并发处理任务
    """
    print("\n" + "="*60)
    print("📝 示例3: 异步并发执行")
    print("="*60)
    
    # 重置
    reset_event_bus()
    
    # 创建协调器
    coordinator = TaskCoordinator()
    coordinator.initialize()
    
    print("\n🚀 开始异步执行...")
    
    # 使用快捷函数执行
    result = await coordinator.execute_concurrent_async(
        "生成Agent开发学习路线的第一层内容",
        timeout=60
    )
    
    print(f"\n📊 执行结果:")
    print(f"   成功: {result['success']}")
    print(f"   耗时: {result['elapsed_seconds']:.2f}秒")
    
    if result['success'] and result['results']:
        print(f"   结果层数: {len(result['results'])}")
    
    print(f"\n✅ 示例3完成")


def example_full_learning_request():
    """
    示例4: 完整的学习请求
    
    演示完整的端到端学习路线生成
    """
    print("\n" + "="*60)
    print("📝 示例4: 完整学习请求")
    print("="*60)
    
    # 使用快捷函数
    print("\n🚀 执行完整学习请求...")
    
    result = run_learning_request(
        request="生成完整的Agent开发学习路线",
        output_dir="data/knowledge"
    )
    
    print(f"\n📊 执行结果:")
    print(f"   成功: {result['success']}")
    print(f"   耗时: {result['elapsed_seconds']:.2f}秒")
    
    if result['success']:
        results = result['results']
        print(f"\n📚 生成的知识层:")
        for layer, data in results.items():
            topics = data.get('topics', [])
            hours = data.get('total_hours', 0)
            print(f"   第{layer}层: {len(topics)} 个主题, {hours} 小时")
    
    print(f"\n✅ 示例4完成")


def example_event_bus_monitoring():
    """
    示例5: 事件总线监控
    
    演示如何监控事件流
    """
    print("\n" + "="*60)
    print("📝 示例5: 事件总线监控")
    print("="*60)
    
    reset_event_bus()
    event_bus = get_event_bus()
    
    # 创建监控器
    event_log = []
    
    def monitor(event: Event):
        entry = {
            "time": event.timestamp,
            "type": event.event_type.value,
            "sender": event.sender
        }
        event_log.append(entry)
        print(f"   📊 {entry['type']} from {entry['sender']}")
    
    # 订阅所有事件类型
    for event_type in EventType:
        event_bus.subscribe(event_type, monitor)
    
    # 模拟事件流
    print("\n📤 模拟事件流:")
    
    # 状态事件
    status_event = TaskAssignedEvent(
        sender="master",
        task_id="monitor_001",
        task_content="监控测试",
        target_agent="worker_1",
        layer=1
    )
    event_bus.publish(status_event)
    
    # 进度事件
    from agents.event_system import ProgressUpdateEvent
    progress = ProgressUpdateEvent(
        sender="worker_1",
        task_id="monitor_001",
        agent_name="worker_1",
        progress=0.5,
        message="处理中"
    )
    event_bus.publish(progress)
    
    # 完成事件
    complete = TaskCompletedEvent(
        sender="worker_1",
        task_id="monitor_001",
        result={"done": True},
        source_agent="worker_1"
    )
    event_bus.publish(complete)
    
    print(f"\n📊 监控统计:")
    print(f"   记录事件数: {len(event_log)}")
    stats = event_bus.get_stats()
    print(f"   历史事件: {stats['total_events']}")
    
    print(f"\n✅ 示例5完成")


def example_custom_worker():
    """
    示例6: 自定义Worker
    
    演示如何创建自定义的Worker Agent
    """
    print("\n" + "="*60)
    print("📝 示例6: 自定义Worker")
    print("="*60)
    
    from agents.event_driven_agent import EventDrivenAgent
    from agents.config_manager import get_config_manager
    
    # 创建自定义Worker
    class CustomWorker(EventDrivenAgent):
        """自定义Worker示例"""
        
        def __init__(self, event_bus=None):
            # 获取配置
            config_manager = get_config_manager()
            llm_config = config_manager.get_llm_config("master_agent")
            
            super().__init__(
                name="custom_worker",
                system_message="你是一个自定义的Worker Agent。",
                llm_config=llm_config,
                event_bus=event_bus,
                subscribed_events=[EventType.TASK_ASSIGNED]
            )
        
        def on_task_assigned(self, event):
            """处理任务"""
            print(f"   🔧 CustomWorker 处理任务: {event.task_id}")
            
            # 自定义处理逻辑
            result = {
                "task_id": event.task_id,
                "custom_result": "这是自定义Worker的处理结果",
                "processed_by": self.name
            }
            
            # 发布完成事件
            completed = TaskCompletedEvent(
                sender=self.name,
                task_id=event.task_id,
                result=result,
                source_agent=self.name
            )
            self.event_bus.publish(completed)
            
            return result
    
    # 测试自定义Worker
    reset_event_bus()
    event_bus = get_event_bus()
    
    print("\n📦 创建自定义Worker...")
    worker = CustomWorker(event_bus=event_bus)
    
    # 发送测试任务
    print("\n📤 发送测试任务...")
    task = TaskAssignedEvent(
        sender="test",
        task_id="custom_001",
        task_content="自定义任务",
        target_agent="custom_worker",
        layer=99
    )
    event_bus.publish(task)
    
    print(f"\n✅ 示例6完成")


def run_all_examples():
    """运行所有示例"""
    print("\n" + "="*60)
    print("🤖 事件驱动架构 - 示例演示")
    print("="*60)
    
    # 运行各示例
    example_basic_event_flow()
    example_master_worker_interaction()
    example_event_bus_monitoring()
    example_custom_worker()
    
    # 异步示例需要特殊处理
    print("\n" + "-"*60)
    print("以下示例需要异步执行（在此演示中跳过）:")
    print("- 示例3: 异步并发执行")
    print("- 示例4: 完整学习请求")
    print("-"*60)
    
    # 运行同步版本
    print("\n💡 提示: 完整示例请运行:")
    print("   python -c \"from agents import TaskCoordinator; c = TaskCoordinator(); c.initialize(); print(c.execute_concurrent('生成学习路线'))\"")
    
    print("\n" + "="*60)
    print("✅ 所有示例演示完成!")
    print("="*60)


if __name__ == "__main__":
    run_all_examples()