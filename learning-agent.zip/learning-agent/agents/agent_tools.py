#!/usr/bin/env python3
"""
Agent 系统工具集

提供常用工具功能：
- 联网搜索
- 文件读写
- 代码执行
- 计算器
- 等等
"""

import os
import json
import requests
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime


class WebSearchTool:
    """联网搜索工具"""
    
    def __init__(self, api_key: str = None, max_results: int = 5):
        self.api_key = api_key or os.getenv("TAVILY_API_KEY", "")
        self.max_results = max_results
        self.enabled = bool(self.api_key)
    
    def search(self, query: str, num_results: int = None) -> List[Dict]:
        """
        搜索网络信息
        
        Args:
            query: 搜索关键词
            num_results: 返回结果数量
        
        Returns:
            搜索结果列表
        """
        if not self.enabled:
            return [{"error": "API Key 未配置，搜索功能不可用"}]
        
        try:
            # 使用 Tavily API（或其他搜索 API）
            url = "https://api.tavily.com/search"
            payload = {
                "api_key": self.api_key,
                "query": query,
                "max_results": num_results or self.max_results,
                "include_answer": True,
                "include_raw_content": False
            }
            
            response = requests.post(url, json=payload, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            return result.get("results", [])
            
        except Exception as e:
            return [{"error": f"搜索失败：{str(e)}"}]
    
    def get_tool_definition(self) -> Dict:
        """返回工具定义（用于 AutoGen）"""
        return {
            "type": "function",
            "function": {
                "name": "web_search",
                "description": "搜索网络获取最新信息",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "搜索关键词"
                        },
                        "num_results": {
                            "type": "integer",
                            "description": "返回结果数量",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                }
            }
        }


class FileOperationsTool:
    """文件操作工具"""
    
    def __init__(self, base_dir: str = "./data"):
        self.base_dir = Path(base_dir).absolute()
        self.allowed_extensions = [".txt", ".md", ".json", ".yaml", ".yml", ".py", ".csv"]
    
    def read_file(self, file_path: str) -> Dict[str, Any]:
        """
        读取文件内容
        
        Args:
            file_path: 文件路径（相对于 base_dir）
        
        Returns:
            文件内容
        """
        try:
            # 安全检查
            full_path = (self.base_dir / file_path).resolve()
            if not str(full_path).startswith(str(self.base_dir)):
                return {"error": "非法路径"}
            
            if not full_path.exists():
                return {"error": f"文件不存在：{file_path}"}
            
            # 检查扩展名
            if full_path.suffix not in self.allowed_extensions:
                return {"error": f"不支持的文件类型：{full_path.suffix}"}
            
            # 读取内容
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return {
                "success": True,
                "file": str(file_path),
                "content": content,
                "size": len(content),
                "lines": content.count('\n') + 1
            }
            
        except Exception as e:
            return {"error": f"读取失败：{str(e)}"}
    
    def write_file(self, file_path: str, content: str) -> Dict[str, Any]:
        """
        写入文件内容
        
        Args:
            file_path: 文件路径
            content: 文件内容
        
        Returns:
            操作结果
        """
        try:
            # 安全检查
            full_path = (self.base_dir / file_path).resolve()
            if not str(full_path).startswith(str(self.base_dir)):
                return {"error": "非法路径"}
            
            # 检查扩展名
            if full_path.suffix not in self.allowed_extensions:
                return {"error": f"不支持的文件类型：{full_path.suffix}"}
            
            # 创建目录
            full_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 写入内容
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return {
                "success": True,
                "file": str(file_path),
                "size": len(content),
                "path": str(full_path)
            }
            
        except Exception as e:
            return {"error": f"写入失败：{str(e)}"}
    
    def list_files(self, dir_path: str = "") -> Dict[str, Any]:
        """
        列出目录文件
        
        Args:
            dir_path: 目录路径
        
        Returns:
            文件列表
        """
        try:
            full_path = (self.base_dir / dir_path).resolve()
            if not str(full_path).startswith(str(self.base_dir)):
                return {"error": "非法路径"}
            
            if not full_path.exists():
                return {"error": f"目录不存在：{dir_path}"}
            
            files = []
            for item in full_path.iterdir():
                if item.is_file() and item.suffix in self.allowed_extensions:
                    files.append({
                        "name": item.name,
                        "size": item.stat().st_size,
                        "modified": datetime.fromtimestamp(item.stat().st_mtime).isoformat()
                    })
            
            return {
                "success": True,
                "directory": str(dir_path),
                "files": files,
                "count": len(files)
            }
            
        except Exception as e:
            return {"error": f"列出失败：{str(e)}"}
    
    def get_tool_definitions(self) -> List[Dict]:
        """返回工具定义"""
        return [
            {
                "type": "function",
                "function": {
                    "name": "read_file",
                    "description": "读取文件内容",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "文件路径"
                            }
                        },
                        "required": ["file_path"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "write_file",
                    "description": "写入文件内容",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "文件路径"
                            },
                            "content": {
                                "type": "string",
                                "description": "文件内容"
                            }
                        },
                        "required": ["file_path", "content"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "list_files",
                    "description": "列出目录中的文件",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "dir_path": {
                                "type": "string",
                                "description": "目录路径",
                                "default": ""
                            }
                        }
                    }
                }
            }
        ]


class CodeExecutionTool:
    """代码执行工具"""
    
    def __init__(self, timeout: int = 30, sandbox: bool = True):
        self.timeout = timeout
        self.sandbox = sandbox
    
    def execute_python(self, code: str, input_data: str = None) -> Dict[str, Any]:
        """
        执行 Python 代码
        
        Args:
            code: Python 代码
            input_data: 输入数据（JSON 字符串）
        
        Returns:
            执行结果
        """
        try:
            # 创建临时文件
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(code)
                temp_file = f.name
            
            try:
                # 执行代码
                cmd = ["python3", temp_file]
                if input_data:
                    result = subprocess.run(
                        cmd,
                        input=input_data,
                        capture_output=True,
                        text=True,
                        timeout=self.timeout
                    )
                else:
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=self.timeout
                    )
                
                return {
                    "success": result.returncode == 0,
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "returncode": result.returncode
                }
                
            finally:
                # 清理临时文件
                os.unlink(temp_file)
                
        except subprocess.TimeoutExpired:
            return {"error": f"代码执行超时（>{self.timeout}秒）"}
        except Exception as e:
            return {"error": f"执行失败：{str(e)}"}
    
    def get_tool_definition(self) -> Dict:
        """返回工具定义"""
        return {
            "type": "function",
            "function": {
                "name": "execute_python",
                "description": "执行 Python 代码",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "code": {
                            "type": "string",
                            "description": "Python 代码"
                        },
                        "input_data": {
                            "type": "string",
                            "description": "输入数据（JSON 字符串）"
                        }
                    },
                    "required": ["code"]
                }
            }
        }


class CalculatorTool:
    """计算器工具"""
    
    def calculate(self, expression: str) -> Dict[str, Any]:
        """
        计算数学表达式
        
        Args:
            expression: 数学表达式
        
        Returns:
            计算结果
        """
        try:
            # 安全检查：只允许数字和基本运算符
            allowed_chars = set("0123456789+-*/.() ")
            if not all(c in allowed_chars for c in expression):
                return {"error": "非法字符，只允许数字和基本运算符"}
            
            result = eval(expression)
            return {
                "success": True,
                "expression": expression,
                "result": result
            }
            
        except Exception as e:
            return {"error": f"计算失败：{str(e)}"}
    
    def get_tool_definition(self) -> Dict:
        """返回工具定义"""
        return {
            "type": "function",
            "function": {
                "name": "calculate",
                "description": "计算数学表达式",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {
                            "type": "string",
                            "description": "数学表达式（如：2 + 3 * 4）"
                        }
                    },
                    "required": ["expression"]
                }
            }
        }


class ToolRegistry:
    """工具注册表"""
    
    def __init__(self, config: Dict = None):
        self.tools = {}
        self.config = config or {}
        
        # 初始化工具
        self._init_tools()
    
    def _init_tools(self):
        """初始化工具"""
        # 联网搜索
        search_config = self.config.get("web_search", {})
        if search_config.get("enabled", False):
            self.tools["web_search"] = WebSearchTool(
                api_key=os.getenv(search_config.get("api_key_env", "TAVILY_API_KEY")),
                max_results=search_config.get("max_results", 5)
            )
        
        # 文件操作
        file_config = self.config.get("file_operations", {})
        if file_config.get("enabled", False):
            self.tools["file_operations"] = FileOperationsTool(
                base_dir=file_config.get("base_dir", "./data")
            )
        
        # 代码执行
        code_config = self.config.get("code_execution", {})
        if code_config.get("enabled", False):
            self.tools["code_execution"] = CodeExecutionTool(
                timeout=code_config.get("timeout", 30),
                sandbox=code_config.get("sandbox", True)
            )
        
        # 计算器
        calc_config = self.config.get("calculator", {})
        if calc_config.get("enabled", False):
            self.tools["calculator"] = CalculatorTool()
    
    def get_tool(self, name: str):
        """获取工具"""
        return self.tools.get(name)
    
    def get_all_tools(self) -> List:
        """获取所有工具定义"""
        all_tools = []
        
        for tool in self.tools.values():
            if hasattr(tool, "get_tool_definition"):
                all_tools.append(tool.get_tool_definition())
            elif hasattr(tool, "get_tool_definitions"):
                all_tools.extend(tool.get_tool_definitions())
        
        return all_tools
    
    def execute_tool(self, name: str, method: str, **kwargs) -> Any:
        """执行工具方法"""
        tool = self.tools.get(name)
        if not tool:
            return {"error": f"工具不存在：{name}"}
        
        method_func = getattr(tool, method, None)
        if not method_func:
            return {"error": f"方法不存在：{method}"}
        
        return method_func(**kwargs)


# 全局工具注册表实例
_tool_registry: Optional[ToolRegistry] = None


def get_tool_registry(config: Dict = None) -> ToolRegistry:
    """获取全局工具注册表"""
    global _tool_registry
    
    if _tool_registry is None:
        _tool_registry = ToolRegistry(config)
    
    return _tool_registry


# 使用示例
if __name__ == "__main__":
    print("="*60)
    print("🔧 Agent 系统工具测试")
    print("="*60)
    
    # 创建工具注册表
    registry = ToolRegistry({
        "web_search": {"enabled": False},  # 需要 API Key
        "file_operations": {"enabled": True, "base_dir": "./data"},
        "code_execution": {"enabled": True},
        "calculator": {"enabled": True}
    })
    
    # 测试计算器
    print("\n🧮 测试计算器:")
    calc = registry.get_tool("calculator")
    result = calc.calculate("2 + 3 * 4")
    print(f"   2 + 3 * 4 = {result.get('result')}")
    
    # 测试文件操作
    print("\n📁 测试文件操作:")
    file_ops = registry.get_tool("file_operations")
    
    # 写入文件
    write_result = file_ops.write_file("test.txt", "Hello, World!")
    print(f"   写入文件：{write_result}")
    
    # 读取文件
    read_result = file_ops.read_file("test.txt")
    print(f"   读取文件：{read_result.get('content', '')}")
    
    # 测试代码执行
    print("\n💻 测试代码执行:")
    code_exec = registry.get_tool("code_execution")
    result = code_exec.execute_python("print('Hello from Python!')")
    print(f"   输出：{result.get('stdout', '')}")
    
    print("\n✅ 工具测试完成")
