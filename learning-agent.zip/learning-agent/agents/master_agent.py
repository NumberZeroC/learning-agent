#!/usr/bin/env python3
"""
主协调Agent

负责：
- 接收用户需求
- 分解任务
- 分配任务给子Agent（通过发布TaskAssignedEvent）
- 收集结果（订阅TaskCompletedEvent）
- 汇总输出
"""

import os
import json
import asyncio
import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path
from dataclasses import dataclass, field

from .event_driven_agent import EventDrivenAgent
from .event_system import (
    EventBus,
    Event,
    EventType,
    TaskAssignedEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    AgentStatusEvent,
    TaskPriority,
    get_event_bus
)
from .config_manager import get_config_manager, ConfigManager

try:
    from autogen import ConversableAgent
    AUTOGEN_AVAILABLE = True
except ImportError:
    AUTOGEN_AVAILABLE = False


# 知识框架定义
KNOWLEDGE_FRAMEWORK = {
    1: {
        "name": "基础理论层",
        "agent_name": "theory_worker",
        "topics": ["AI 基础", "LLM 原理", "Agent 概念", "架构模式"],
        "description": "涵盖人工智能、大语言模型、智能体系统的基础理论知识",
        "keywords": ["AI", "机器学习", "深度学习", "神经网络", "Transformer", "注意力机制", "预训练", "微调"]
    },
    2: {
        "name": "技术栈层",
        "agent_name": "tech_stack_worker",
        "topics": ["Python 编程", "Agent 框架", "向量数据库", "深度学习框架"],
        "description": "掌握开发AI Agent所需的编程语言和框架技术",
        "keywords": ["Python", "LangChain", "AutoGen", "Pinecone", "Milvus", "PyTorch", "TensorFlow", "向量"]
    },
    3: {
        "name": "核心能力层",
        "agent_name": "core_skill_worker",
        "topics": ["任务规划", "工具调用", "记忆管理", "多 Agent 协作"],
        "description": "培养Agent系统的核心开发能力",
        "keywords": ["规划", "ReAct", "CoT", "工具", "RAG", "记忆", "协作", "通信"]
    },
    4: {
        "name": "工程实践层",
        "agent_name": "engineering_worker",
        "topics": ["项目经验", "性能优化", "部署运维", "安全合规"],
        "description": "积累实际项目经验和工程化能力",
        "keywords": ["部署", "Docker", "Kubernetes", "性能", "优化", "监控", "安全", "合规"]
    },
    5: {
        "name": "面试准备层",
        "agent_name": "interview_worker",
        "topics": ["算法题", "系统设计", "行为面试", "项目阐述"],
        "description": "准备AI工程师面试相关内容",
        "keywords": ["算法", "LeetCode", "系统设计", "面试", "简历", "STAR"]
    }
}

# 架构类问题关键词
ARCHITECTURE_KEYWORDS = [
    "架构", "设计", "方案", "系统", "整体", "框架",
    "如何构建", "如何设计", "怎么搭建", "技术选型",
    "优缺点", "对比", "选择", "最佳实践",
    "架构模式", "设计模式", "微服务", "分布式"
]


@dataclass
class TaskInfo:
    """任务信息"""
    task_id: str
    layer: int
    content: str
    status: str = "pending"  # pending, running, completed, failed
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None


class MasterCoordinator(EventDrivenAgent):
    """
    主协调Agent
    
    职责：
    1. 接收用户的学习需求
    2. 分析需求并分解为子任务
    3. 为每个知识层创建任务并分配给对应的Worker
    4. 收集所有Worker的完成结果
    5. 汇总并生成最终学习路线
    """
    
    def __init__(
        self,
        config_path: str = "config/agent_config.yaml",
        event_bus: Optional[EventBus] = None,
        output_dir: str = "data/knowledge"
    ):
        # 配置管理器
        self.config_manager: ConfigManager = get_config_manager()
        self.config_manager.config_path = Path(config_path)
        self.config_manager.load_config()
        
        # 获取LLM配置
        llm_config = self.config_manager.get_llm_config("master_agent")
        
        # 系统提示词
        system_message = """你是 Learning Agent 系统的架构师 (Architect Agent)。

## 你的身份
你是资深AI系统架构师，拥有丰富的Agent系统设计和实践经验。你的核心职责是从架构层面解答用户问题，并在需要时协调专业子Agent处理具体知识点。

## 你的核心能力
作为架构师，你可以直接回答以下类型的问题：

### 1. 架构设计类问题（直接回答）
- Agent系统整体架构设计
- 技术方案选型与对比
- 系统设计方案
- 架构模式选择
- 技术栈组合建议
- 最佳实践指导

### 2. 具体知识点问题（委派给子Agent）
当用户询问具体知识点、学习内容、详细实现时，你需要：
- 分析问题属于哪个知识层
- 将任务分配给对应的专业子Agent
- 汇总子Agent的回答

## 子 Agent 列表与职责分工
| Agent | 层级 | 负责领域 |
|-------|------|----------|
| theory_worker | 第1层 | AI基础、LLM原理、Agent概念、架构模式的具体知识点 |
| tech_stack_worker | 第2层 | Python编程、Agent框架、向量数据库的实践细节 |
| core_skill_worker | 第3层 | 任务规划、工具调用、记忆管理的实现方法 |
| engineering_worker | 第4层 | 项目经验、性能优化、部署运维的具体实践 |
| interview_worker | 第5层 | 算法题、系统设计、面试准备的详细内容 |

## 回复原则
1. **架构类问题**：直接给出专业的架构建议，包括设计思路、技术选型、优缺点分析
2. **具体知识点问题**：先简要概述，然后说明"关于这个知识点的详细内容，我将请专业Agent为您解答"
3. **混合问题**：架构部分自己回答，知识点部分委派子Agent

## 架构师视角
- 从系统整体角度思考问题
- 关注可扩展性、可维护性、性能
- 提供多种方案对比
- 结合实际项目经验给出建议"""
        
        # 初始化父类
        super().__init__(
            name="master_agent",
            system_message=system_message,
            llm_config=llm_config,
            event_bus=event_bus,
            subscribed_events=[EventType.TASK_COMPLETED, EventType.TASK_FAILED]
        )
        
        # 输出目录
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 任务管理
        self._tasks: Dict[str, TaskInfo] = {}
        self._layer_tasks: Dict[int, str] = {}  # layer -> task_id
        self._results: Dict[int, Dict[str, Any]] = {}
        
        # 等待机制
        self._completion_event: Optional[asyncio.Event] = None
        self._expected_results: int = 0
        self._received_results: int = 0
        
        # 知识框架
        self.knowledge_framework = KNOWLEDGE_FRAMEWORK
        
        print(f"✅ 架构师Agent初始化完成")
        print(f"   管理层级: {len(self.knowledge_framework)}")
    
    def is_architecture_question(self, question: str) -> bool:
        """
        判断是否为架构类问题
        
        Args:
            question: 用户问题
            
        Returns:
            是否为架构类问题
        """
        question_lower = question.lower()
        
        # 检查架构关键词
        for keyword in ARCHITECTURE_KEYWORDS:
            if keyword in question:
                return True
        
        return False
    
    def identify_target_layer(self, question: str) -> Optional[int]:
        """
        识别问题应该由哪个层级的Agent处理
        
        Args:
            question: 用户问题
            
        Returns:
            层级编号，无法确定时返回None
        """
        question_lower = question.lower()
        
        # 根据关键词匹配层级
        layer_scores = {}
        for layer, framework in self.knowledge_framework.items():
            score = 0
            # 检查主题关键词
            for topic in framework.get('topics', []):
                if topic.lower() in question_lower:
                    score += 2
            # 检查扩展关键词
            for keyword in framework.get('keywords', []):
                if keyword.lower() in question_lower:
                    score += 1
            
            if score > 0:
                layer_scores[layer] = score
        
        # 返回得分最高的层级
        if layer_scores:
            return max(layer_scores, key=layer_scores.get)
        
        return None
    
    def answer_architecture_question(self, question: str) -> str:
        """
        直接回答架构类问题（通过 LLM）
        
        Args:
            question: 架构类问题
            
        Returns:
            架构师视角的回答
        """
        # 使用 LLM 生成回答
        return self._call_llm_for_architecture(question)
    
    def _call_llm_for_architecture(self, question: str) -> str:
        """通过 LLM 生成架构师回答"""
        system_prompt = """你是 Learning Agent 系统的架构师 (Architect Agent)。

## 你的身份
你是资深AI系统架构师，拥有丰富的Agent系统设计和实践经验。

## 你的职责
- 从架构层面解答用户问题
- 提供技术选型建议
- 给出最佳实践指导

## 回复原则
1. 给出专业的架构建议
2. 包含设计思路、技术选型、优缺点分析
3. 从系统整体角度思考问题
4. 关注可扩展性、可维护性、性能

## 回复格式
使用 Markdown 格式，包含：
- 问题分析
- 架构建议/技术对比
- 具体方案
- 注意事项"""
        
        prompt = f"""用户问题：{question}

请从架构师角度给出专业、详细的回答。"""
        
        # 使用 LLMService
        try:
            from services.llm_service import get_llm_service
            llm_service = get_llm_service()
            response = llm_service.call(prompt, system_prompt)
            return response.content
        except Exception as e:
            # 回退到硬编码回答
            return self._fallback_architecture_answer(question, str(e))
    
    def _fallback_architecture_answer(self, question: str, error: str = "") -> str:
        """LLM 不可用时的回退回答"""
        return f"""## 架构师回答

您的问题是：{question}

抱歉，LLM 服务暂时不可用。{'错误：' + error if error else ''}

请稍后重试或使用 Task 模式生成详细内容。"""
    
    def _generate_architecture_advice(self, question: str) -> str:
        """生成架构设计建议"""
        return f"""## 架构设计建议

针对您的问题「{question}」，我从架构师视角给出以下建议：

### 1. 系统架构设计原则

**分层架构**
- 表现层：用户交互界面
- 应用层：业务逻辑处理
- 领域层：核心业务实体
- 基础设施层：数据存储、外部服务

**Agent系统特有架构**
- 感知层：接收用户输入、环境信息
- 决策层：任务规划、策略选择
- 执行层：工具调用、动作执行
- 记忆层：短期记忆、长期知识库

### 2. 关键设计考量

| 维度 | 考量点 | 建议 |
|------|--------|------|
| 可扩展性 | Agent数量增长 | 采用事件驱动架构，支持动态扩容 |
| 可维护性 | 模块耦合度 | 明确接口边界，使用依赖注入 |
| 性能 | 响应延迟 | 异步处理、缓存策略、并发控制 |
| 可靠性 | 故障恢复 | 重试机制、降级策略、监控告警 |

### 3. 技术选型建议

**框架选择**
- AutoGen：适合多Agent协作，事件驱动
- LangChain：适合工具链集成，生态丰富
- CrewAI：适合任务编排，简洁易用

**存储选择**
- 向量数据库：Pinecone、Milvus、Chroma
- 关系数据库：PostgreSQL（支持pgvector）

如果您需要了解某个具体技术点的详细内容，请告诉我，我将安排专业Agent为您解答。"""
    
    def _generate_comparison_advice(self, question: str) -> str:
        """生成技术选型对比建议"""
        return f"""## 技术选型对比

针对「{question}」，我为您提供以下对比分析：

### Agent框架对比

| 特性 | AutoGen | LangChain | CrewAI |
|------|---------|-----------|--------|
| 核心优势 | 多Agent协作 | 工具生态丰富 | 简单易用 |
| 学习曲线 | 中等 | 较陡 | 平缓 |
| 适用场景 | 复杂协作任务 | RAG应用 | 任务编排 |
| 事件驱动 | ✅ 原生支持 | 需要扩展 | 基础支持 |
| 热更新 | ✅ 支持 | 需要自行实现 | 不支持 |

### 向量数据库对比

| 特性 | Pinecone | Milvus | Chroma |
|------|----------|--------|--------|
| 部署方式 | SaaS | 自托管/云 | 嵌入式 |
| 性能 | 优秀 | 优秀 | 良好 |
| 成本 | 按量付费 | 开源免费 | 免费 |
| 适用规模 | 中大型 | 大型 | 小型 |

### 选型建议

1. **初创项目**：LangChain + Chroma，快速验证
2. **中型项目**：AutoGen + Milvus，平衡功能和性能
3. **大型项目**：AutoGen + Pinecone/Milvus集群，保证扩展性

需要了解具体框架的使用细节，我可以安排专业Agent为您详细解答。"""
    
    def _generate_best_practices(self, question: str) -> str:
        """生成最佳实践建议"""
        return f"""## 最佳实践建议

针对「{question}」，我总结以下最佳实践：

### 1. Agent设计最佳实践

**单一职责原则**
- 每个Agent只负责一个明确的功能领域
- 避免Agent功能重叠和模糊边界

**清晰的接口定义**
- 使用结构化输入/输出
- 定义明确的工具接口
- 支持版本控制

### 2. 多Agent协作最佳实践

**通信模式选择**
- 点对点：适合简单的一对一交互
- 发布订阅：适合一对多、事件驱动
- 集中式协调：适合复杂工作流

**任务分解策略**
- 按功能域分解：每个Agent管理一个领域
- 按处理阶段分解：流水线模式
- 混合分解：结合两种方式

### 3. 性能优化最佳实践

**并发控制**
- 使用异步处理提高吞吐量
- 合理设置并发池大小
- 避免资源竞争

**缓存策略**
- 缓存频繁访问的知识
- 设置合理的TTL
- 实现缓存预热

### 4. 可观测性最佳实践

**日志记录**
- 记录关键决策点
- 记录工具调用和结果
- 实现链路追踪

**监控指标**
- 响应延迟分布
- Agent处理成功率
- 资源使用情况

如果您想深入了解某个具体实践点的实现细节，请告诉我。"""
    
    def _generate_general_architecture_advice(self, question: str) -> str:
        """生成通用架构建议"""
        return f"""## 架构师视角

您的问题「{question}」涉及系统架构层面，以下是我的建议：

### 核心考虑因素

1. **业务需求分析**
   - 明确核心业务场景
   - 识别关键性能指标
   - 确定扩展性需求

2. **技术架构选择**
   - 选择合适的Agent框架
   - 设计数据存储方案
   - 规划部署架构

3. **工程实践保障**
   - 建立CI/CD流程
   - 实现监控告警
   - 制定容灾方案

### 下一步建议

如果您需要了解：
- **具体技术细节**：我可以安排专业Agent为您解答
- **学习路径规划**：我可以为您设计系统学习方案
- **项目实践指导**：我可以提供工程化建议

请告诉我您更关注哪个方面？"""
    
    def decompose_task(self, user_request: str) -> Dict[int, str]:
        """
        分解用户需求为子任务
        
        Args:
            user_request: 用户请求
            
        Returns:
            层级 -> 子任务的映射
        """
        print(f"\n🔍 分解任务: {user_request}")
        
        subtasks = {}
        for layer, framework in self.knowledge_framework.items():
            subtasks[layer] = f"""
为"{framework['name']}"生成详细的学习内容。

主要主题：{', '.join(framework['topics'])}
描述：{framework['description']}

请生成包含以下内容的学习资料：
1. 每个主题的详细描述
2. 3-5个子主题
3. 每个子主题的关键知识点
4. 推荐学习资源
5. 估算学习时间
6. 难度级别

输出格式为JSON。
"""
        
        print(f"📋 任务分解完成: {len(subtasks)} 个子任务")
        return subtasks
    
    def assign_tasks_to_workers(
        self,
        subtasks: Dict[int, str],
        priority: TaskPriority = TaskPriority.NORMAL,
        context: Optional[Dict[str, Any]] = None
    ) -> List[str]:
        """
        将任务分配给Worker（发布TaskAssignedEvent）
        
        Args:
            subtasks: 层级 -> 子任务内容
            priority: 任务优先级
            context: 额外上下文
            
        Returns:
            创建的任务ID列表
        """
        task_ids = []
        
        print(f"\n📤 分配任务给Worker...")
        
        for layer, task_content in subtasks.items():
            framework = self.knowledge_framework[layer]
            task_id = f"task_{layer}_{uuid.uuid4().hex[:8]}"
            
            # 创建任务信息
            task_info = TaskInfo(
                task_id=task_id,
                layer=layer,
                content=task_content
            )
            self._tasks[task_id] = task_info
            self._layer_tasks[layer] = task_id
            
            # 创建并发布任务分配事件
            event = TaskAssignedEvent(
                sender=self.name,
                task_id=task_id,
                task_content=task_content,
                target_agent=framework["agent_name"],
                layer=layer,
                priority=priority,
                context=context or {}
            )
            
            self.event_bus.publish(event)
            task_ids.append(task_id)
            
            print(f"   📌 分配任务 {task_id} -> {framework['agent_name']} (第{layer}层)")
        
        self._expected_results = len(task_ids)
        self._received_results = 0
        
        return task_ids
    
    def on_task_assigned(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """
        主Agent不处理任务分配，只负责分配给Worker
        """
        return None
    
    def on_task_completed(self, event: TaskCompletedEvent):
        """
        处理任务完成事件
        
        收集Worker完成的结果
        """
        print(f"\n📥 [{self.name}] 收到任务完成: {event.task_id}")
        
        if event.task_id in self._tasks:
            self._tasks[event.task_id].status = "completed"
            self._tasks[event.task_id].result = event.result
            self._tasks[event.task_id].completed_at = datetime.now().isoformat()
        
        # 保存结果
        self._results[event.layer] = event.result
        self._received_results += 1
        
        print(f"   ✅ 第{event.layer}层结果已收集 ({self._received_results}/{self._expected_results})")
        
        # 检查是否所有任务都完成
        if self._received_results >= self._expected_results:
            print(f"\n🎉 所有任务完成！开始汇总...")
            self._finalize_results()
    
    def collect_results(self) -> Dict[int, Dict[str, Any]]:
        """
        收集所有任务结果
        
        Returns:
            层级 -> 结果的映射
        """
        return self._results.copy()
    
    def _finalize_results(self):
        """汇总所有结果并保存"""
        # 生成总结
        summary = self._generate_summary()
        
        # 保存各层级结果
        for layer, result in self._results.items():
            if result:
                output_file = self.output_dir / f"layer_{layer}_knowledge.json"
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                print(f"   💾 保存第{layer}层结果: {output_file}")
        
        # 保存总结
        summary_file = self.output_dir / "learning_summary.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(f"   💾 保存学习总结: {summary_file}")
    
    def _generate_summary(self) -> Dict[str, Any]:
        """生成学习路线总结"""
        summary = {
            "generated_at": datetime.now().isoformat(),
            "architecture": "event-driven",
            "total_layers": len(self.knowledge_framework),
            "agents": {
                "master": "master_agent",
                "workers": [f["agent_name"] for f in self.knowledge_framework.values()]
            },
            "layers": {},
            "total_hours": 0
        }
        
        for layer in sorted(self.knowledge_framework.keys()):
            framework = self.knowledge_framework[layer]
            result = self._results.get(layer, {})
            
            summary["layers"][str(layer)] = {
                "name": framework["name"],
                "agent": framework["agent_name"],
                "topics_count": len(result.get("topics", [])),
                "total_hours": result.get("total_hours", 0),
                "status": "completed" if result else "pending"
            }
            summary["total_hours"] += result.get("total_hours", 0)
        
        return summary
    
    async def execute_request_async(
        self,
        user_request: str,
        priority: TaskPriority = TaskPriority.NORMAL
    ) -> Dict[str, Any]:
        """
        异步执行用户请求
        
        Args:
            user_request: 用户请求
            priority: 任务优先级
            
        Returns:
            执行结果
        """
        # 分解任务
        subtasks = self.decompose_task(user_request)
        
        # 分配任务
        task_ids = self.assign_tasks_to_workers(subtasks, priority)
        
        # 等待所有结果（带超时）
        max_wait = 300  # 5分钟超时
        start_time = datetime.now()
        
        while self._received_results < self._expected_results:
            await asyncio.sleep(1)
            elapsed = (datetime.now() - start_time).total_seconds()
            if elapsed > max_wait:
                print(f"⚠️ 等待超时，已收集 {self._received_results}/{self._expected_results} 个结果")
                break
        
        return self.collect_results()
    
    def execute_request(
        self,
        user_request: str,
        priority: TaskPriority = TaskPriority.NORMAL
    ) -> Dict[str, Any]:
        """
        同步执行用户请求
        
        Args:
            user_request: 用户请求
            priority: 任务优先级
            
        Returns:
            执行结果
        """
        return asyncio.run(self.execute_request_async(user_request, priority))
    
    def get_task_status(self) -> Dict[str, Any]:
        """获取所有任务状态"""
        return {
            "total_tasks": len(self._tasks),
            "pending": sum(1 for t in self._tasks.values() if t.status == "pending"),
            "running": sum(1 for t in self._tasks.values() if t.status == "running"),
            "completed": sum(1 for t in self._tasks.values() if t.status == "completed"),
            "failed": sum(1 for t in self._tasks.values() if t.status == "failed"),
            "results_received": self._received_results,
            "results_expected": self._expected_results
        }
    
    def print_architecture(self):
        """打印架构信息"""
        print("\n" + "="*60)
        print("🏗️ 事件驱动架构")
        print("="*60)
        
        print("""
┌─────────────────────────────────────────────────────────┐
│                    Event Bus                             │
│            (发布-订阅模式)                               │
└─────────────────────────────────────────────────────────┘
                         │
         ┌───────────────┼───────────────┐
         │               │               │
         ▼               ▼               ▼
┌───────────────┐                              ┌───────────────┐
│Master Agent   │                              │ Worker Agent  │
│(发布者/订阅者) │──────────────────────────────▶│ (订阅者)      │
│               │◀──────────────────────────────│               │
│ master_agent  │   TaskAssignedEvent          │ theory_worker │
└───────────────┘   TaskCompletedEvent          └───────────────┘
                                                     ...
                                              ┌───────────────┐
                                              │interview_worker│
                                              └───────────────┘

事件流程:
1. Master 发布 TaskAssignedEvent
2. Worker 订阅并处理任务
3. Worker 发布 TaskCompletedEvent
4. Master 收集结果并汇总
""")