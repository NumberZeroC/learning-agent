#!/usr/bin/env python3
"""
事件驱动Agent基类

提供支持事件机制的Agent基类：
- EventDrivenAgent: 继承ConversableAgent，增加事件处理能力
- 支持订阅/发布事件
- 支持异步事件处理
"""

import asyncio
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
import threading
from abc import abstractmethod

try:
    from autogen import ConversableAgent
    AUTOGEN_AVAILABLE = True
except ImportError:
    print("⚠️ 未安装 AutoGen，请运行：pip install pyautogen")
    AUTOGEN_AVAILABLE = False
    ConversableAgent = object

from .event_system import (
    EventBus,
    Event,
    EventType,
    TaskAssignedEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    AgentStatusEvent,
    ProgressUpdateEvent,
    AgentStatus,
    get_event_bus
)


class EventDrivenAgent(ConversableAgent if AUTOGEN_AVAILABLE else object):
    """
    事件驱动Agent基类
    
    特性：
    - 继承AutoGen的ConversableAgent
    - 支持事件订阅和发布
    - 支持异步事件处理
    - 自动状态管理
    """
    
    def __init__(
        self,
        name: str,
        system_message: str,
        llm_config: Dict[str, Any],
        event_bus: Optional[EventBus] = None,
        subscribed_events: Optional[List[EventType]] = None,
        **kwargs
    ):
        # 初始化父类
        if AUTOGEN_AVAILABLE:
            super().__init__(
                name=name,
                system_message=system_message,
                llm_config=llm_config,
                human_input_mode="NEVER",
                **kwargs
            )
        else:
            self.name = name
            self.system_message = system_message
        
        # 事件系统
        self.event_bus = event_bus or get_event_bus()
        self.subscribed_events = subscribed_events or []
        
        # 状态管理
        self._status = AgentStatus.IDLE
        self._current_task_id: Optional[str] = None
        self._progress: float = 0.0
        
        # 任务处理
        self._pending_tasks: Dict[str, TaskAssignedEvent] = {}
        self._completed_tasks: Dict[str, Dict[str, Any]] = {}
        
        # 异步支持
        self._event_loop: Optional[asyncio.AbstractEventLoop] = None
        self._worker_thread: Optional[threading.Thread] = None
        
        # 注册事件处理器
        self._register_event_handlers()
        
        print(f"✅ 创建事件驱动Agent: {name}")
    
    def _register_event_handlers(self):
        """注册事件处理器"""
        # 默认订阅任务分配事件
        if EventType.TASK_ASSIGNED not in self.subscribed_events:
            self.subscribed_events.append(EventType.TASK_ASSIGNED)
        
        # 注册处理器
        for event_type in self.subscribed_events:
            if event_type == EventType.TASK_ASSIGNED:
                self.event_bus.subscribe(event_type, self._on_task_assigned_wrapper)
            elif event_type == EventType.TASK_COMPLETED:
                self.event_bus.subscribe(event_type, self._on_task_completed_wrapper)
    
    def _on_task_assigned_wrapper(self, event: Event):
        """任务分配事件处理包装器"""
        if isinstance(event, TaskAssignedEvent):
            # 检查是否是发给自己的的任务
            if event.target_agent == self.name or event.target_agent == "all":
                print(f"\n📬 [{self.name}] 收到任务: {event.task_id}")
                self._handle_task_assigned(event)
    
    def _on_task_completed_wrapper(self, event: Event):
        """任务完成事件处理包装器"""
        if isinstance(event, TaskCompletedEvent):
            self._handle_task_completed(event)
    
    def _handle_task_assigned(self, event: TaskAssignedEvent):
        """
        处理任务分配事件（内部方法）
        
        子类应该实现 on_task_assigned 方法
        """
        self._status = AgentStatus.BUSY
        self._current_task_id = event.task_id
        self._pending_tasks[event.task_id] = event
        
        # 发布状态更新
        self.publish_status(AgentStatus.BUSY, event.task_id, 0.0, f"开始处理任务: {event.task_content[:50]}...")
        
        try:
            # 调用子类实现的处理方法
            result = self.on_task_assigned(event)
            
            if result:
                self._completed_tasks[event.task_id] = result
                self._publish_task_completed(event, result)
            else:
                self._publish_task_failed(event, "任务处理返回空结果")
                
        except Exception as e:
            print(f"❌ [{self.name}] 任务处理失败: {e}")
            self._publish_task_failed(event, str(e))
        
        finally:
            self._status = AgentStatus.IDLE
            self._current_task_id = None
            self._progress = 0.0
            self.publish_status(AgentStatus.IDLE, None, 1.0, "任务完成")
    
    def _handle_task_completed(self, event: TaskCompletedEvent):
        """
        处理任务完成事件（内部方法）
        
        子类可以重写 on_task_completed 方法
        """
        self.on_task_completed(event)
    
    @abstractmethod
    def on_task_assigned(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """
        处理任务分配事件（抽象方法）
        
        子类必须实现此方法
        
        Args:
            event: 任务分配事件
            
        Returns:
            任务处理结果，返回None表示失败
        """
        raise NotImplementedError("子类必须实现 on_task_assigned 方法")
    
    def on_task_completed(self, event: TaskCompletedEvent):
        """
        处理任务完成事件
        
        子类可以重写此方法来处理其他Agent完成的任务
        
        Args:
            event: 任务完成事件
        """
        pass
    
    def _publish_task_completed(self, task_event: TaskAssignedEvent, result: Dict[str, Any]):
        """发布任务完成事件"""
        completed_event = TaskCompletedEvent(
            sender=self.name,
            task_id=task_event.task_id,
            result=result,
            source_agent=self.name,
            layer=task_event.layer,
            success=True
        )
        self.event_bus.publish(completed_event)
        print(f"✅ [{self.name}] 任务完成: {task_event.task_id}")
    
    def _publish_task_failed(self, task_event: TaskAssignedEvent, error: str):
        """发布任务失败事件"""
        failed_event = TaskFailedEvent(
            sender=self.name,
            task_id=task_event.task_id,
            error=error,
            source_agent=self.name
        )
        self.event_bus.publish(failed_event)
        print(f"❌ [{self.name}] 任务失败: {task_event.task_id} - {error}")
    
    def publish_status(
        self,
        status: AgentStatus,
        current_task: Optional[str] = None,
        progress: float = 0.0,
        message: str = ""
    ):
        """发布Agent状态事件"""
        self._status = status
        self._progress = progress
        
        status_event = AgentStatusEvent(
            sender=self.name,
            agent_name=self.name,
            status=status,
            current_task=current_task,
            progress=progress,
            message=message
        )
        self.event_bus.publish(status_event)
    
    def publish_progress(
        self,
        task_id: str,
        progress: float,
        message: str = "",
        current_step: str = ""
    ):
        """发布进度更新事件"""
        self._progress = progress
        
        progress_event = ProgressUpdateEvent(
            sender=self.name,
            task_id=task_id,
            agent_name=self.name,
            progress=progress,
            message=message,
            current_step=current_step
        )
        self.event_bus.publish(progress_event)
    
    def publish_event(self, event: Event):
        """发布任意事件"""
        event.sender = self.name
        self.event_bus.publish(event)
    
    def get_status(self) -> Dict[str, Any]:
        """获取Agent当前状态"""
        return {
            "name": self.name,
            "status": self._status.value,
            "current_task": self._current_task_id,
            "progress": self._progress,
            "pending_tasks": len(self._pending_tasks),
            "completed_tasks": len(self._completed_tasks)
        }
    
    def get_completed_results(self) -> Dict[str, Dict[str, Any]]:
        """获取所有已完成的任务结果"""
        return self._completed_tasks.copy()


class AsyncEventDrivenAgent(EventDrivenAgent):
    """
    异步事件驱动Agent基类
    
    支持异步任务处理
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._async_tasks: Dict[str, asyncio.Task] = {}
    
    async def handle_task_async(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """
        异步处理任务
        
        子类应该实现此方法
        
        Args:
            event: 任务分配事件
            
        Returns:
            任务处理结果
        """
        raise NotImplementedError("子类必须实现 handle_task_async 方法")
    
    def on_task_assigned(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """同步包装器，启动异步处理"""
        self._status = AgentStatus.BUSY
        self._current_task_id = event.task_id
        
        try:
            # 尝试在现有事件循环中运行
            try:
                loop = asyncio.get_running_loop()
                # 如果已有运行中的循环，创建任务
                task = asyncio.create_task(self.handle_task_async(event))
                self._async_tasks[event.task_id] = task
            except RuntimeError:
                # 没有运行中的循环，创建新的
                result = asyncio.run(self.handle_task_async(event))
                return result
        except Exception as e:
            print(f"❌ 异步任务处理失败: {e}")
            return None
    
    async def wait_for_all_tasks(self):
        """等待所有异步任务完成"""
        if self._async_tasks:
            await asyncio.gather(*self._async_tasks.values(), return_exceptions=True)
            self._async_tasks.clear()