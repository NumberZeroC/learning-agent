#!/usr/bin/env python3
"""
事件系统核心模块

提供事件驱动架构的基础设施：
- Event: 事件基类
- TaskAssignedEvent: 任务分配事件
- TaskCompletedEvent: 任务完成事件
- AgentStatusEvent: Agent状态事件
- EventBus: 事件总线（发布-订阅模式）
"""

import uuid
import asyncio
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable, Set
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import threading


class EventType(Enum):
    """事件类型枚举"""
    TASK_ASSIGNED = "task_assigned"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    AGENT_STATUS = "agent_status"
    AGENT_REGISTERED = "agent_registered"
    AGENT_UNREGISTERED = "agent_unregistered"
    PROGRESS_UPDATE = "progress_update"


class TaskPriority(Enum):
    """任务优先级"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    URGENT = 4


class AgentStatus(Enum):
    """Agent状态"""
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    OFFLINE = "offline"


@dataclass
class Event:
    """事件基类"""
    event_type: EventType
    sender: str
    data: Dict[str, Any]
    event_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "sender": self.sender,
            "timestamp": self.timestamp,
            "data": self.data
        }


@dataclass
class TaskAssignedEvent(Event):
    """任务分配事件
    
    主Agent发布此事件将任务分配给子Agent
    """
    task_id: str = ""
    task_content: str = ""
    target_agent: str = ""
    layer: int = 0
    priority: TaskPriority = TaskPriority.NORMAL
    deadline: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        self.event_type = EventType.TASK_ASSIGNED
        self.data = {
            "task_id": self.task_id,
            "task_content": self.task_content,
            "target_agent": self.target_agent,
            "layer": self.layer,
            "priority": self.priority.value,
            "deadline": self.deadline,
            "context": self.context
        }


@dataclass
class TaskCompletedEvent(Event):
    """任务完成事件
    
    子Agent完成处理后发布此事件
    """
    task_id: str = ""
    result: Dict[str, Any] = field(default_factory=dict)
    source_agent: str = ""
    layer: int = 0
    execution_time: float = 0.0
    success: bool = True
    error_message: Optional[str] = None
    
    def __post_init__(self):
        self.event_type = EventType.TASK_COMPLETED
        self.data = {
            "task_id": self.task_id,
            "result": self.result,
            "source_agent": self.source_agent,
            "layer": self.layer,
            "execution_time": self.execution_time,
            "success": self.success,
            "error_message": self.error_message
        }


@dataclass
class TaskFailedEvent(Event):
    """任务失败事件"""
    task_id: str = ""
    error: str = ""
    source_agent: str = ""
    retry_count: int = 0
    
    def __post_init__(self):
        self.event_type = EventType.TASK_FAILED
        self.data = {
            "task_id": self.task_id,
            "error": self.error,
            "source_agent": self.source_agent,
            "retry_count": self.retry_count
        }


@dataclass
class AgentStatusEvent(Event):
    """Agent状态事件"""
    agent_name: str = ""
    status: AgentStatus = AgentStatus.IDLE
    current_task: Optional[str] = None
    progress: float = 0.0
    message: str = ""
    
    def __post_init__(self):
        self.event_type = EventType.AGENT_STATUS
        self.data = {
            "agent_name": self.agent_name,
            "status": self.status.value,
            "current_task": self.current_task,
            "progress": self.progress,
            "message": self.message
        }


@dataclass
class ProgressUpdateEvent(Event):
    """进度更新事件"""
    task_id: str = ""
    agent_name: str = ""
    progress: float = 0.0
    message: str = ""
    current_step: str = ""
    
    def __post_init__(self):
        self.event_type = EventType.PROGRESS_UPDATE
        self.data = {
            "task_id": self.task_id,
            "agent_name": self.agent_name,
            "progress": self.progress,
            "message": self.message,
            "current_step": self.current_step
        }


# 回调函数类型
EventHandler = Callable[[Event], None]
AsyncEventHandler = Callable[[Event], asyncio.coroutine]


class EventBus:
    """
    事件总线 - 发布订阅模式实现
    
    支持：
    - 同步和异步事件处理
    - 按事件类型订阅
    - 按Agent名称订阅
    - 事件历史记录
    - 线程安全
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized') and self._initialized:
            return
        
        # 订阅者：事件类型 -> 回调函数列表
        self._subscribers: Dict[EventType, List[EventHandler]] = defaultdict(list)
        # Agent特定订阅：Agent名称 -> 回调函数
        self._agent_subscribers: Dict[str, List[EventHandler]] = defaultdict(list)
        # 异步订阅者
        self._async_subscribers: Dict[EventType, List[AsyncEventHandler]] = defaultdict(list)
        # 事件历史
        self._event_history: List[Event] = []
        self._max_history = 1000
        # 事件循环（用于异步处理）
        self._event_queue: asyncio.Queue = None
        self._running = False
        
        self._initialized = True
        print("✅ EventBus 初始化完成")
    
    def subscribe(self, event_type: EventType, handler: EventHandler) -> str:
        """
        订阅事件
        
        Args:
            event_type: 事件类型
            handler: 事件处理函数
            
        Returns:
            订阅ID（用于取消订阅）
        """
        self._subscribers[event_type].append(handler)
        handler_id = f"{event_type.value}_{len(self._subscribers[event_type])}"
        print(f"📥 订阅事件: {event_type.value} -> {handler.__name__ if hasattr(handler, '__name__') else handler_id}")
        return handler_id
    
    def subscribe_for_agent(self, agent_name: str, handler: EventHandler) -> str:
        """
        为特定Agent订阅事件
        
        Args:
            agent_name: Agent名称
            handler: 事件处理函数
            
        Returns:
            订阅ID
        """
        self._agent_subscribers[agent_name].append(handler)
        handler_id = f"agent_{agent_name}_{len(self._agent_subscribers[agent_name])}"
        print(f"📥 Agent订阅: {agent_name}")
        return handler_id
    
    def subscribe_async(self, event_type: EventType, handler: AsyncEventHandler) -> str:
        """
        订阅异步事件处理
        
        Args:
            event_type: 事件类型
            handler: 异步事件处理函数
            
        Returns:
            订阅ID
        """
        self._async_subscribers[event_type].append(handler)
        handler_id = f"async_{event_type.value}_{len(self._async_subscribers[event_type])}"
        print(f"📥 异步订阅事件: {event_type.value}")
        return handler_id
    
    def unsubscribe(self, handler_id: str) -> bool:
        """
        取消订阅
        
        Args:
            handler_id: 订阅ID
            
        Returns:
            是否成功
        """
        # 简化实现：找到并移除对应的handler
        parts = handler_id.split('_')
        if len(parts) >= 2:
            event_type_str = '_'.join(parts[:-1])
            try:
                event_type = EventType(event_type_str)
                if event_type in self._subscribers:
                    self._subscribers[event_type].clear()
                    print(f"📤 取消订阅: {event_type_str}")
                    return True
            except ValueError:
                pass
        return False
    
    def publish(self, event: Event) -> int:
        """
        发布事件（同步）
        
        Args:
            event: 事件对象
            
        Returns:
            接收到事件的订阅者数量
        """
        # 记录历史
        self._event_history.append(event)
        if len(self._event_history) > self._max_history:
            self._event_history.pop(0)
        
        count = 0
        
        # 通知该事件类型的所有订阅者
        if event.event_type in self._subscribers:
            for handler in self._subscribers[event.event_type]:
                try:
                    handler(event)
                    count += 1
                except Exception as e:
                    print(f"❌ 事件处理错误: {e}")
        
        # 通知Agent特定订阅者
        if hasattr(event, 'target_agent') and event.target_agent:
            if event.target_agent in self._agent_subscribers:
                for handler in self._agent_subscribers[event.target_agent]:
                    try:
                        handler(event)
                        count += 1
                    except Exception as e:
                        print(f"❌ Agent事件处理错误: {e}")
        
        print(f"📢 发布事件: {event.event_type.value} (ID: {event.event_id}, 接收者: {count})")
        return count
    
    async def publish_async(self, event: Event) -> int:
        """
        发布事件（异步）
        
        Args:
            event: 事件对象
            
        Returns:
            接收到事件的订阅者数量
        """
        # 记录历史
        self._event_history.append(event)
        if len(self._event_history) > self._max_history:
            self._event_history.pop(0)
        
        count = 0
        
        # 通知异步订阅者
        if event.event_type in self._async_subscribers:
            tasks = []
            for handler in self._async_subscribers[event.event_type]:
                tasks.append(handler(event))
            
            if tasks:
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for r in results:
                    if isinstance(r, Exception):
                        print(f"❌ 异步事件处理错误: {r}")
                    else:
                        count += 1
        
        # 同时通知同步订阅者
        if event.event_type in self._subscribers:
            for handler in self._subscribers[event.event_type]:
                try:
                    handler(event)
                    count += 1
                except Exception as e:
                    print(f"❌ 事件处理错误: {e}")
        
        print(f"📢 异步发布事件: {event.event_type.value} (ID: {event.event_id}, 接收者: {count})")
        return count
    
    def get_history(self, event_type: Optional[EventType] = None, limit: int = 10) -> List[Event]:
        """
        获取事件历史
        
        Args:
            event_type: 可选的事件类型过滤
            limit: 返回数量限制
            
        Returns:
            事件列表
        """
        if event_type:
            events = [e for e in self._event_history if e.event_type == event_type]
        else:
            events = self._event_history.copy()
        
        return events[-limit:]
    
    def clear_history(self):
        """清除事件历史"""
        self._event_history.clear()
        print("🗑️ 事件历史已清除")
    
    def get_stats(self) -> Dict[str, Any]:
        """获取事件总线统计信息"""
        return {
            "total_events": len(self._event_history),
            "subscriber_count": sum(len(handlers) for handlers in self._subscribers.values()),
            "async_subscriber_count": sum(len(handlers) for handlers in self._async_subscribers.values()),
            "agent_subscribers": list(self._agent_subscribers.keys()),
            "event_types": list(self._subscribers.keys())
        }


# 全局事件总线实例
_event_bus: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    """获取全局事件总线实例"""
    global _event_bus
    if _event_bus is None:
        _event_bus = EventBus()
    return _event_bus


def reset_event_bus():
    """重置事件总线（用于测试）"""
    global _event_bus
    _event_bus = None