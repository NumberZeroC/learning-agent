#!/usr/bin/env python3
"""
Learning Agent - AutoGen 主从架构（简化演示版）

无需真实 API 调用，模拟主从 Agent 协作流程
用于演示架构设计和工作流程
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List


class MasterAgent:
    """主 Agent - 负责任务协调"""
    
    def __init__(self):
        self.name = "master_agent"
        self.role = "主协调者"
        self.worker_agents = {}
    
    def register_worker(self, worker: 'WorkerAgent'):
        """注册子 Agent"""
        self.worker_agents[worker.layer] = worker
        print(f"📝 注册子 Agent: {worker.name} (第{worker.layer}层)")
    
    def decompose_task(self, task: str) -> Dict[int, str]:
        """任务分解"""
        print(f"\n🔍 主 Agent 分解任务：{task}")
        
        subtasks = {
            1: "生成第 1 层（基础理论层）的详细学习内容",
            2: "生成第 2 层（技术栈层）的详细学习内容",
            3: "生成第 3 层（核心能力层）的详细学习内容",
            4: "生成第 4 层（工程实践层）的详细学习内容",
            5: "生成第 5 层（面试准备层）的详细学习内容"
        }
        
        print("📋 任务分解完成，分配给 5 个子 Agent\n")
        return subtasks
    
    def collect_results(self, results: Dict[int, Dict]) -> Dict:
        """汇总结果"""
        print("\n📥 主 Agent 汇总结果...")
        
        summary = {
            "generated_at": datetime.now().isoformat(),
            "architecture": "master-worker",
            "coordinator": self.name,
            "total_layers": len(results),
            "workers": [w.name for w in self.worker_agents.values()],
            "layers": {},
            "total_hours": 0
        }
        
        for layer, data in results.items():
            summary["layers"][str(layer)] = {
                "name": data.get("layer_name", ""),
                "agent": self.worker_agents[layer].name,
                "topics_count": len(data.get("topics", [])),
                "total_hours": data.get("total_hours", 0)
            }
            summary["total_hours"] += data.get("total_hours", 0)
        
        print(f"✅ 汇总完成：{len(results)} 层，总计 {summary['total_hours']} 小时")
        return summary


class WorkerAgent:
    """子 Agent - 负责具体知识层"""
    
    def __init__(self, name: str, layer: int, role: str, topics: List[str]):
        self.name = name
        self.layer = layer
        self.role = role
        self.topics = topics
    
    def generate_knowledge(self, task: str) -> Dict:
        """生成知识内容（从 generator.py 加载）"""
        print(f"🤖 {self.name} 执行任务：{task}")
        
        # 从已生成的数据中加载
        data_file = Path("data/knowledge") / f"layer_{self.layer}_knowledge.json"
        
        if data_file.exists():
            with open(data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            print(f"⚠️ 数据文件不存在：{data_file}")
            return {
                "layer": self.layer,
                "layer_name": f"第{self.layer}层",
                "topics": [],
                "total_hours": 0
            }


class LearningAgentSystem:
    """Learning Agent 系统（主从架构）"""
    
    def __init__(self):
        self.master = MasterAgent()
        self.workers = {}
        self.data_dir = Path("data/knowledge")
    
    def initialize(self):
        """初始化系统"""
        print("="*60)
        print("🤖 Learning Agent - AutoGen 主从架构（简化版）")
        print("="*60)
        
        # 创建子 Agent
        worker_configs = [
            ("theory_worker", 1, "基础理论专家", ["AI 基础", "LLM 原理", "Agent 概念", "架构模式"]),
            ("tech_stack_worker", 2, "技术栈专家", ["Python 编程", "Agent 框架", "向量数据库", "深度学习框架"]),
            ("core_skill_worker", 3, "核心能力专家", ["任务规划", "工具调用", "记忆管理", "多 Agent 协作"]),
            ("engineering_worker", 4, "工程实践专家", ["项目经验", "性能优化", "部署运维", "安全合规"]),
            ("interview_worker", 5, "面试准备专家", ["算法题", "系统设计", "行为面试", "项目阐述"])
        ]
        
        for name, layer, role, topics in worker_configs:
            worker = WorkerAgent(name, layer, role, topics)
            self.workers[layer] = worker
            self.master.register_worker(worker)
        
        print("\n✅ 系统初始化完成")
        print(f"   主 Agent: 1 个 ({self.master.name})")
        print(f"   子 Agent: {len(self.workers)}个")
        print(f"   知识层级：{len(self.workers)}层")
    
    def execute_task(self, task: str = "生成完整的 Agent 开发学习路线"):
        """执行任务"""
        print(f"\n📋 任务：{task}\n")
        print("="*60)
        print("🔄 开始执行任务流程")
        print("="*60)
        
        # 步骤 1: 主 Agent 分解任务
        subtasks = self.master.decompose_task(task)
        
        # 步骤 2: 子 Agent 并行执行
        results = {}
        print("="*60)
        print("🤖 子 Agent 执行任务")
        print("="*60)
        
        for layer, subtask in subtasks.items():
            worker = self.workers[layer]
            result = worker.generate_knowledge(subtask)
            results[layer] = result
            
            if result.get("topics"):
                print(f"✅ {worker.name} 完成：{len(result['topics'])} 个主题，{result['total_hours']} 小时\n")
        
        # 步骤 3: 主 Agent 汇总结果
        print("="*60)
        summary = self.master.collect_results(results)
        
        # 步骤 4: 保存总结
        summary_file = self.data_dir / "autogen_summary.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        print(f"\n📄 总结已保存：{summary_file}")
        
        return summary
    
    def print_architecture(self):
        """打印架构信息"""
        print("\n" + "="*60)
        print("🏗️ 系统架构")
        print("="*60)
        
        print(f"""
┌─────────────────────────────────────────────────────────┐
│                    Master Agent                         │
│                   (master_agent)                        │
│                   主协调者                              │
└─────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ theory_worker │   │tech_stack_worker│ │core_skill_worker│
│   第 1 层       │   │    第 2 层       │   │    第 3 层       │
└───────────────┘   └───────────────┘   └───────────────┘
        │                   │                   │
        └───────────────────┼───────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│engineering_worker│ │interview_worker │
│    第 4 层         │ │    第 5 层         │
└─────────────────┘ └─────────────────┘

架构特点:
- 1 个主 Agent 负责任务分解和协调
- 5 个子 Agent 各自负责一个知识层
- 所有 Agent 都可独立调用大模型
- 主从协作，高效并行
""")


def main():
    """主函数"""
    # 创建系统
    system = LearningAgentSystem()
    
    # 初始化
    system.initialize()
    
    # 打印架构
    system.print_architecture()
    
    # 执行任务
    summary = system.execute_task()
    
    # 输出结果
    print("\n" + "="*60)
    print("✅ 任务完成！")
    print("="*60)
    print(f"""
📊 学习路线总结:
   架构：Master-Worker (主从架构)
   Agent 总数：1 个主 Agent + 5 个子 Agent
   知识层级：{summary['total_layers']}层
   总主题数：{sum(l['topics_count'] for l in summary['layers'].values())}个
   预计总时长：{summary['total_hours']} 小时
   建议周期：约 3-4 个月（每天 3 小时）

📁 数据目录：{system.data_dir.absolute()}
📄 总结文件：autogen_summary.json
""")


if __name__ == "__main__":
    main()
