#!/usr/bin/env python3
"""
AutoGen 主从架构 - 支持多模型配置和热更新

特性：
- 每个 Agent 独立配置不同的大模型
- 配置文件控制
- 支持热更新（无需重启）
- 配置变更自动应用
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

# 导入配置管理器
from .config_manager import get_config_manager, ConfigManager

# 导入工具
from .agent_tools import get_tool_registry, ToolRegistry

try:
    from autogen import ConversableAgent, UserProxyAgent, GroupChat, GroupChatManager
    AUTOGEN_AVAILABLE = True
except ImportError:
    print("⚠️ 未安装 AutoGen，请运行：pip install pyautogen")
    AUTOGEN_AVAILABLE = False


class MultiModelLearningAgent:
    """支持多模型的 Learning Agent 系统"""
    
    def __init__(self, config_path: str = "config/agent_config.yaml"):
        self.config_manager: ConfigManager = get_config_manager()
        self.config_manager.config_path = Path(config_path)
        self.config_manager.load_config()
        
        self.data_dir = Path("data/knowledge")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # 初始化工具注册表
        tools_config = self.config_manager.get_config("tools", {})
        self.tool_registry: ToolRegistry = get_tool_registry(tools_config)
        
        # Agent 实例
        self.master_agent = None
        self.worker_agents = {}
        self.user_proxy = None
        
        # Agent 配置缓存
        self.agent_llm_configs = {}
        
        # 注册配置变更回调
        self._register_config_callbacks()
    
    def _register_config_callbacks(self):
        """注册配置变更回调"""
        # 为每个 Agent 注册回调
        agents_config = self.config_manager.get_config("agents", {})
        
        for agent_name in agents_config.keys():
            self.config_manager.register_callback(
                agent_name,
                lambda key, old, new, name=agent_name: self._on_agent_config_changed(name, key, old, new)
            )
        
        # 全局回调
        self.config_manager.register_callback("global", self._on_global_config_changed)
    
    def _on_agent_config_changed(self, agent_name: str, key: str, old_value: Any, new_value: Any):
        """Agent 配置变更回调"""
        print(f"\n🔔 Agent 配置变更：{agent_name}.{key}")
        print(f"   旧值：{old_value}")
        print(f"   新值：{new_value}")
        
        # 如果支持热更新，重新创建 Agent
        agent_config = self.config_manager.get_agent_config(agent_name)
        if agent_config.get('hot_reload', True):
            print(f"🔄 热更新 Agent: {agent_name}")
            self._reload_agent(agent_name)
    
    def _on_global_config_changed(self, key: str, old_value: Any, new_value: Any):
        """全局配置变更回调"""
        print(f"\n🔔 全局配置变更：{key}")
        self.config_manager.load_config()
    
    def _reload_agent(self, agent_name: str):
        """重新创建 Agent（热更新）"""
        if agent_name == "master_agent" and self.master_agent:
            print(f"♻️ 重新创建主 Agent")
            self.master_agent = self._create_master_agent_instance()
        
        elif agent_name.endswith("_worker") and agent_name in self.worker_agents:
            layer = None
            for l, agent in self.worker_agents.items():
                if agent.name == agent_name:
                    layer = l
                    break
            
            if layer:
                print(f"♻️ 重新创建子 Agent: {agent_name} (第{layer}层)")
                self.worker_agents[layer] = self._create_worker_agent_instance(layer)
    
    def create_llm_config(self, agent_name: str) -> Dict:
        """为 Agent 创建 LLM 配置"""
        return self.config_manager.get_llm_config(agent_name)
    
    def create_user_proxy(self):
        """创建用户代理"""
        if not AUTOGEN_AVAILABLE:
            return None
        
        self.user_proxy = UserProxyAgent(
            name="user_proxy",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=0,
            code_execution_config=False
        )
        
        print("✅ 创建用户代理：user_proxy")
        return self.user_proxy
    
    def _create_master_agent_instance(self) -> ConversableAgent:
        """创建主 Agent 实例"""
        llm_config = self.create_llm_config("master_agent")
        
        system_message = """你是 Learning Agent 系统的主协调者 (Master Agent)。

## 你的职责
1. 接收用户的学习需求
2. 分析需求并分解任务
3. 协调 5 个子 Agent 完成各自负责的知识层
4. 汇总结果并输出完整学习路线

## 子 Agent 列表
- theory_worker: 负责第 1 层（基础理论层）
- tech_stack_worker: 负责第 2 层（技术栈层）
- core_skill_worker: 负责第 3 层（核心能力层）
- engineering_worker: 负责第 4 层（工程实践层）
- interview_worker: 负责第 5 层（面试准备层）

## 工作流程
1. 接收任务 → 2. 任务分解 → 3. 分配给子 Agent → 4. 汇总结果 → 5. 输出

记住：你是协调者，不是执行者。将具体任务分配给对应的子 Agent。"""
        
        return ConversableAgent(
            name="master_agent",
            system_message=system_message,
            llm_config=llm_config,
            human_input_mode="NEVER",
            max_consecutive_auto_reply=10
        )
    
    def create_master_agent(self):
        """创建主 Agent"""
        if not AUTOGEN_AVAILABLE:
            return None
        
        self.master_agent = self._create_master_agent_instance()
        
        config = self.config_manager.get_agent_config("master_agent")
        print(f"✅ 创建主 Agent: master_agent")
        print(f"   提供商：{config.get('provider', 'dashscope')}")
        print(f"   模型：{config.get('model', 'qwen-max')}")
        print(f"   热更新：{config.get('hot_reload', True)}")
        
        return self.master_agent
    
    def _create_worker_agent_instance(self, layer: int) -> ConversableAgent:
        """创建子 Agent 实例"""
        agents_config = self.config_manager.get_config("agents", {})
        
        # 查找对应层的 Agent 配置
        agent_name = None
        for name, config in agents_config.items():
            if config.get('layer') == layer:
                agent_name = name
                break
        
        if not agent_name:
            raise ValueError(f"第{layer}层的 Agent 配置不存在")
        
        llm_config = self.create_llm_config(agent_name)
        agent_config = self.config_manager.get_agent_config(agent_name)
        
        framework = {
            1: {"name": "基础理论层", "topics": ["AI 基础", "LLM 原理", "Agent 概念", "架构模式"]},
            2: {"name": "技术栈层", "topics": ["Python 编程", "Agent 框架", "向量数据库", "深度学习框架"]},
            3: {"name": "核心能力层", "topics": ["任务规划", "工具调用", "记忆管理", "多 Agent 协作"]},
            4: {"name": "工程实践层", "topics": ["项目经验", "性能优化", "部署运维", "安全合规"]},
            5: {"name": "面试准备层", "topics": ["算法题", "系统设计", "行为面试", "项目阐述"]}
        }
        
        system_message = f"""你是 Learning Agent 系统的{agent_config.get('role', '专家')}。

## 负责层级
第{layer}层：{framework.get(layer, {}).get('name', '')}

## 主要主题
{', '.join(framework.get(layer, {}).get('topics', []))}

## 你的职责
1. 接收主 Agent (master_agent) 的任务分配
2. 生成负责层级的详细学习内容
3. 为每个主题提供：描述、子主题、知识点、资源、时间估算、难度

## 输出格式
请严格按照 JSON 格式输出学习路线数据。

## 注意事项
- 内容要详细、实用
- 资源链接要真实有效
- 时间估算要合理
- 只输出 JSON，不要其他内容"""
        
        return ConversableAgent(
            name=agent_name,
            system_message=system_message,
            llm_config=llm_config,
            human_input_mode="NEVER",
            max_consecutive_auto_reply=10
        )
    
    def create_worker_agents(self):
        """创建子 Agent（Worker Agents）"""
        if not AUTOGEN_AVAILABLE:
            return
        
        agents_config = self.config_manager.get_config("agents", {})
        
        for agent_name, config in agents_config.items():
            if not config.get('enabled', False):
                continue
            
            layer = config.get('layer')
            if not layer:
                continue
            
            agent = self._create_worker_agent_instance(layer)
            self.worker_agents[layer] = agent
            
            print(f"✅ 创建子 Agent: {agent_name}")
            print(f"   层级：{layer}")
            print(f"   提供商：{config.get('provider', 'dashscope')}")
            print(f"   模型：{config.get('model', 'qwen-plus')}")
            print(f"   热更新：{config.get('hot_reload', True)}")
        
        return self.worker_agents
    
    def initialize(self):
        """初始化整个系统"""
        print("="*60)
        print("🤖 Learning Agent - AutoGen 多模型架构")
        print("="*60)
        
        # 创建所有 Agent
        self.create_user_proxy()
        self.create_master_agent()
        self.create_worker_agents()
        
        print("\n✅ 系统初始化完成！")
        print(f"   主 Agent: 1 个")
        print(f"   子 Agent: {len(self.worker_agents)}个")
        
        # 打印模型配置
        print("\n📊 模型配置:")
        agents_config = self.config_manager.get_config("agents", {})
        for agent_name, config in agents_config.items():
            if config.get('enabled', False):
                print(f"   {agent_name}: {config.get('provider')}/{config.get('model')}")
        
        # 开始监控配置变更
        print("\n👁️ 启动配置热监控...")
        self.config_manager.start_watching()
    
    def print_architecture(self):
        """打印架构信息"""
        print("\n" + "="*60)
        print("🏗️ 系统架构（多模型支持）")
        print("="*60)
        
        print("""
┌─────────────────────────────────────────────────────────┐
│              Master Agent                               │
│             (master_agent)                              │
│        模型：qwen-max (DashScope)                       │
│        热更新：✅                                       │
└─────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ theory_worker │   │tech_stack_worker│ │core_skill_worker│
│   第 1 层       │   │    第 2 层       │   │    第 3 层       │
│ qwen-plus     │   │  qwen-plus    │   │  qwen-plus    │
│ 热更新：✅     │   │  热更新：✅    │   │  热更新：✅    │
└───────────────┘   └───────────────┘   └───────────────┘
        │                   │                   │
        └───────────────────┼───────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐
│engineering_worker│ │interview_worker │
│    第 4 层         │ │    第 5 层         │
│ qwen-turbo      │ │ qwen-plus      │
│ 热更新：✅       │ │ 热更新：✅       │
└─────────────────┘ └─────────────────┘

架构特点:
- 1 个主 Agent 负责任务分解和协调
- 5 个子 Agent 各自负责一个知识层
- 每个 Agent 可配置不同的大模型
- 所有 Agent 都支持热更新
- 配置文件变更自动应用
""")
    
    def get_config_status(self) -> Dict:
        """获取配置状态"""
        return {
            "config_file": str(self.config_manager.config_path.absolute()),
            "config_hash": self.config_manager.config_hash[:8],
            "hot_reload_enabled": self.config_manager.get_config("hot_reload.enabled", True),
            "watching": self.config_manager._watching,
            "agents": self.config_manager.get_all_agents_config(),
            "change_history": self.config_manager.get_change_history(5)
        }


def main():
    """主函数"""
    # 初始化系统
    system = MultiModelLearningAgent()
    system.initialize()
    
    # 打印架构
    system.print_architecture()
    
    # 获取配置状态
    print("\n" + "="*60)
    print("📊 配置状态")
    print("="*60)
    
    status = system.get_config_status()
    print(f"配置文件：{status['config_file']}")
    print(f"配置哈希：{status['config_hash']}")
    print(f"热更新：{status['hot_reload_enabled']}")
    print(f"监控中：{status['watching']}")
    
    print("\n✅ 系统就绪，支持热更新配置")
    print("修改 config/agent_config.yaml 后会自动应用更改")
    print("按 Ctrl+C 退出")
    
    try:
        while True:
            import time
            time.sleep(1)
    except KeyboardInterrupt:
        system.config_manager.stop_watching()
        print("\n✅ 已退出")


if __name__ == "__main__":
    main()
