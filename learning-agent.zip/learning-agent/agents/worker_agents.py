#!/usr/bin/env python3
"""
知识层Worker Agent

实现5个专业领域的Worker Agent：
- TheoryWorker: 基础理论层
- TechStackWorker: 技术栈层
- CoreSkillWorker: 核心能力层
- EngineeringWorker: 工程实践层
- InterviewWorker: 面试准备层
"""

import os
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path

from .event_driven_agent import EventDrivenAgent, AsyncEventDrivenAgent
from .event_system import (
    EventBus,
    EventType,
    TaskAssignedEvent,
    TaskCompletedEvent,
    AgentStatus,
    get_event_bus
)
from .config_manager import get_config_manager, ConfigManager
from .master_agent import KNOWLEDGE_FRAMEWORK

try:
    from autogen import ConversableAgent
    AUTOGEN_AVAILABLE = True
except ImportError:
    AUTOGEN_AVAILABLE = False


class KnowledgeWorkerAgent(EventDrivenAgent):
    """
    知识层Worker Agent基类
    
    负责处理特定知识层的学习内容生成
    """
    
    def __init__(
        self,
        layer: int,
        event_bus: Optional[EventBus] = None,
        config_path: str = "config/agent_config.yaml"
    ):
        self.layer = layer
        self.framework = KNOWLEDGE_FRAMEWORK.get(layer, {})
        self.agent_name = self.framework.get("agent_name", f"worker_{layer}")
        
        # 配置管理
        self.config_manager: ConfigManager = get_config_manager()
        self.config_manager.config_path = Path(config_path)
        self.config_manager.load_config()
        
        # 获取LLM配置
        llm_config = self._get_llm_config()
        
        # 生成系统提示词
        system_message = self._create_system_message()
        
        # 初始化父类
        super().__init__(
            name=self.agent_name,
            system_message=system_message,
            llm_config=llm_config,
            event_bus=event_bus,
            subscribed_events=[EventType.TASK_ASSIGNED]
        )
        
        # 知识缓存
        self._knowledge_cache: Dict[str, Any] = {}
        
        print(f"✅ 创建知识层Worker: {self.agent_name} (第{layer}层)")
        print(f"   负责主题: {', '.join(self.framework.get('topics', []))}")
    
    def _get_llm_config(self) -> Dict[str, Any]:
        """获取LLM配置"""
        return self.config_manager.get_llm_config(self.agent_name)
    
    def _create_system_message(self) -> str:
        """创建系统提示词"""
        return f"""你是 Learning Agent 系统的{self.framework.get('name', '知识层')}专家。

## 你的身份
你是负责第{self.layer}层知识的专业Agent，拥有深厚的专业知识和教学经验。

## 负责层级
第{self.layer}层：{self.framework.get('name', '')}

## 主要主题
{', '.join(self.framework.get('topics', []))}

## 描述
{self.framework.get('description', '')}

## 你的职责
1. 接收主 Agent (master_agent) 分配的任务
2. 生成负责层级的详细学习内容
3. 为每个主题提供：
   - 详细描述
   - 3-5 个子主题
   - 每个子主题的关键知识点（至少 3 个）
   - 推荐学习资源（书籍、课程、文档链接）
   - 估算学习时间（小时）
   - 难度级别（beginner/intermediate/advanced）

## 输出格式
请严格按照以下 JSON 格式输出：
{{
    "layer": {self.layer},
    "layer_name": "{self.framework.get('name', '')}",
    "topics": [
        {{
            "name": "主题名称",
            "description": "主题描述",
            "subtopics": [
                {{
                    "name": "子主题",
                    "key_points": ["知识点 1", "知识点 2", "知识点 3"],
                    "resources": ["资源链接 1", "资源链接 2"],
                    "estimated_hours": 10,
                    "difficulty": "intermediate"
                }}
            ],
            "estimated_hours": 40,
            "priority": "high"
        }}
    ],
    "total_hours": 总学习时长,
    "recommended_order": ["推荐学习顺序"]
}}

## 注意事项
- 内容要详细、实用，贴近实际应用
- 资源链接要真实有效
- 时间估算要合理
- 只输出 JSON，不要其他内容
- 如果主 Agent 没有明确要求，按默认格式输出"""

    def on_task_assigned(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """
        处理任务分配事件
        
        Args:
            event: 任务分配事件
            
        Returns:
            生成的知识内容
        """
        print(f"\n🤖 [{self.agent_name}] 处理任务: {event.task_id}")
        print(f"   内容: {event.task_content[:100]}...")
        
        # 发布进度更新
        self.publish_progress(event.task_id, 0.1, "开始分析任务", "分析任务需求")
        
        try:
            # 生成知识内容
            result = self._generate_knowledge(event)
            
            if result:
                # 缓存结果
                self._knowledge_cache[event.task_id] = result
                
                # 发布进度
                self.publish_progress(event.task_id, 1.0, "任务完成", "生成完成")
                
                print(f"   ✅ [{self.agent_name}] 任务完成")
                return result
            else:
                print(f"   ❌ [{self.agent_name}] 生成失败")
                return None
                
        except Exception as e:
            print(f"   ❌ [{self.agent_name}] 处理错误: {e}")
            return None
    
    def _generate_knowledge(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """
        生成知识内容
        
        子类可以重写此方法来实现特定的生成逻辑
        
        Args:
            event: 任务分配事件
            
        Returns:
            生成的知识数据
        """
        # 默认实现：返回模板数据
        # 实际使用时会调用LLM生成
        return self._get_default_knowledge()
    
    def _get_default_knowledge(self) -> Dict[str, Any]:
        """获取默认知识模板"""
        topics_data = []
        
        for topic_name in self.framework.get("topics", []):
            topics_data.append({
                "name": topic_name,
                "description": f"{topic_name}的详细学习内容",
                "subtopics": [
                    {
                        "name": f"{topic_name}基础",
                        "key_points": ["基本概念", "核心原理", "实践方法"],
                        "resources": [
                            f"https://example.com/{topic_name}/intro",
                            f"https://docs.example.com/{topic_name}"
                        ],
                        "estimated_hours": 10,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 30,
                "priority": "high"
            })
        
        return {
            "layer": self.layer,
            "layer_name": self.framework.get("name", ""),
            "topics": topics_data,
            "total_hours": sum(t.get("estimated_hours", 0) for t in topics_data),
            "recommended_order": self.framework.get("topics", []),
            "agent": self.agent_name,
            "generated_at": datetime.now().isoformat()
        }


# ==================== 具体Worker实现 ====================

class TheoryWorker(KnowledgeWorkerAgent):
    """基础理论层Worker"""
    
    def __init__(self, event_bus: Optional[EventBus] = None, config_path: str = "config/agent_config.yaml"):
        super().__init__(layer=1, event_bus=event_bus, config_path=config_path)
    
    def _generate_knowledge(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """生成基础理论知识"""
        result = self._get_default_knowledge()
        
        # 添加AI基础特定内容
        result["topics"] = [
            {
                "name": "AI 基础",
                "description": "人工智能基础理论，包括机器学习、深度学习核心概念",
                "subtopics": [
                    {"name": "机器学习基础", "key_points": ["监督学习", "无监督学习", "强化学习"], "estimated_hours": 15},
                    {"name": "神经网络原理", "key_points": ["感知机", "反向传播", "激活函数"], "estimated_hours": 12},
                    {"name": "深度学习入门", "key_points": ["CNN", "RNN", "Transformer"], "estimated_hours": 18}
                ],
                "estimated_hours": 45
            },
            {
                "name": "LLM 原理",
                "description": "大语言模型的工作原理和架构",
                "subtopics": [
                    {"name": "Transformer架构", "key_points": ["自注意力机制", "位置编码", "多头注意力"], "estimated_hours": 15},
                    {"name": "预训练与微调", "key_points": ["预训练目标", "指令微调", "RLHF"], "estimated_hours": 12}
                ],
                "estimated_hours": 27
            },
            {
                "name": "Agent 概念",
                "description": "智能体系统的核心概念和架构",
                "subtopics": [
                    {"name": "Agent定义", "key_points": ["感知", "决策", "行动", "学习"], "estimated_hours": 8},
                    {"name": "Agent架构", "key_points": ["ReAct", "CoT", "ToT"], "estimated_hours": 10}
                ],
                "estimated_hours": 18
            },
            {
                "name": "架构模式",
                "description": "常见的Agent系统架构模式",
                "subtopics": [
                    {"name": "单Agent架构", "key_points": ["任务规划", "工具调用", "记忆管理"], "estimated_hours": 10},
                    {"name": "多Agent协作", "key_points": ["通信机制", "任务分配", "冲突解决"], "estimated_hours": 12}
                ],
                "estimated_hours": 22
            }
        ]
        result["total_hours"] = sum(t.get("estimated_hours", 0) for t in result["topics"])
        return result


class TechStackWorker(KnowledgeWorkerAgent):
    """技术栈层Worker"""
    
    def __init__(self, event_bus: Optional[EventBus] = None, config_path: str = "config/agent_config.yaml"):
        super().__init__(layer=2, event_bus=event_bus, config_path=config_path)
    
    def _generate_knowledge(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """生成技术栈知识"""
        result = self._get_default_knowledge()
        
        result["topics"] = [
            {
                "name": "Python 编程",
                "description": "Python高级编程和异步编程",
                "subtopics": [
                    {"name": "高级语法", "key_points": ["装饰器", "生成器", "上下文管理器"], "estimated_hours": 15},
                    {"name": "异步编程", "key_points": ["asyncio", "协程", "并发模式"], "estimated_hours": 12}
                ],
                "estimated_hours": 27
            },
            {
                "name": "Agent 框架",
                "description": "主流Agent开发框架",
                "subtopics": [
                    {"name": "LangChain", "key_points": ["Chain", "Agent", "Tool", "Memory"], "estimated_hours": 20},
                    {"name": "AutoGen", "key_points": ["ConversableAgent", "GroupChat", "事件驱动"], "estimated_hours": 18}
                ],
                "estimated_hours": 38
            },
            {
                "name": "向量数据库",
                "description": "向量存储和检索技术",
                "subtopics": [
                    {"name": "向量存储", "key_points": ["Embedding", "索引", "相似度搜索"], "estimated_hours": 12},
                    {"name": "主流数据库", "key_points": ["Pinecone", "Milvus", "Chroma"], "estimated_hours": 15}
                ],
                "estimated_hours": 27
            },
            {
                "name": "深度学习框架",
                "description": "PyTorch和TensorFlow实践",
                "subtopics": [
                    {"name": "PyTorch", "key_points": ["张量操作", "自动微分", "模型构建"], "estimated_hours": 20},
                    {"name": "模型部署", "key_points": ["ONNX", "TensorRT", "量化"], "estimated_hours": 15}
                ],
                "estimated_hours": 35
            }
        ]
        result["total_hours"] = sum(t.get("estimated_hours", 0) for t in result["topics"])
        return result


class CoreSkillWorker(KnowledgeWorkerAgent):
    """核心能力层Worker"""
    
    def __init__(self, event_bus: Optional[EventBus] = None, config_path: str = "config/agent_config.yaml"):
        super().__init__(layer=3, event_bus=event_bus, config_path=config_path)
    
    def _generate_knowledge(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """生成核心能力知识"""
        result = self._get_default_knowledge()
        
        result["topics"] = [
            {
                "name": "任务规划",
                "description": "Agent任务分解和规划能力",
                "subtopics": [
                    {"name": "任务分解", "key_points": ["目标分解", "依赖分析", "优先级排序"], "estimated_hours": 12},
                    {"name": "规划算法", "key_points": ["ReAct", "Plan-and-Solve", "ToT"], "estimated_hours": 15}
                ],
                "estimated_hours": 27
            },
            {
                "name": "工具调用",
                "description": "工具集成和调用机制",
                "subtopics": [
                    {"name": "工具定义", "key_points": ["函数描述", "参数验证", "错误处理"], "estimated_hours": 10},
                    {"name": "工具选择", "key_points": ["语义匹配", "多工具协调", "结果解析"], "estimated_hours": 12}
                ],
                "estimated_hours": 22
            },
            {
                "name": "记忆管理",
                "description": "短期和长期记忆系统",
                "subtopics": [
                    {"name": "短期记忆", "key_points": ["对话上下文", "滑动窗口", "摘要"], "estimated_hours": 10},
                    {"name": "长期记忆", "key_points": ["向量存储", "知识图谱", "检索增强"], "estimated_hours": 15}
                ],
                "estimated_hours": 25
            },
            {
                "name": "多 Agent 协作",
                "description": "多智能体系统设计和协作",
                "subtopics": [
                    {"name": "协作模式", "key_points": ["主从模式", "对等模式", "层级模式"], "estimated_hours": 12},
                    {"name": "通信机制", "key_points": ["消息传递", "事件驱动", "共享状态"], "estimated_hours": 15}
                ],
                "estimated_hours": 27
            }
        ]
        result["total_hours"] = sum(t.get("estimated_hours", 0) for t in result["topics"])
        return result


class EngineeringWorker(KnowledgeWorkerAgent):
    """工程实践层Worker"""
    
    def __init__(self, event_bus: Optional[EventBus] = None, config_path: str = "config/agent_config.yaml"):
        super().__init__(layer=4, event_bus=event_bus, config_path=config_path)
    
    def _generate_knowledge(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """生成工程实践知识"""
        result = self._get_default_knowledge()
        
        result["topics"] = [
            {
                "name": "项目经验",
                "description": "实际项目开发和部署经验",
                "subtopics": [
                    {"name": "项目架构", "key_points": ["需求分析", "架构设计", "技术选型"], "estimated_hours": 15},
                    {"name": "代码质量", "key_points": ["代码规范", "测试覆盖", "Code Review"], "estimated_hours": 12}
                ],
                "estimated_hours": 27
            },
            {
                "name": "性能优化",
                "description": "系统性能调优技术",
                "subtopics": [
                    {"name": "推理优化", "key_points": ["模型量化", "缓存策略", "批处理"], "estimated_hours": 15},
                    {"name": "并发处理", "key_points": ["异步IO", "连接池", "负载均衡"], "estimated_hours": 12}
                ],
                "estimated_hours": 27
            },
            {
                "name": "部署运维",
                "description": "生产环境部署和运维",
                "subtopics": [
                    {"name": "容器化", "key_points": ["Docker", "Kubernetes", "CI/CD"], "estimated_hours": 15},
                    {"name": "监控告警", "key_points": ["日志收集", "指标监控", "告警配置"], "estimated_hours": 10}
                ],
                "estimated_hours": 25
            },
            {
                "name": "安全合规",
                "description": "AI系统安全和合规要求",
                "subtopics": [
                    {"name": "安全防护", "key_points": ["输入过滤", "输出审核", "访问控制"], "estimated_hours": 12},
                    {"name": "合规要求", "key_points": ["数据隐私", "模型透明", "责任追溯"], "estimated_hours": 10}
                ],
                "estimated_hours": 22
            }
        ]
        result["total_hours"] = sum(t.get("estimated_hours", 0) for t in result["topics"])
        return result


class InterviewWorker(KnowledgeWorkerAgent):
    """面试准备层Worker"""
    
    def __init__(self, event_bus: Optional[EventBus] = None, config_path: str = "config/agent_config.yaml"):
        super().__init__(layer=5, event_bus=event_bus, config_path=config_path)
    
    def _generate_knowledge(self, event: TaskAssignedEvent) -> Optional[Dict[str, Any]]:
        """生成面试准备知识"""
        result = self._get_default_knowledge()
        
        result["topics"] = [
            {
                "name": "算法题",
                "description": "AI工程师常见算法面试题",
                "subtopics": [
                    {"name": "数据结构", "key_points": ["数组", "链表", "树", "图"], "estimated_hours": 20},
                    {"name": "算法技巧", "key_points": ["动态规划", "贪心", "回溯"], "estimated_hours": 25}
                ],
                "estimated_hours": 45
            },
            {
                "name": "系统设计",
                "description": "AI系统设计面试",
                "subtopics": [
                    {"name": "推荐系统", "key_points": ["召回", "排序", "重排"], "estimated_hours": 15},
                    {"name": "LLM应用", "key_points": ["RAG", "Agent", "微调"], "estimated_hours": 18}
                ],
                "estimated_hours": 33
            },
            {
                "name": "行为面试",
                "description": "软技能和行为面试准备",
                "subtopics": [
                    {"name": "项目经历", "key_points": ["STAR法则", "难点分析", "成果量化"], "estimated_hours": 8},
                    {"name": "职业规划", "key_points": ["发展路径", "技能矩阵", "目标设定"], "estimated_hours": 6}
                ],
                "estimated_hours": 14
            },
            {
                "name": "项目阐述",
                "description": "项目展示和讲解能力",
                "subtopics": [
                    {"name": "技术深度", "key_points": ["架构决策", "技术亮点", "优化方案"], "estimated_hours": 10},
                    {"name": "业务价值", "key_points": ["问题定义", "解决方案", "效果评估"], "estimated_hours": 8}
                ],
                "estimated_hours": 18
            }
        ]
        result["total_hours"] = sum(t.get("estimated_hours", 0) for t in result["topics"])
        return result


def create_all_workers(
    event_bus: Optional[EventBus] = None,
    config_path: str = "config/agent_config.yaml"
) -> Dict[int, KnowledgeWorkerAgent]:
    """
    创建所有Worker Agent
    
    Args:
        event_bus: 事件总线
        config_path: 配置文件路径
        
    Returns:
        层级 -> Worker Agent 的映射
    """
    workers = {
        1: TheoryWorker(event_bus=event_bus, config_path=config_path),
        2: TechStackWorker(event_bus=event_bus, config_path=config_path),
        3: CoreSkillWorker(event_bus=event_bus, config_path=config_path),
        4: EngineeringWorker(event_bus=event_bus, config_path=config_path),
        5: InterviewWorker(event_bus=event_bus, config_path=config_path)
    }
    
    print(f"\n✅ 所有Worker Agent创建完成，共 {len(workers)} 个")
    return workers