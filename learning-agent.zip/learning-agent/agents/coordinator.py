#!/usr/bin/env python3
"""
任务协调器

负责：
- 协调主Agent和子Agent的协作
- 管理异步任务执行
- 处理超时和重试
- 提供任务状态监控
"""

import asyncio
import threading
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
import uuid

from .event_system import (
    EventBus,
    Event,
    EventType,
    TaskAssignedEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    TaskPriority,
    AgentStatus,
    get_event_bus
)
from .master_agent import MasterCoordinator, KNOWLEDGE_FRAMEWORK
from .worker_agents import (
    KnowledgeWorkerAgent,
    TheoryWorker,
    TechStackWorker,
    CoreSkillWorker,
    EngineeringWorker,
    InterviewWorker,
    create_all_workers
)


class TaskCoordinator:
    """
    任务协调器
    
    管理整个事件驱动系统的运行：
    - 初始化所有Agent
    - 启动事件总线
    - 执行用户请求
    - 监控任务状态
    """
    
    def __init__(
        self,
        config_path: str = "config/agent_config.yaml",
        output_dir: str = "data/knowledge"
    ):
        self.config_path = config_path
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 事件总线
        self.event_bus = get_event_bus()
        
        # Agent实例
        self.master_agent: Optional[MasterCoordinator] = None
        self.workers: Dict[int, KnowledgeWorkerAgent] = {}
        
        # 任务状态
        self._running = False
        self._current_request: Optional[str] = None
        self._start_time: Optional[datetime] = None
        
        # 回调
        self._on_progress: Optional[Callable] = None
        self._on_complete: Optional[Callable] = None
        self._on_error: Optional[Callable] = None
        
        print("✅ TaskCoordinator 初始化完成")
    
    def initialize(self):
        """初始化所有Agent"""
        print("\n" + "="*60)
        print("🚀 初始化事件驱动Agent系统")
        print("="*60)
        
        # 创建Worker Agents
        print("\n📦 创建Worker Agents...")
        self.workers = create_all_workers(
            event_bus=self.event_bus,
            config_path=self.config_path
        )
        
        # 创建Master Agent
        print("\n📦 创建Master Agent...")
        self.master_agent = MasterCoordinator(
            config_path=self.config_path,
            event_bus=self.event_bus,
            output_dir=str(self.output_dir)
        )
        
        print("\n✅ 所有Agent初始化完成")
        print(f"   Master Agent: 1 个")
        print(f"   Worker Agents: {len(self.workers)} 个")
        
        # 打印事件总线状态
        stats = self.event_bus.get_stats()
        print(f"\n📊 事件总线状态:")
        print(f"   订阅者数量: {stats['subscriber_count']}")
        print(f"   Agent订阅: {stats['agent_subscribers']}")
    
    def execute_concurrent(
        self,
        user_request: str,
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout: float = 300.0
    ) -> Dict[str, Any]:
        """
        并发执行用户请求
        
        Args:
            user_request: 用户请求
            priority: 任务优先级
            timeout: 超时时间（秒）
            
        Returns:
            执行结果
        """
        if not self.master_agent:
            self.initialize()
        
        self._running = True
        self._current_request = user_request
        self._start_time = datetime.now()
        
        print(f"\n{'='*60}")
        print(f"📋 执行请求: {user_request[:50]}...")
        print(f"{'='*60}")
        
        try:
            # 使用同步包装器执行
            result = self.master_agent.execute_request(user_request, priority)
            
            # 检查执行状态
            elapsed = (datetime.now() - self._start_time).total_seconds()
            
            print(f"\n⏱️ 执行耗时: {elapsed:.2f} 秒")
            
            return {
                "success": True,
                "request": user_request,
                "results": result,
                "elapsed_seconds": elapsed,
                "completed_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            print(f"\n❌ 执行失败: {e}")
            return {
                "success": False,
                "request": user_request,
                "error": str(e),
                "elapsed_seconds": (datetime.now() - self._start_time).total_seconds()
            }
            
        finally:
            self._running = False
            self._current_request = None
    
    async def execute_concurrent_async(
        self,
        user_request: str,
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout: float = 300.0
    ) -> Dict[str, Any]:
        """
        异步并发执行用户请求
        
        Args:
            user_request: 用户请求
            priority: 任务优先级
            timeout: 超时时间（秒）
            
        Returns:
            执行结果
        """
        if not self.master_agent:
            self.initialize()
        
        self._running = True
        self._current_request = user_request
        self._start_time = datetime.now()
        
        try:
            # 异步执行
            result = await asyncio.wait_for(
                self.master_agent.execute_request_async(user_request, priority),
                timeout=timeout
            )
            
            elapsed = (datetime.now() - self._start_time).total_seconds()
            
            return {
                "success": True,
                "request": user_request,
                "results": result,
                "elapsed_seconds": elapsed,
                "completed_at": datetime.now().isoformat()
            }
            
        except asyncio.TimeoutError:
            return {
                "success": False,
                "request": user_request,
                "error": f"执行超时（>{timeout}秒）",
                "elapsed_seconds": timeout
            }
        except Exception as e:
            return {
                "success": False,
                "request": user_request,
                "error": str(e),
                "elapsed_seconds": (datetime.now() - self._start_time).total_seconds()
            }
        finally:
            self._running = False
            self._current_request = None
    
    def get_status(self) -> Dict[str, Any]:
        """获取协调器状态"""
        return {
            "running": self._running,
            "current_request": self._current_request,
            "start_time": self._start_time.isoformat() if self._start_time else None,
            "workers_count": len(self.workers),
            "master_status": self.master_agent.get_status() if self.master_agent else None,
            "event_bus_stats": self.event_bus.get_stats() if self.event_bus else None
        }
    
    def get_workers_status(self) -> Dict[str, Dict[str, Any]]:
        """获取所有Worker状态"""
        return {
            worker.name: worker.get_status()
            for worker in self.workers.values()
        }
    
    def print_architecture(self):
        """打印系统架构"""
        if self.master_agent:
            self.master_agent.print_architecture()
    
    def shutdown(self):
        """关闭协调器"""
        print("\n🛑 关闭TaskCoordinator...")
        self._running = False
        self.event_bus.clear_history()
        print("✅ 已关闭")


class ConcurrentTaskExecutor:
    """
    并发任务执行器
    
    提供更细粒度的并发控制
    """
    
    def __init__(self, coordinator: TaskCoordinator):
        self.coordinator = coordinator
        self._tasks: Dict[str, asyncio.Task] = {}
    
    async def submit_task(
        self,
        task_id: str,
        request: str,
        priority: TaskPriority = TaskPriority.NORMAL
    ) -> str:
        """
        提交任务
        
        Args:
            task_id: 任务ID
            request: 请求内容
            priority: 优先级
            
        Returns:
            任务ID
        """
        if task_id in self._tasks:
            raise ValueError(f"任务 {task_id} 已存在")
        
        task = asyncio.create_task(
            self.coordinator.execute_concurrent_async(request, priority)
        )
        self._tasks[task_id] = task
        
        return task_id
    
    async def wait_for_task(self, task_id: str, timeout: float = 300.0) -> Dict[str, Any]:
        """
        等待任务完成
        
        Args:
            task_id: 任务ID
            timeout: 超时时间
            
        Returns:
            任务结果
        """
        if task_id not in self._tasks:
            raise ValueError(f"任务 {task_id} 不存在")
        
        try:
            result = await asyncio.wait_for(self._tasks[task_id], timeout=timeout)
            return result
        except asyncio.TimeoutError:
            return {"success": False, "error": "任务超时"}
        finally:
            del self._tasks[task_id]
    
    async def wait_all(self, timeout: float = 600.0) -> Dict[str, Dict[str, Any]]:
        """
        等待所有任务完成
        
        Args:
            timeout: 总超时时间
            
        Returns:
            所有任务结果
        """
        if not self._tasks:
            return {}
        
        results = {}
        tasks = list(self._tasks.items())
        
        for task_id, task in tasks:
            try:
                results[task_id] = await asyncio.wait_for(task, timeout=timeout)
            except asyncio.TimeoutError:
                results[task_id] = {"success": False, "error": "任务超时"}
        
        self._tasks.clear()
        return results
    
    def get_pending_tasks(self) -> List[str]:
        """获取待处理任务列表"""
        return list(self._tasks.keys())
    
    def cancel_task(self, task_id: str) -> bool:
        """
        取消任务
        
        Args:
            task_id: 任务ID
            
        Returns:
            是否成功
        """
        if task_id in self._tasks:
            self._tasks[task_id].cancel()
            del self._tasks[task_id]
            return True
        return False


def run_learning_request(
    request: str = "生成完整的Agent开发学习路线",
    config_path: str = "config/agent_config.yaml",
    output_dir: str = "data/knowledge"
) -> Dict[str, Any]:
    """
    快捷函数：执行学习路线生成请求
    
    Args:
        request: 用户请求
        config_path: 配置文件路径
        output_dir: 输出目录
        
    Returns:
        执行结果
    """
    coordinator = TaskCoordinator(config_path=config_path, output_dir=output_dir)
    coordinator.initialize()
    return coordinator.execute_concurrent(request)


# 主函数
def main():
    """主函数"""
    print("="*60)
    print("🤖 Learning Agent - 事件驱动架构")
    print("="*60)
    
    # 创建协调器
    coordinator = TaskCoordinator()
    
    # 初始化
    coordinator.initialize()
    
    # 打印架构
    coordinator.print_architecture()
    
    # 执行请求
    result = coordinator.execute_concurrent(
        "生成完整的Agent开发学习路线，涵盖从入门到精通的全部内容"
    )
    
    # 输出结果
    print("\n" + "="*60)
    print("📊 执行结果")
    print("="*60)
    print(f"成功: {result['success']}")
    print(f"耗时: {result['elapsed_seconds']:.2f} 秒")
    
    if result['success']:
        results = result['results']
        print(f"\n生成的知识层: {len(results)} 层")
        for layer, data in results.items():
            topics = data.get('topics', [])
            hours = data.get('total_hours', 0)
            print(f"   第{layer}层: {len(topics)} 个主题, {hours} 小时")
    else:
        print(f"错误: {result.get('error', '未知错误')}")
    
    # 关闭
    coordinator.shutdown()
    
    print("\n✅ 任务完成")


if __name__ == "__main__":
    main()