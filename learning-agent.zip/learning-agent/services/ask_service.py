#!/usr/bin/env python3
"""
Ask Service - Web 问答助手服务

提供实时对话交互功能：
- 对话历史管理
- Agent 回复生成
- 上下文维护
- 多轮对话支持
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import threading
import queue

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.config_manager import get_config_manager, ConfigManager
from agents.master_agent import KNOWLEDGE_FRAMEWORK, ARCHITECTURE_KEYWORDS
from .llm_service import get_llm_service, LLMService


class ConversationContext:
    """对话上下文"""
    
    def __init__(self, agent_name: str, max_history: int = 20):
        self.agent_name = agent_name
        self.max_history = max_history
        self.messages: List[Dict[str, Any]] = []
        self.created_at = datetime.now()
        self.last_activity = datetime.now()
    
    def add_message(self, role: str, content: str, metadata: Optional[Dict] = None):
        """添加消息"""
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        self.messages.append(message)
        self.last_activity = datetime.now()
        
        # 限制历史长度
        if len(self.messages) > self.max_history:
            self.messages = self.messages[-self.max_history:]
    
    def get_history(self, limit: Optional[int] = None) -> List[Dict]:
        """获取历史消息"""
        if limit:
            return self.messages[-limit:]
        return self.messages.copy()
    
    def clear(self):
        """清空历史"""
        self.messages.clear()
        self.last_activity = datetime.now()


class AskService:
    """
    Ask 服务 - Web 问答助手
    
    功能：
    - 管理多个 Agent 的对话上下文
    - 生成智能回复
    - 支持多轮对话
    - 集成事件驱动架构
    """
    
    def __init__(self, config_path: str = "config/agent_config.yaml"):
        self.config_path = Path(config_path)
        self.config_manager: ConfigManager = get_config_manager()
        
        if self.config_path.exists():
            self.config_manager.config_path = self.config_path
            self.config_manager.load_config()
        
        # 对话上下文存储
        self._contexts: Dict[str, ConversationContext] = {}
        
        # 知识库缓存
        self._knowledge_cache: Dict[int, Dict] = {}
        self._load_knowledge_cache()
        
        # 回复模板
        self._reply_templates = self._init_reply_templates()
        
        # 初始化架构师组件
        self._init_architect()
        
        # 初始化 LLM 服务
        self._init_llm_service()
        
        print("✅ AskService 初始化完成")
    
    def _init_llm_service(self):
        """初始化 LLM 服务"""
        try:
            self._llm_service: LLMService = get_llm_service(str(self.config_path))
            print("   ✅ LLM 服务已加载")
        except Exception as e:
            print(f"   ⚠️ LLM 服务加载失败: {e}")
            self._llm_service = None
    
    def _init_architect(self):
        """初始化架构师组件"""
        # 导入 MasterAgent 的架构师功能
        try:
            from agents.master_agent import MasterCoordinator
            # 不完整初始化，只使用静态方法
            self._architect_class = MasterCoordinator
        except Exception as e:
            print(f"⚠️ 无法加载架构师组件: {e}")
            self._architect_class = None
    
    def _load_knowledge_cache(self):
        """加载知识库缓存"""
        data_dir = Path("data/knowledge")
        if not data_dir.exists():
            return
        
        for layer in range(1, 6):
            layer_file = data_dir / f"layer_{layer}_knowledge.json"
            if layer_file.exists():
                try:
                    with open(layer_file, 'r', encoding='utf-8') as f:
                        self._knowledge_cache[layer] = json.load(f)
                except Exception as e:
                    print(f"⚠️ 加载知识缓存失败 (layer {layer}): {e}")
    
    def _init_reply_templates(self) -> Dict[str, str]:
        """初始化回复模板"""
        return {
            "greeting": """你好！我是 Learning Agent 的智能助手。

我可以帮助你：
- 📚 制定个性化学习路线
- 🎯 推荐学习资源和项目
- 💡 解答技术问题
- 🎓 面试准备指导
- 📈 职业规划建议

请告诉我你想了解什么？""",

            "learning_path": """根据您的需求，我为您推荐以下学习路径：

**🎯 学习路线总览**

| 层级 | 名称 | 主要内容 | 预计时长 |
|------|------|----------|----------|
| 1 | 基础理论层 | AI基础、LLM原理、Agent概念 | 100+ 小时 |
| 2 | 技术栈层 | Python、框架、向量数据库 | 120+ 小时 |
| 3 | 核心能力层 | 任务规划、工具调用、协作 | 100+ 小时 |
| 4 | 工程实践层 | 项目经验、优化、部署 | 100+ 小时 |
| 5 | 面试准备层 | 算法、系统设计、行为面试 | 110+ 小时 |

您想了解哪个层级的详细内容？""",

            "unknown": """抱歉，我暂时无法理解您的问题。

您可以尝试这样问我：
- "我想学习 Agent 开发，请为我制定学习路线"
- "第1层基础理论包含哪些内容？"
- "如何准备 AI 工程师面试？"
- "Python 初学者如何入门 AI？"

或者直接输入您感兴趣的主题，我会尽力帮助您！"""
        }
    
    def get_or_create_context(self, agent_name: str) -> ConversationContext:
        """获取或创建对话上下文"""
        if agent_name not in self._contexts:
            self._contexts[agent_name] = ConversationContext(agent_name)
        return self._contexts[agent_name]
    
    def chat(
        self,
        message: str,
        agent_name: str = "master_agent",
        context_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        发送消息并获取回复
        
        Args:
            message: 用户消息
            agent_name: Agent 名称
            context_id: 上下文ID（可选）
            
        Returns:
            回复结果
        """
        # 获取上下文
        context = self.get_or_create_context(agent_name)
        
        # 添加用户消息
        context.add_message("user", message)
        
        # 获取 Agent 配置
        agent_config = self.config_manager.get_agent_config(agent_name)
        if not agent_config:
            agent_config = {"name": agent_name, "role": "AI 助手"}
        
        # 生成回复
        reply = self._generate_reply(message, agent_config, context)
        
        # 添加助手消息
        context.add_message("assistant", reply)
        
        return {
            "success": True,
            "reply": reply,
            "agent": agent_name,
            "timestamp": datetime.now().isoformat(),
            "context_id": context_id
        }
    
    def _generate_reply(
        self,
        message: str,
        agent_config: Dict,
        context: ConversationContext
    ) -> str:
        """
        生成回复
        
        Args:
            message: 用户消息
            agent_config: Agent 配置
            context: 对话上下文
            
        Returns:
            回复内容
        """
        role = agent_config.get('role', 'AI 助手')
        message_lower = message.lower()
        
        # ===== 主 Agent：通过 LLM 判断如何处理 =====
        if agent_name == "master_agent":
            # 使用 LLM 判断是直接回答还是委派给子 Agent
            return self._llm_route_and_answer(message)
        
        # 分析消息意图
        intent = self._analyze_intent(message)
        
        # 根据意图生成回复
        if intent == "greeting":
            return self._reply_templates["greeting"]
        
        elif intent == "learning_path":
            return self._generate_learning_path_reply(message)
        
        elif intent == "layer_detail":
            return self._generate_layer_detail_reply(message)
        
        elif intent == "interview":
            return self._generate_interview_reply(message)
        
        elif intent == "python":
            return self._generate_python_reply(message)
        
        elif intent == "help":
            return self._generate_help_reply()
        
        else:
            # 尝试从知识库中查找相关内容
            knowledge_reply = self._search_knowledge(message)
            if knowledge_reply:
                return knowledge_reply
            
            return self._generate_default_reply(message, role)
    
    def _analyze_intent(self, message: str) -> str:
        """分析消息意图"""
        message_lower = message.lower()
        
        # 问候
        greetings = ["你好", "hello", "hi", "您好", "早上好", "下午好"]
        if any(g in message_lower for g in greetings):
            return "greeting"
        
        # 学习路线
        path_keywords = ["学习路线", "学习路径", "怎么学", "如何学", "学习计划"]
        if any(k in message for k in path_keywords):
            return "learning_path"
        
        # 层级详情
        layer_keywords = ["第1层", "第2层", "第3层", "第4层", "第5层", 
                          "基础理论", "技术栈", "核心能力", "工程实践", "面试"]
        if any(k in message for k in layer_keywords):
            return "layer_detail"
        
        # 面试相关
        interview_keywords = ["面试", "工作", "求职", "简历", "offer"]
        if any(k in message for k in interview_keywords):
            return "interview"
        
        # Python入门
        python_keywords = ["python", "入门", "初学者", "新手", "零基础"]
        if any(k in message_lower for k in python_keywords):
            return "python"
        
        # 帮助
        if "帮助" in message or "help" in message_lower:
            return "help"
        
        return "unknown"
    
    def _generate_learning_path_reply(self, message: str) -> str:
        """生成学习路线回复"""
        reply = self._reply_templates["learning_path"]
        
        # 如果有缓存的知识，添加详情
        if self._knowledge_cache:
            reply += "\n\n**📚 已生成的知识内容：**\n"
            for layer, data in sorted(self._knowledge_cache.items()):
                topics = data.get('topics', [])
                hours = data.get('total_hours', 0)
                reply += f"\n第{layer}层：{', '.join(t['name'] for t in topics[:3])}{'...' if len(topics) > 3 else ''} ({hours}小时)"
        
        reply += "\n\n您想了解哪个层级或主题的详细内容？"
        return reply
    
    def _generate_layer_detail_reply(self, message: str) -> str:
        """生成层级详情回复"""
        # 检测层级
        layer = None
        for i in range(1, 6):
            if f"第{i}层" in message or str(i) in message:
                layer = i
                break
        
        # 检测层级名称
        layer_names = {
            "基础理论": 1, "理论": 1,
            "技术栈": 2, "框架": 2,
            "核心能力": 3, "能力": 3,
            "工程实践": 4, "实践": 4,
            "面试": 5, "准备": 5
        }
        
        for name, l in layer_names.items():
            if name in message:
                layer = l
                break
        
        if layer and layer in self._knowledge_cache:
            data = self._knowledge_cache[layer]
            framework = KNOWLEDGE_FRAMEWORK.get(layer, {})
            
            reply = f"## 第{layer}层：{framework.get('name', '')}\n\n"
            reply += f"{framework.get('description', '')}\n\n"
            reply += "**📚 主要主题：**\n\n"
            
            for topic in data.get('topics', []):
                reply += f"### {topic.get('name', '')}\n"
                reply += f"{topic.get('description', '')}\n"
                reply += f"- 预计时长：{topic.get('estimated_hours', 0)} 小时\n\n"
            
            reply += f"**总计：{data.get('total_hours', 0)} 小时**\n"
            return reply
        
        # 没有缓存数据时返回默认内容
        if layer:
            framework = KNOWLEDGE_FRAMEWORK.get(layer, {})
            reply = f"## 第{layer}层：{framework.get('name', '')}\n\n"
            reply += f"{framework.get('description', '')}\n\n"
            reply += "**📚 主要主题：**\n"
            for topic in framework.get('topics', []):
                reply += f"- {topic}\n"
            return reply
        
        return "请告诉我您想了解第几层的详细内容？（1-5层）"
    
    def _generate_interview_reply(self, message: str) -> str:
        """生成面试准备回复"""
        return """## 💼 AI 工程师面试准备指南

### 1. 算法题准备（40%）
- **LeetCode Hot 100** 必刷
- 重点数据结构：树、图、动态规划
- 建议每天 3-5 道题

### 2. 机器学习基础（30%）
- 常见算法原理（LR、SVM、决策树、随机森林、GBDT）
- 模型评估指标（准确率、召回率、F1、AUC）
- 过拟合/欠拟合处理

### 3. 深度学习（20%）
- CNN/RNN/Transformer 架构
- 优化器、损失函数
- 实战项目经验

### 4. 行为面试（10%）
- 项目经历梳理（STAR 法则）
- 职业规划思考
- 团队协作案例

**📝 推荐刷题顺序：**
1. 数组/字符串（1 周）
2. 链表/树（2 周）
3. 动态规划（2 周）
4. 模拟面试（1 周）

需要我为您制定详细的面试准备计划吗？"""
    
    def _generate_python_reply(self, message: str) -> str:
        """生成 Python 入门回复"""
        return """## 🐍 Python 入门 AI 学习路径

### 第一阶段：Python 基础（2-4 周）

**基础语法**
- 变量、数据类型、运算符
- 条件语句、循环
- 函数定义和调用

**进阶内容**
- 面向对象编程
- 异常处理
- 文件操作

**数据科学库**
- NumPy：数值计算
- Pandas：数据处理
- Matplotlib：数据可视化

### 第二阶段：AI 入门（4-8 周）

**机器学习基础**
- 监督学习 vs 无监督学习
- 常见算法（回归、分类）
- Scikit-learn 实战

**深度学习入门**
- 神经网络原理
- PyTorch 基础
- 简单项目实践

### 📚 推荐资源
- 《Python 编程：从入门到实践》
- 吴恩达机器学习课程
- Kaggle 入门竞赛

建议边学边练，每个知识点都动手写代码！

需要我为您制定详细的学习计划吗？"""
    
    def _generate_help_reply(self) -> str:
        """生成帮助回复"""
        return """## 📋 我可以帮您做什么？

### 📚 学习路线
- "生成 Agent 开发学习路线"
- "第1层包含哪些内容？"

### 🎯 主题查询
- "Python 如何入门？"
- "如何准备 AI 面试？"
- "Transformer 架构是什么？"

### 💡 技术问答
- 询问具体的技术问题
- 了解概念和原理

### 📖 知识检索
- 查询已生成的学习内容
- 获取学习资源推荐

请输入您的问题，我会尽力帮助您！"""
    
    def _search_knowledge(self, message: str) -> Optional[str]:
        """搜索知识库"""
        keywords = message.lower().split()
        
        results = []
        for layer, data in self._knowledge_cache.items():
            for topic in data.get('topics', []):
                topic_name = topic.get('name', '').lower()
                if any(k in topic_name for k in keywords):
                    results.append({
                        "layer": layer,
                        "topic": topic.get('name', ''),
                        "description": topic.get('description', '')
                    })
        
        if results:
            reply = "📚 找到相关内容：\n\n"
            for r in results[:3]:
                reply += f"**第{r['layer']}层 - {r['topic']}**\n"
                reply += f"{r['description']}\n\n"
            return reply
        
        return None
    
    def _generate_default_reply(self, message: str, role: str) -> str:
        """生成默认回复"""
        return f"""我收到您的问题了：

> "{message}"

我是 {role}，我可以帮助您：

- 📚 制定学习路线
- 🎯 解答技术问题
- 💡 推荐学习资源

您可以尝试这样问我：
- "我想学习 Agent 开发"
- "Python 如何入门 AI？"
- "如何准备 AI 面试？"

请告诉我您具体想了解什么？"""
    
    def get_history(self, agent_name: str, limit: int = 20) -> List[Dict]:
        """获取对话历史"""
        context = self._contexts.get(agent_name)
        if context:
            return context.get_history(limit)
        return []
    
    def clear_history(self, agent_name: str):
        """清空对话历史"""
        context = self._contexts.get(agent_name)
        if context:
            context.clear()
    
    def get_available_agents(self) -> List[Dict]:
        """获取可用的 Agent 列表"""
        agents = self.config_manager.get_all_agents_config()
        
        result = []
        for name, config in agents.items():
            result.append({
                "name": name,
                "role": config.get('role', ''),
                "layer": config.get('layer'),
                "model": config.get('model', ''),
                "enabled": config.get('enabled', False)
            })
        
        return result
    
    # ==================== 架构师相关方法 ====================
    
    def _is_architecture_question(self, question: str) -> bool:
        """
        判断是否为架构类问题
        
        Args:
            question: 用户问题
            
        Returns:
            是否为架构类问题
        """
        for keyword in ARCHITECTURE_KEYWORDS:
            if keyword in question:
                return True
        return False
    
    def _identify_target_layer(self, question: str) -> Optional[int]:
        """
        识别问题应该由哪个层级的Agent处理
        
        Args:
            question: 用户问题
            
        Returns:
            层级编号，无法确定时返回None
        """
        question_lower = question.lower()
        
        # 根据关键词匹配层级
        layer_scores = {}
        for layer, framework in KNOWLEDGE_FRAMEWORK.items():
            score = 0
            # 检查主题关键词
            for topic in framework.get('topics', []):
                if topic.lower() in question_lower:
                    score += 2
            # 检查扩展关键词
            for keyword in framework.get('keywords', []):
                if keyword.lower() in question_lower:
                    score += 1
            
            if score > 0:
                layer_scores[layer] = score
        
        # 返回得分最高的层级
        if layer_scores:
            return max(layer_scores, key=layer_scores.get)
        
        return None
    
    def _architect_answer(self, question: str) -> str:
        """
        架构师直接回答架构类问题
        
        Args:
            question: 用户问题
            
        Returns:
            架构师回答
        """
        # 使用 LLM 生成架构师回答
        return self._call_llm_for_architect(question)
    
    # ==================== LLM 路由判断 ====================
    
    def _llm_route_and_answer(self, question: str) -> str:
        """
        通过 LLM 判断问题应该如何处理，并生成回答
        
        Args:
            question: 用户问题
            
        Returns:
            回答内容
        """
        # 使用 LLM 判断路由
        route_result = self._llm_judge_route(question)
        
        if route_result["action"] == "direct_answer":
            # 直接回答（架构类问题）
            return self._call_llm_for_architect(question)
        elif route_result["action"] == "delegate":
            # 委派给子 Agent
            target_layer = route_result.get("layer")
            if target_layer:
                return self._call_llm_for_worker(question, target_layer)
            else:
                # 无法确定层级，直接回答
                return self._call_llm_for_architect(question)
        else:
            # 默认直接回答
            return self._call_llm_for_architect(question)
    
    def _llm_judge_route(self, question: str) -> Dict[str, Any]:
        """
        通过 LLM 判断问题的路由方式
        
        Args:
            question: 用户问题
            
        Returns:
            {"action": "direct_answer" | "delegate", "layer": 1-5 | None, "reason": "..."}
        """
        system_prompt = """你是 Learning Agent 系统的路由判断器。

## 你的任务
分析用户问题，判断应该由谁来回答：

### 1. 架构师直接回答 (direct_answer)
以下类型的问题由架构师直接回答：
- 系统架构设计问题
- 技术方案选型与对比
- 最佳实践指导
- 整体性、框架性问题
- 概念性、原理性概述

### 2. 委派给子Agent (delegate)
以下类型的问题需要委派给专业子Agent：
- 具体知识点的详细讲解
- 学习内容、教程
- 代码示例、实现细节
- 某个技术点的深入探讨

## 5个子Agent及其负责领域
- Layer 1 (基础理论层): AI基础、LLM原理、Agent概念、架构模式的理论知识
- Layer 2 (技术栈层): Python编程、Agent框架(LangChain/AutoGen)、向量数据库、深度学习框架
- Layer 3 (核心能力层): 任务规划、工具调用、记忆管理、多Agent协作的实现
- Layer 4 (工程实践层): 项目经验、性能优化、部署运维、安全合规
- Layer 5 (面试准备层): 算法题、系统设计、行为面试、项目阐述

## 输出格式
必须严格按照JSON格式输出：
{"action": "direct_answer" 或 "delegate", "layer": 1-5或null, "reason": "判断理由"}

只输出JSON，不要其他内容。"""
        
        prompt = f"""用户问题：{question}

请判断这个问题应该如何处理，输出JSON格式的判断结果。"""
        
        if self._llm_service:
            try:
                response = self._llm_service.call(prompt, system_prompt)
                # 解析 JSON
                import json
                content = response.content.strip()
                # 提取 JSON
                if '{' in content and '}' in content:
                    start = content.find('{')
                    end = content.rfind('}') + 1
                    json_str = content[start:end]
                    result = json.loads(json_str)
                    return result
            except Exception as e:
                print(f"⚠️ LLM 路由判断失败: {e}")
        
        # 回退到默认判断
        return {"action": "direct_answer", "layer": None, "reason": "LLM判断失败，使用默认直接回答"}
    
    def _call_llm_for_architect(self, question: str) -> str:
        """通过 LLM 生成架构师回答"""
        system_prompt = """你是 Learning Agent 系统的架构师 (Architect Agent)。

## 你的身份
你是资深AI系统架构师，拥有丰富的Agent系统设计和实践经验。

## 你的职责
- 从架构层面解答用户问题
- 提供技术选型建议
- 给出最佳实践指导

## 回复原则
1. 给出专业的架构建议
2. 包含设计思路、技术选型、优缺点分析
3. 从系统整体角度思考问题
4. 关注可扩展性、可维护性、性能

## 回复格式
使用 Markdown 格式，包含：
- 问题分析
- 架构建议/技术对比
- 具体方案
- 注意事项"""
        
        prompt = f"""用户问题：{question}

请从架构师角度给出专业、详细的回答。"""
        
        if self._llm_service:
            response = self._llm_service.call(prompt, system_prompt)
            return response.content
        else:
            return self._fallback_architect_answer(question)
    
    def _fallback_architect_answer(self, question: str) -> str:
        """LLM 不可用时的回退回答"""
        return f"""## 架构师回答

您的问题是：{question}

抱歉，LLM 服务暂时不可用。请稍后重试或使用 Task 模式生成详细内容。

您可以执行 `python cli.py task "{question}"` 来获取详细解答。"""
    
    def _delegate_to_worker(self, question: str, target_layer: int) -> str:
        """
        将具体知识点问题委派给子Agent
        
        Args:
            question: 用户问题
            target_layer: 目标层级
            
        Returns:
            委派说明回复
        """
        framework = KNOWLEDGE_FRAMEWORK.get(target_layer, {})
        layer_name = framework.get('name', f'第{target_layer}层')
        agent_name = framework.get('agent_name', 'unknown_worker')
        topics = framework.get('topics', [])
        
        # 检查知识库是否有相关内容
        knowledge_reply = self._search_knowledge(question)
        if knowledge_reply:
            # 使用 LLM 基于知识库内容生成回复
            return self._call_llm_with_knowledge(question, knowledge_reply, layer_name, topics)
        
        # 没有缓存知识时，使用 LLM 直接回答
        return self._call_llm_for_worker(question, target_layer, layer_name, agent_name, topics)
    
    def _call_llm_with_knowledge(
        self,
        question: str,
        knowledge: str,
        layer_name: str,
        topics: List[str]
    ) -> str:
        """基于知识库内容通过 LLM 生成回复"""
        system_prompt = f"""你是 Learning Agent 系统的知识专家，专注于{layer_name}。

## 你的职责
- 基于知识库内容回答用户问题
- 提供准确、详细的技术解答
- 结合实际应用场景

## 相关知识领域
{', '.join(topics)}

## 回复格式
使用 Markdown 格式，清晰明了。"""
        
        prompt = f"""用户问题：{question}

相关知识库内容：
{knowledge}

请基于以上知识库内容，详细回答用户的问题。"""
        
        if self._llm_service:
            response = self._llm_service.call(prompt, system_prompt)
            return response.content
        else:
            return f"""## 📚 知识库检索结果

您的问题属于 **{layer_name}** 的范畴。

{knowledge}

---

**相关主题**：{', '.join(topics)}"""
    
    def _call_llm_for_worker(
        self,
        question: str,
        target_layer: int,
        layer_name: str = None,
        agent_name: str = None,
        topics: List[str] = None
    ) -> str:
        """通过 LLM 生成知识点回答"""
        # 自动获取层级信息
        framework = KNOWLEDGE_FRAMEWORK.get(target_layer, {})
        layer_name = layer_name or framework.get('name', f'第{target_layer}层')
        agent_name = agent_name or framework.get('agent_name', 'unknown_worker')
        topics = topics or framework.get('topics', [])
        
        system_prompt = f"""你是 Learning Agent 系统的专业知识专家。

## 你的专业领域
- 层级：{layer_name} (第{target_layer}层)
- 主题：{', '.join(topics)}

## 你的职责
- 解答用户关于该领域的具体问题
- 提供深入的技术讲解
- 给出学习建议和实践指导

## 回复格式
使用 Markdown 格式，包含：
- 问题解答
- 关键知识点
- 实践建议
- 学习资源推荐（如有）"""
        
        prompt = f"""用户问题：{question}

请从{layer_name}的专业角度，详细解答用户的问题。"""
        
        if self._llm_service:
            response = self._llm_service.call(prompt, system_prompt)
            return response.content
        else:
            return self._fallback_worker_answer(question, layer_name, agent_name, topics)
    
    def _fallback_worker_answer(
        self,
        question: str,
        layer_name: str,
        agent_name: str,
        topics: List[str]
    ) -> str:
        """LLM 不可用时的回退回答"""
        return f"""## 🎯 问题分析

我识别到您的问题「{question}」属于 **{layer_name}** 的范畴。

**该层级的主要主题**：
- {', '.join(topics)}

**负责该领域的专业Agent**：{agent_name}

---

您可以通过以下方式获取详细解答：

1. **Task模式**：执行 `python cli.py task "{question}"` 让专业Agent生成完整内容
2. **继续对话**：告诉我您具体想了解哪个主题的详细内容

您希望我如何继续帮助您？"""


# 全局服务实例
_ask_service: Optional[AskService] = None


def get_ask_service(config_path: str = "config/agent_config.yaml") -> AskService:
    """获取 AskService 单例"""
    global _ask_service
    if _ask_service is None:
        _ask_service = AskService(config_path=config_path)
    return _ask_service