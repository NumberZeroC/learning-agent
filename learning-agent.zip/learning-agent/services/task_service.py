#!/usr/bin/env python3
"""
Task 服务 - 后台任务执行

功能：
- 批量知识生成
- 异步任务执行
- 进度跟踪
- 结果持久化
"""

import os
import sys
import json
import asyncio
import threading
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents import (
    TaskCoordinator,
    TaskPriority,
    EventType,
    EventBus,
    get_event_bus,
    reset_event_bus,
    KNOWLEDGE_FRAMEWORK
)


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class TaskResult:
    """任务结果"""
    task_id: str
    status: TaskStatus
    request: str
    results: Dict[int, Any] = field(default_factory=dict)
    error: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    elapsed_seconds: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "status": self.status.value,
            "request": self.request,
            "results": self.results,
            "error": self.error,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "elapsed_seconds": self.elapsed_seconds
        }


class TaskService:
    """
    Task 服务 - 后台任务执行
    
    功能：
    - 执行批量知识生成任务
    - 支持指定层级
    - 进度跟踪和回调
    - 结果持久化
    """
    
    def __init__(
        self,
        config_path: str = "config/agent_config.yaml",
        output_dir: str = "data/knowledge",
        verbose: bool = True
    ):
        self.config_path = Path(config_path)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.verbose = verbose
        
        # 任务管理
        self._tasks: Dict[str, TaskResult] = {}
        self._coordinator: Optional[TaskCoordinator] = None
        
        # 进度回调
        self._progress_callbacks: List[callable] = []
        
        if self.verbose:
            print("✅ TaskService 初始化完成")
    
    def _log(self, message: str):
        """输出日志"""
        if self.verbose:
            print(message)
    
    def _init_coordinator(self):
        """初始化协调器"""
        if self._coordinator is None:
            reset_event_bus()
            self._coordinator = TaskCoordinator(
                config_path=str(self.config_path),
                output_dir=str(self.output_dir)
            )
            self._coordinator.initialize()
    
    def execute(
        self,
        request: str,
        layers: Optional[List[int]] = None,
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout: float = 300.0
    ) -> Dict[str, Any]:
        """
        执行任务（同步）
        
        Args:
            request: 任务请求
            layers: 指定层级（None 表示全部）
            priority: 任务优先级
            timeout: 超时时间（秒）
            
        Returns:
            执行结果
        """
        import time
        import uuid
        
        # 创建任务ID
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        start_time = time.time()
        
        # 创建任务记录
        task_result = TaskResult(
            task_id=task_id,
            status=TaskStatus.RUNNING,
            request=request,
            started_at=datetime.now().isoformat()
        )
        self._tasks[task_id] = task_result
        
        self._log(f"\n🚀 开始执行任务: {task_id}")
        self._log(f"   请求: {request[:50]}...")
        
        try:
            # 初始化协调器
            self._init_coordinator()
            
            # 如果指定了层级，修改知识框架
            if layers:
                self._log(f"   指定层级: {layers}")
                # 只执行指定层级
                result = self._execute_specific_layers(request, layers, priority, timeout)
            else:
                # 执行全部层级
                result = self._coordinator.execute_concurrent(request, priority)
            
            # 更新任务状态
            elapsed = time.time() - start_time
            task_result.elapsed_seconds = elapsed
            task_result.completed_at = datetime.now().isoformat()
            
            if result.get('success', False):
                task_result.status = TaskStatus.COMPLETED
                task_result.results = result.get('results', {})
                self._log(f"   ✅ 任务完成 (耗时: {elapsed:.2f}秒)")
            else:
                task_result.status = TaskStatus.FAILED
                task_result.error = result.get('error', '未知错误')
                self._log(f"   ❌ 任务失败: {task_result.error}")
            
            return {
                "success": task_result.status == TaskStatus.COMPLETED,
                "task_id": task_id,
                "results": task_result.results,
                "elapsed_seconds": elapsed,
                "status": task_result.status.value
            }
            
        except Exception as e:
            elapsed = time.time() - start_time
            task_result.status = TaskStatus.FAILED
            task_result.error = str(e)
            task_result.elapsed_seconds = elapsed
            task_result.completed_at = datetime.now().isoformat()
            
            self._log(f"   ❌ 任务异常: {e}")
            
            return {
                "success": False,
                "task_id": task_id,
                "error": str(e),
                "elapsed_seconds": elapsed,
                "status": TaskStatus.FAILED.value
            }
    
    def _execute_specific_layers(
        self,
        request: str,
        layers: List[int],
        priority: TaskPriority,
        timeout: float
    ) -> Dict[str, Any]:
        """执行指定层级的任务"""
        results = {}
        
        for layer in layers:
            if layer not in KNOWLEDGE_FRAMEWORK:
                self._log(f"   ⚠️ 跳过无效层级: {layer}")
                continue
            
            framework = KNOWLEDGE_FRAMEWORK[layer]
            self._log(f"\n   📚 处理第{layer}层: {framework['name']}")
            
            # 创建单层请求
            layer_request = f"为第{layer}层（{framework['name']}）生成学习内容"
            
            try:
                # 使用协调器执行
                result = self._coordinator.execute_concurrent(layer_request, priority)
                
                if result.get('success'):
                    results[layer] = result.get('results', {}).get(layer, {})
                    self._log(f"      ✅ 第{layer}层完成")
                else:
                    self._log(f"      ❌ 第{layer}层失败")
                    
            except Exception as e:
                self._log(f"      ❌ 第{layer}层异常: {e}")
        
        return {
            "success": len(results) > 0,
            "results": results,
            "elapsed_seconds": sum(
                r.get('elapsed_seconds', 0) 
                for r in [results] if isinstance(results, dict)
            )
        }
    
    async def execute_async(
        self,
        request: str,
        layers: Optional[List[int]] = None,
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout: float = 300.0
    ) -> Dict[str, Any]:
        """
        异步执行任务
        
        Args:
            request: 任务请求
            layers: 指定层级
            priority: 优先级
            timeout: 超时时间
            
        Returns:
            执行结果
        """
        # 在线程池中执行同步方法
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.execute(request, layers, priority, timeout)
        )
    
    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取任务状态"""
        if task_id in self._tasks:
            return self._tasks[task_id].to_dict()
        return None
    
    def get_all_tasks(self) -> List[Dict[str, Any]]:
        """获取所有任务"""
        return [task.to_dict() for task in self._tasks.values()]
    
    def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        if task_id in self._tasks:
            task = self._tasks[task_id]
            if task.status == TaskStatus.RUNNING:
                task.status = TaskStatus.CANCELLED
                task.completed_at = datetime.now().isoformat()
                return True
        return False
    
    def register_progress_callback(self, callback: callable):
        """注册进度回调"""
        self._progress_callbacks.append(callback)
    
    def get_generated_knowledge(self) -> Dict[str, Any]:
        """获取已生成的知识"""
        knowledge = {}
        
        for layer_file in self.output_dir.glob("layer_*_knowledge.json"):
            try:
                with open(layer_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    layer = data.get('layer', 0)
                    knowledge[str(layer)] = data
            except Exception as e:
                self._log(f"⚠️ 读取文件失败: {layer_file}")
        
        return knowledge
    
    def get_summary(self) -> Dict[str, Any]:
        """获取学习路线总结"""
        summary_file = self.output_dir / "learning_summary.json"
        
        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        # 如果没有总结，生成一个
        return self._generate_summary()
    
    def _generate_summary(self) -> Dict[str, Any]:
        """生成学习路线总结"""
        knowledge = self.get_generated_knowledge()
        
        summary = {
            "generated_at": datetime.now().isoformat(),
            "total_layers": len(knowledge),
            "layers": {},
            "total_hours": 0
        }
        
        for layer_str, data in knowledge.items():
            layer = int(layer_str)
            framework = KNOWLEDGE_FRAMEWORK.get(layer, {})
            
            topics = data.get('topics', [])
            hours = data.get('total_hours', 0)
            
            summary["layers"][layer_str] = {
                "name": framework.get('name', f"第{layer}层"),
                "topics_count": len(topics),
                "total_hours": hours
            }
            summary["total_hours"] += hours
        
        # 保存总结
        summary_file = self.output_dir / "learning_summary.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        return summary


# 全局 Task 服务实例
_task_service: Optional[TaskService] = None


def get_task_service(
    config_path: str = "config/agent_config.yaml",
    output_dir: str = "data/knowledge",
    verbose: bool = True
) -> TaskService:
    """获取 Task 服务单例"""
    global _task_service
    if _task_service is None:
        _task_service = TaskService(config_path, output_dir, verbose)
    return _task_service