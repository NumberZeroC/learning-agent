#!/usr/bin/env python3
"""
LLM Service - 大模型调用服务

统一封装所有大模型调用，支持：
- 多模型配置
- 缓存机制
- 错误处理
- 调用追踪
"""

import os
import sys
import json
import time
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
import threading
from functools import lru_cache

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))


@dataclass
class LLMConfig:
    """LLM 配置"""
    provider: str = "dashscope"
    model: str = "qwen3.5-plus"
    api_key: str = ""
    base_url: str = ""
    temperature: float = 0.7
    max_tokens: int = 4000
    top_p: float = 0.9
    
    def to_dict(self) -> Dict:
        return {
            "provider": self.provider,
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "top_p": self.top_p
        }


@dataclass
class LLMResponse:
    """LLM 响应"""
    content: str
    model: str
    usage: Dict[str, int] = field(default_factory=dict)
    latency: float = 0.0
    cached: bool = False
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict:
        return {
            "content": self.content,
            "model": self.model,
            "usage": self.usage,
            "latency": self.latency,
            "cached": self.cached,
            "timestamp": self.timestamp
        }


class LLMService:
    """
    LLM 服务 - 统一封装大模型调用
    
    功能：
    - 统一的 API 调用接口
    - 支持多个模型提供商
    - 自动缓存结果
    - 错误处理和重试
    - 调用日志记录
    """
    
    def __init__(
        self,
        config_path: str = "config/agent_config.yaml",
        cache_enabled: bool = True,
        cache_ttl: int = 300
    ):
        self.config_path = Path(config_path)
        self.cache_enabled = cache_enabled
        self.cache_ttl = cache_ttl
        
        # 加载配置
        self._load_provider_config()
        
        # 缓存
        self._cache: Dict[str, Dict] = {}
        self._cache_lock = threading.Lock()
        
        # 调用统计
        self._call_stats = {
            "total_calls": 0,
            "cached_calls": 0,
            "failed_calls": 0,
            "total_latency": 0.0
        }
        
        print(f"✅ LLMService 初始化完成")
        print(f"   Provider: {self.default_config.provider}")
        print(f"   Model: {self.default_config.model}")
    
    def _load_provider_config(self):
        """加载提供商配置"""
        # 默认配置
        self.default_config = LLMConfig()
        
        # 从配置文件加载
        if self.config_path.exists():
            try:
                import yaml
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                
                providers = config.get('providers', {})
                
                # 获取 DashScope 配置
                if 'dashscope' in providers:
                    ds_config = providers['dashscope']
                    self.default_config.provider = 'dashscope'
                    self.default_config.base_url = ds_config.get('base_url', '')
                    
                    # API Key
                    api_key_env = ds_config.get('api_key_env', 'DASHSCOPE_API_KEY')
                    api_key_value = ds_config.get('api_key_value', '')
                    self.default_config.api_key = os.getenv(api_key_env) or api_key_value
                    
                    # 模型配置
                    models = ds_config.get('models', {})
                    if 'qwen3.5-plus' in models:
                        model_config = models['qwen3.5-plus']
                        self.default_config.model = 'qwen3.5-plus'
                        self.default_config.temperature = model_config.get('temperature', 0.7)
                        self.default_config.max_tokens = model_config.get('max_tokens', 4000)
                        self.default_config.top_p = model_config.get('top_p', 0.9)
                
            except Exception as e:
                print(f"⚠️ 加载配置失败: {e}")
        
        # 尝试从环境变量获取 API Key
        if not self.default_config.api_key:
            self.default_config.api_key = os.getenv('DASHSCOPE_API_KEY', '')
    
    def _get_cache_key(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        config: Optional[LLMConfig] = None
    ) -> str:
        """生成缓存键"""
        content = f"{system_prompt or ''}|{prompt}|{json.dumps(config.to_dict() if config else self.default_config.to_dict(), sort_keys=True)}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def _check_cache(self, cache_key: str) -> Optional[LLMResponse]:
        """检查缓存"""
        if not self.cache_enabled:
            return None
        
        with self._cache_lock:
            if cache_key in self._cache:
                cached_item = self._cache[cache_key]
                # 检查是否过期
                if time.time() - cached_item['timestamp'] < self.cache_ttl:
                    response = cached_item['response']
                    response.cached = True
                    return response
        
        return None
    
    def _save_cache(self, cache_key: str, response: LLMResponse):
        """保存缓存"""
        if not self.cache_enabled:
            return
        
        with self._cache_lock:
            self._cache[cache_key] = {
                'response': response,
                'timestamp': time.time()
            }
            
            # 清理过期缓存
            current_time = time.time()
            expired_keys = [
                k for k, v in self._cache.items()
                if current_time - v['timestamp'] > self.cache_ttl
            ]
            for k in expired_keys:
                del self._cache[k]
    
    def call(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        config: Optional[LLMConfig] = None,
        use_cache: bool = True
    ) -> LLMResponse:
        """
        调用大模型
        
        Args:
            prompt: 用户提示
            system_prompt: 系统提示（可选）
            config: LLM配置（可选）
            use_cache: 是否使用缓存
            
        Returns:
            LLM 响应
        """
        config = config or self.default_config
        
        # 检查缓存
        if use_cache:
            cache_key = self._get_cache_key(prompt, system_prompt, config)
            cached_response = self._check_cache(cache_key)
            if cached_response:
                self._call_stats['cached_calls'] += 1
                print(f"   📦 使用缓存响应")
                return cached_response
        
        # 调用大模型
        start_time = time.time()
        
        try:
            content = self._call_dashscope(prompt, system_prompt, config)
            
            latency = time.time() - start_time
            
            response = LLMResponse(
                content=content,
                model=config.model,
                latency=latency,
                cached=False
            )
            
            # 保存缓存
            if use_cache:
                self._save_cache(cache_key, response)
            
            # 更新统计
            self._call_stats['total_calls'] += 1
            self._call_stats['total_latency'] += latency
            
            print(f"   ✅ LLM 调用成功 (耗时: {latency:.2f}s)")
            
            return response
            
        except Exception as e:
            self._call_stats['failed_calls'] += 1
            print(f"   ❌ LLM 调用失败: {e}")
            
            # 返回错误响应
            return LLMResponse(
                content=f"抱歉，大模型调用失败：{str(e)}",
                model=config.model,
                latency=time.time() - start_time,
                cached=False
            )
    
    def _call_dashscope(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        config: Optional[LLMConfig] = None
    ) -> str:
        """
        调用 DashScope API
        
        Args:
            prompt: 用户提示
            system_prompt: 系统提示
            config: LLM 配置
            
        Returns:
            模型输出内容
        """
        import requests
        
        # 构建请求
        headers = {
            "Authorization": f"Bearer {config.api_key}",
            "Content-Type": "application/json"
        }
        
        # 消息格式
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": config.model,
            "messages": messages,
            "temperature": config.temperature,
            "max_tokens": config.max_tokens,
            "top_p": config.top_p
        }
        
        # 发送请求
        url = f"{config.base_url}/chat/completions"
        
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=60
        )
        
        response.raise_for_status()
        
        # 解析响应
        result = response.json()
        
        if 'choices' and len(result['choices']) > 0:
            return result['choices'][0]['message']['content']
        
        raise Exception("响应格式异常")
    
    def chat(
        self,
        messages: List[Dict[str, str]],
        config: Optional[LLMConfig] = None
    ) -> LLMResponse:
        """
        多轮对话
        
        Args:
            messages: 消息列表 [{"role": "user/assistant", "content": "..."}]
            config: LLM 配置
            
        Returns:
            LLM 响应
        """
        config = config or self.default_config
        
        # 构建完整 prompt（用于缓存）
        full_prompt = json.dumps(messages, ensure_ascii=False)
        cache_key = self._get_cache_key(full_prompt, None, config)
        
        # 检查缓存
        cached_response = self._check_cache(cache_key)
        if cached_response:
            self._call_stats['cached_calls'] += 1
            return cached_response
        
        start_time = time.time()
        
        try:
            import requests
            
            headers = {
                "Authorization": f"Bearer {config.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": config.model,
                "messages": messages,
                "temperature": config.temperature,
                "max_tokens": config.max_tokens,
                "top_p": config.top_p
            }
            
            url = f"{config.base_url}/chat/completions"
            
            response = requests.post(
                url,
                headers=headers,
                json=payload,
                timeout=60
            )
            
            response.raise_for_status()
            
            result = response.json()
            
            content = result['choices'][0]['message']['content'] if result.get('choices') else ""
            
            latency = time.time() - start_time
            
            llm_response = LLMResponse(
                content=content,
                model=config.model,
                latency=latency
            )
            
            self._save_cache(cache_key, llm_response)
            self._call_stats['total_calls'] += 1
            self._call_stats['total_latency'] += latency
            
            return llm_response
            
        except Exception as e:
            self._call_stats['failed_calls'] += 1
            return LLMResponse(
                content=f"对话调用失败: {str(e)}",
                model=config.model,
                latency=time.time() - start_time
            )
    
    def get_stats(self) -> Dict[str, Any]:
        """获取调用统计"""
        stats = self._call_stats.copy()
        if stats['total_calls'] > 0:
            stats['avg_latency'] = stats['total_latency'] / stats['total_calls']
            stats['cache_rate'] = stats['cached_calls'] / stats['total_calls']
        else:
            stats['avg_latency'] = 0
            stats['cache_rate'] = 0
        return stats
    
    def clear_cache(self):
        """清空缓存"""
        with self._cache_lock:
            self._cache.clear()
        print("📦 缓存已清空")


# 全局 LLM 服务实例
_llm_service: Optional[LLMService] = None


def get_llm_service(
    config_path: str = "config/agent_config.yaml",
    cache_enabled: bool = True
) -> LLMService:
    """获取 LLM 服务单例"""
    global _llm_service
    if _llm_service is None:
        _llm_service = LLMService(config_path=config_path, cache_enabled=cache_enabled)
    return _llm_service


def call_llm(
    prompt: str,
    system_prompt: Optional[str] = None,
    use_cache: bool = True
) -> str:
    """
    快捷调用大模型
    
    Args:
        prompt: 用户提示
        system_prompt: 系统提示
        use_cache: 是否使用缓存
        
    Returns:
        模型输出内容
    """
    service = get_llm_service()
    response = service.call(prompt, system_prompt, use_cache=use_cache)
    return response.content