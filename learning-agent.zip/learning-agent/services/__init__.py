#!/usr/bin/env python3
"""
Services 模块

提供两种核心服务模式：
- AskService: Web 问答助手，实时对话交互
- TaskService: 后台任务执行，批量知识生成
"""

from .ask_service import AskService, get_ask_service
from .task_service import TaskService, get_task_service
from .llm_service import LLMService, get_llm_service, call_llm

__all__ = [
    'AskService',
    'get_ask_service',
    'TaskService',
    'get_task_service',
    'LLMService',
    'get_llm_service',
    'call_llm'
]