#!/usr/bin/env python3
"""
深度知识生成器

功能：
- 读取已生成的知识点
- 对每个知识点调用大模型生成详细内容
- 保存为结构化文件（Markdown + JSON）
- 支持 Web 页面查看
"""

import os
import sys
import json
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
import re

# 项目路径
PROJECT_DIR = Path(__file__).parent
CONFIG_PATH = PROJECT_DIR / "config" / "agent_config.yaml"
OUTPUT_DIR = PROJECT_DIR / "data" / "deep_knowledge"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


class DeepKnowledgeGenerator:
    """深度知识生成器"""
    
    def __init__(self):
        # 加载配置
        self.api_key, self.base_url, self.model = self._load_config()
        
        # 提示词模板
        self.prompt_templates = {
            "concept": self._get_concept_prompt(),
            "skill": self._get_skill_prompt(),
            "tool": self._get_tool_prompt(),
            "practice": self._get_practice_prompt()
        }
    
    def _load_config(self):
        """加载配置"""
        import yaml
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        providers = config.get('providers', {})
        dashscope = providers.get('dashscope', {})
        
        api_key = dashscope.get('api_key_value', '')
        base_url = dashscope.get('base_url', '')
        model = dashscope.get('models', {}).get('qwen3.5-plus', {})
        
        return api_key, base_url, 'qwen3.5-plus'
    
    def _get_concept_prompt(self) -> str:
        """概念类知识点提示词"""
        return """你是一个专业的 AI 教育专家。请详细讲解以下概念：

**概念名称：** {name}

**所属主题：** {topic}

**所属层级：** {layer}

请按照以下结构输出详细内容：

## 1. 概念定义
用简洁准确的语言定义这个概念（200-300 字）

## 2. 核心要点
列出 3-5 个核心要点，每个要点详细解释（每个 100-150 字）

## 3. 工作原理
解释这个概念是如何工作的，可以用流程图或步骤说明（300-500 字）

## 4. 应用场景
列举 2-3 个实际应用场景，说明在什么情况下使用（每个场景 100-150 字）

## 5. 代码示例
提供一个完整的代码示例，展示如何使用这个概念（带详细注释）

## 6. 常见问题
列出 2-3 个学习者常问的问题，并给出解答

## 7. 相关概念
列出 3-5 个相关或相似的概念，说明它们的区别和联系

## 8. 学习资源
推荐 2-3 个优质学习资源（书籍、课程、文档链接）

**输出要求：**
- 使用 Markdown 格式
- 语言通俗易懂，避免过度专业化
- 代码示例要完整可运行
- 总字数 1500-2500 字"""
    
    def _get_skill_prompt(self) -> str:
        """技能类知识点提示词"""
        return """你是一个资深的 AI 工程师。请详细讲解以下技能：

**技能名称：** {name}

**所属主题：** {topic}

请按照以下结构输出详细内容：

## 1. 技能概述
说明这是什么技能，为什么重要（200-300 字）

## 2. 前置知识
列出学习这个技能需要先掌握的知识（3-5 项）

## 3. 技能详解
详细讲解这个技能的具体内容，分步骤说明（500-800 字）

## 4. 操作步骤
提供清晰的操作步骤，每一步详细说明（5-8 个步骤）

## 5. 实战案例
提供一个完整的实战案例，展示如何应用这个技能（带代码）

## 6. 最佳实践
列出 3-5 个最佳实践和注意事项

## 7. 常见错误
列举 2-3 个常见错误及解决方法

## 8. 练习题目
提供 2-3 个练习题目，帮助巩固这个技能

**输出要求：**
- 使用 Markdown 格式
- 步骤清晰，可操作性强
- 代码示例完整
- 总字数 1500-2500 字"""
    
    def _get_tool_prompt(self) -> str:
        """工具类知识点提示词"""
        return """你是一个工具使用专家。请详细讲解以下工具：

**工具名称：** {name}

**所属主题：** {topic}

请按照以下结构输出详细内容：

## 1. 工具介绍
说明这是什么工具，解决什么问题（200-300 字）

## 2. 核心功能
列出 3-5 个核心功能，每个功能详细说明

## 3. 安装配置
提供完整的安装和配置步骤（带命令）

## 4. 基本用法
介绍基本使用方法，提供代码示例

## 5. 高级用法
介绍 2-3 个高级使用技巧

## 6. 实际案例
提供一个完整的实际使用案例

## 7. 替代方案
列出 2-3 个同类工具，对比优缺点

## 8. 参考文档
提供官方文档链接和优质教程

**输出要求：**
- 使用 Markdown 格式
- 命令和代码要准确
- 总字数 1500-2500 字"""
    
    def _get_practice_prompt(self) -> str:
        """实践类知识点提示词"""
        return """你是一个项目实战专家。请详细讲解以下实践内容：

**实践名称：** {name}

**所属主题：** {topic}

请按照以下结构输出详细内容：

## 1. 实践目标
说明这个实践要达到什么目标（200-300 字）

## 2. 背景介绍
介绍实践的背景和实际应用场景

## 3. 技术选型
说明使用哪些技术，为什么选择这些技术

## 4. 架构设计
提供系统架构图和设计说明

## 5. 实现步骤
分步骤详细说明实现过程（8-12 个步骤）

## 6. 核心代码
提供核心代码实现（带详细注释）

## 7. 测试验证
说明如何测试和验证实践成果

## 8. 部署上线
提供部署上线的步骤和注意事项

## 9. 经验总结
总结实践中的经验教训和最佳实践

**输出要求：**
- 使用 Markdown 格式
- 步骤完整，可复现
- 代码可运行
- 总字数 2000-3000 字"""
    
    def _classify_knowledge(self, name: str, context: str = "") -> str:
        """分类知识点类型"""
        name_lower = name.lower()
        
        # 简单规则分类
        if any(word in name_lower for word in ['概念', '原理', '机制', '基础', '理论']):
            return 'concept'
        elif any(word in name_lower for word in ['技能', '方法', '技巧', '实践', '实现']):
            return 'skill'
        elif any(word in name_lower for word in ['工具', '框架', '库', '平台', '系统']):
            return 'tool'
        else:
            return 'practice'
    
    def generate_content(self, knowledge_point: Dict, topic_info: Dict, layer_info: Dict) -> Dict:
        """生成单个知识点的详细内容"""
        name = knowledge_point.get('name', '')
        topic_name = topic_info.get('topic_name', '')
        layer_name = layer_info.get('layer_name', '')
        
        # 分类知识点
        knowledge_type = self._classify_knowledge(name)
        prompt_template = self.prompt_templates.get(knowledge_type, self.prompt_templates['concept'])
        
        # 填充提示词
        prompt = prompt_template.format(
            name=name,
            topic=topic_name,
            layer=layer_name
        )
        
        # 调用 API
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个专业的 AI 教育专家，擅长将复杂的技术概念讲解得通俗易懂。"
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.7,
            "max_tokens": 4000
        }
        
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(url, data=data, headers=headers, method='POST')
            
            print(f"     🤖 调用大模型生成：{name}")
            
            with urllib.request.urlopen(req, timeout=120) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if 'choices' in result and len(result['choices']) > 0:
                    content = result['choices'][0]['message']['content']
                    
                    return {
                        "success": True,
                        "name": name,
                        "type": knowledge_type,
                        "content": content,
                        "generated_at": datetime.now().isoformat(),
                        "tokens_used": result.get('usage', {}).get('total_tokens', 0)
                    }
                else:
                    return {
                        "success": False,
                        "error": f"API 返回异常：{result}",
                        "name": name
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": f"生成失败：{str(e)}",
                "name": name
            }
    
    def save_content(self, content_data: Dict, layer_num: int, topic_name: str):
        """保存生成的内容"""
        # 创建目录
        layer_dir = OUTPUT_DIR / f"layer_{layer_num}"
        layer_dir.mkdir(parents=True, exist_ok=True)
        
        topic_dir = layer_dir / self._sanitize_filename(topic_name)
        topic_dir.mkdir(parents=True, exist_ok=True)
        
        # 保存 Markdown
        md_file = topic_dir / f"{self._sanitize_filename(content_data['name'])}.md"
        
        with open(md_file, 'w', encoding='utf-8') as f:
            f.write(f"# {content_data['name']}\n\n")
            f.write(f"**生成时间：** {content_data['generated_at']}\n\n")
            f.write(f"**类型：** {content_data['type']}\n\n")
            f.write("---\n\n")
            f.write(content_data['content'])
        
        # 保存 JSON
        json_file = topic_dir / f"{self._sanitize_filename(content_data['name'])}.json"
        
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(content_data, f, ensure_ascii=False, indent=2)
        
        print(f"       ✅ 已保存：{md_file.name}")
    
    def _sanitize_filename(self, name: str) -> str:
        """清理文件名中的非法字符"""
        # 替换非法字符
        name = re.sub(r'[<>:"/\\|？*]', '_', name)
        name = name.replace(' ', '_')
        return name[:100]  # 限制长度
    
    def process_layer(self, layer_data: Dict):
        """处理整个层级的知识点"""
        layer_num = layer_data.get('layer', 0)
        layer_name = layer_data.get('layer_name', '')
        topics = layer_data.get('topics', [])
        
        print(f"\n{'='*60}")
        print(f"📚 开始生成第{layer_num}层详细内容：{layer_name}")
        print(f"{'='*60}\n")
        
        total_points = 0
        success_count = 0
        
        for topic in topics:
            topic_name = topic.get('topic_name', '')
            subtopics = topic.get('subtopics', [])
            
            print(f"  📖 主题：{topic_name}")
            print(f"     知识点数：{len(subtopics)}\n")
            
            for i, subtopic in enumerate(subtopics, 1):
                print(f"     [{i}/{len(subtopics)}] ", end='')
                
                # 生成内容
                result = self.generate_content(subtopic, topic, layer_data)
                
                if result.get('success'):
                    # 保存内容
                    self.save_content(result, layer_num, topic_name)
                    success_count += 1
                else:
                    print(f"       ❌ 失败：{result.get('error', 'unknown')}")
                
                total_points += 1
        
        print(f"\n  ✅ 第{layer_num}层完成：成功{success_count}/{total_points} 个知识点")
        
        return {
            "layer": layer_num,
            "layer_name": layer_name,
            "total_points": total_points,
            "success_count": success_count,
            "failed_count": total_points - success_count
        }
    
    def run(self):
        """运行深度知识生成"""
        print("="*60)
        print("🤖 深度知识生成器")
        print("="*60)
        
        # 读取已生成的知识
        generated_dir = PROJECT_DIR / "data" / "generated_knowledge"
        
        if not generated_dir.exists():
            print("❌ 未找到已生成的知识文件，请先运行 knowledge_generator.py")
            return
        
        # 获取所有层级文件
        layer_files = sorted(generated_dir.glob("layer_*_generated.json"))
        
        if not layer_files:
            print("❌ 未找到层级文件")
            return
        
        print(f"\n📂 找到 {len(layer_files)} 个层级文件")
        
        start_time = datetime.now()
        results = []
        
        for layer_file in layer_files:
            print(f"\n📄 处理文件：{layer_file.name}")
            
            with open(layer_file, 'r', encoding='utf-8') as f:
                layer_data = json.load(f)
            
            result = self.process_layer(layer_data)
            results.append(result)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # 生成总结
        self._generate_summary(results, duration)
    
    def _generate_summary(self, results: List[Dict], duration: float):
        """生成总结"""
        total_points = sum(r['total_points'] for r in results)
        success_count = sum(r['success_count'] for r in results)
        
        summary = {
            "generated_at": datetime.now().isoformat(),
            "duration_seconds": duration,
            "total_layers": len(results),
            "total_points": total_points,
            "success_count": success_count,
            "failed_count": total_points - success_count,
            "success_rate": f"{success_count/total_points*100:.1f}%" if total_points > 0 else "0%",
            "layers": results
        }
        
        # 保存总结
        summary_file = OUTPUT_DIR / "generation_summary.json"
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        print("\n" + "="*60)
        print("📊 深度知识生成总结")
        print("="*60)
        print(f"   总层级：{len(results)}")
        print(f"   总知识点：{total_points}")
        print(f"   成功：{success_count}")
        print(f"   失败：{total_points - success_count}")
        print(f"   成功率：{summary['success_rate']}")
        print(f"   总耗时：{duration:.2f}秒 ({duration/60:.1f}分钟)")
        print(f"\n📄 总结已保存：{summary_file}")
        print(f"📁 输出目录：{OUTPUT_DIR}")


def main():
    """主函数"""
    generator = DeepKnowledgeGenerator()
    generator.run()


if __name__ == "__main__":
    main()
