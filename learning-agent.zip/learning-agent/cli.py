#!/usr/bin/env python3
"""
Learning Agent 统一入口

支持两种运行模式：
1. ask 模式 - Web 问答助手，实时对话交互
2. task 模式 - 后台命令执行，批量任务处理

使用方法：
    python cli.py ask                    # 启动 Web 服务
    python cli.py task "生成学习路线"    # 执行后台任务
    python cli.py task --file input.txt  # 从文件读取任务
"""

import os
import sys
import argparse
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Optional, List

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))


class LearningAgentCLI:
    """Learning Agent 命令行接口"""
    
    def __init__(self):
        self.project_dir = Path(__file__).parent
        
    def run_ask_mode(self, host: str = "0.0.0.0", port: int = 5001, debug: bool = False):
        """
        运行 Ask 模式 - Web 问答助手
        
        Args:
            host: 监听地址
            port: 监听端口
            debug: 是否开启调试模式
        """
        print("\n" + "="*60)
        print("🌐 Learning Agent - Ask 模式")
        print("="*60)
        print(f"启动 Web 问答服务...")
        print(f"地址: http://{host}:{port}")
        print("="*60 + "\n")
        
        # 导入并启动 Web 应用
        from web.app import app, initialize_ask_service
        
        # 初始化 Ask 服务
        initialize_ask_service()
        
        # 启动 Flask
        app.run(host=host, port=port, debug=debug)
    
    def run_task_mode(
        self,
        request: str,
        output_dir: str = "data/knowledge",
        layers: Optional[List[int]] = None,
        verbose: bool = True
    ) -> dict:
        """
        运行 Task 模式 - 后台任务执行
        
        Args:
            request: 任务请求内容
            output_dir: 输出目录
            layers: 指定生成的层级（None 表示全部）
            verbose: 是否输出详细信息
            
        Returns:
            执行结果
        """
        print("\n" + "="*60)
        print("⚙️  Learning Agent - Task 模式")
        print("="*60)
        print(f"任务: {request[:50]}...")
        print(f"输出目录: {output_dir}")
        if layers:
            print(f"指定层级: {layers}")
        print("="*60 + "\n")
        
        # 导入 TaskService
        from services.task_service import TaskService
        
        # 创建任务服务
        service = TaskService(output_dir=output_dir, verbose=verbose)
        
        # 执行任务
        result = service.execute(request, layers=layers)
        
        # 输出结果
        print("\n" + "="*60)
        print("📊 执行结果")
        print("="*60)
        print(f"成功: {result['success']}")
        print(f"耗时: {result.get('elapsed_seconds', 0):.2f} 秒")
        
        if result['success']:
            results = result.get('results', {})
            print(f"\n生成的知识层: {len(results)} 层")
            
            total_hours = 0
            for layer, data in sorted(results.items()):
                if isinstance(data, dict):
                    topics = data.get('topics', [])
                    hours = data.get('total_hours', 0)
                    total_hours += hours
                    print(f"   第{layer}层: {len(topics)} 个主题, {hours} 小时")
            
            print(f"\n总计: {total_hours} 小时")
            print(f"输出目录: {Path(output_dir).absolute()}")
        else:
            print(f"错误: {result.get('error', '未知错误')}")
        
        return result
    
    def run_task_from_file(
        self,
        file_path: str,
        output_dir: str = "data/knowledge",
        verbose: bool = True
    ) -> dict:
        """
        从文件读取任务并执行
        
        Args:
            file_path: 任务文件路径
            output_dir: 输出目录
            verbose: 是否输出详细信息
            
        Returns:
            执行结果
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            print(f"❌ 文件不存在: {file_path}")
            return {"success": False, "error": "文件不存在"}
        
        # 读取文件内容
        with open(file_path, 'r', encoding='utf-8') as f:
            request = f.read().strip()
        
        print(f"📄 从文件读取任务: {file_path}")
        
        return self.run_task_mode(request, output_dir=output_dir, verbose=verbose)
    
    def show_status(self):
        """显示系统状态"""
        print("\n" + "="*60)
        print("📊 Learning Agent 系统状态")
        print("="*60)
        
        # 检查配置
        config_path = self.project_dir / "config" / "agent_config.yaml"
        print(f"\n📁 配置文件: {config_path}")
        print(f"   存在: {'✅' if config_path.exists() else '❌'}")
        
        # 检查数据目录
        data_dir = self.project_dir / "data" / "knowledge"
        print(f"\n📁 数据目录: {data_dir}")
        print(f"   存在: {'✅' if data_dir.exists() else '❌'}")
        
        if data_dir.exists():
            # 统计已生成的知识
            knowledge_files = list(data_dir.glob("layer_*_knowledge.json"))
            print(f"   已生成知识: {len(knowledge_files)} 层")
            
            # 检查总结文件
            summary_file = data_dir / "learning_summary.json"
            if summary_file.exists():
                import json
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary = json.load(f)
                print(f"   总学习时长: {summary.get('total_hours', 0)} 小时")
        
        # 检查环境变量
        print(f"\n🔑 环境变量:")
        api_key = os.getenv("DASHSCOPE_API_KEY", "")
        print(f"   DASHSCOPE_API_KEY: {'✅ 已设置' if api_key else '❌ 未设置'}")
        
        # 检查依赖
        print(f"\n📦 依赖检查:")
        try:
            import autogen
            print(f"   AutoGen: ✅")
        except ImportError:
            print(f"   AutoGen: ❌ (pip install pyautogen)")
        
        try:
            import flask
            print(f"   Flask: ✅")
        except ImportError:
            print(f"   Flask: ❌ (pip install flask)")
        
        print("\n" + "="*60)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="Learning Agent - AI 学习路线生成系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # Ask 模式 - 启动 Web 问答服务
  python cli.py ask
  python cli.py ask --port 8080
  python cli.py ask --debug
  
  # Task 模式 - 执行后台任务
  python cli.py task "生成完整的 Agent 开发学习路线"
  python cli.py task "生成 Python 入门学习路线" --layers 1,2
  python cli.py task --file tasks.txt
  
  # 查看系统状态
  python cli.py status
        """
    )
    
    subparsers = parser.add_subparsers(dest="mode", help="运行模式")
    
    # Ask 模式
    ask_parser = subparsers.add_parser("ask", help="启动 Web 问答服务 (Ask 模式)")
    ask_parser.add_argument("--host", default="0.0.0.0", help="监听地址 (默认: 0.0.0.0)")
    ask_parser.add_argument("--port", type=int, default=5001, help="监听端口 (默认: 5001)")
    ask_parser.add_argument("--debug", action="store_true", help="开启调试模式")
    
    # Task 模式
    task_parser = subparsers.add_parser("task", help="执行后台任务 (Task 模式)")
    task_parser.add_argument("request", nargs="?", help="任务请求内容")
    task_parser.add_argument("--file", "-f", help="从文件读取任务")
    task_parser.add_argument("--output", "-o", default="data/knowledge", help="输出目录")
    task_parser.add_argument("--layers", "-l", help="指定层级，用逗号分隔 (如: 1,2,3)")
    task_parser.add_argument("--quiet", "-q", action="store_true", help="静默模式")
    
    # Status 命令
    status_parser = subparsers.add_parser("status", help="显示系统状态")
    
    args = parser.parse_args()
    
    cli = LearningAgentCLI()
    
    if args.mode == "ask":
        cli.run_ask_mode(host=args.host, port=args.port, debug=args.debug)
    
    elif args.mode == "task":
        # 解析层级
        layers = None
        if args.layers:
            layers = [int(x.strip()) for x in args.layers.split(",")]
        
        if args.file:
            cli.run_task_from_file(
                file_path=args.file,
                output_dir=args.output,
                verbose=not args.quiet
            )
        elif args.request:
            cli.run_task_mode(
                request=args.request,
                output_dir=args.output,
                layers=layers,
                verbose=not args.quiet
            )
        else:
            task_parser.print_help()
            print("\n❌ 请提供任务内容或使用 --file 指定任务文件")
    
    elif args.mode == "status":
        cli.show_status()
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()