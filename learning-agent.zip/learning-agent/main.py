#!/usr/bin/env python3
"""
AutoGen 多 Agent 学习架构生成器

每个 Agent 负责知识框架中的一层，协同生成完整的学习路线
"""

import os
import sys
import json
import yaml
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

# 添加路径
sys.path.insert(0, str(Path(__file__).parent))

try:
    from autogen import ConversableAgent, UserProxyAgent, GroupChat, GroupChatManager
    AUTOGEN_AVAILABLE = True
except ImportError:
    print("⚠️ 未安装 AutoGen，请运行：pip install pyautogen")
    AUTOGEN_AVAILABLE = False


class LearningAgentSystem:
    """学习 Agent 系统"""
    
    def __init__(self, config_path: str = "config/agent_config.yaml"):
        self.config = self._load_config(config_path)
        self.data_dir = Path("data/knowledge")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.agents = {}
        self.user_proxy = None
        self.group_chat = None
        self.group_chat_manager = None
        
        # 知识框架
        self.knowledge_framework = {
            1: {
                "name": "基础理论层",
                "topics": ["AI 基础", "LLM 原理", "Agent 概念", "架构模式"]
            },
            2: {
                "name": "技术栈层",
                "topics": ["Python 编程", "深度学习框架", "Agent 框架", "向量数据库"]
            },
            3: {
                "name": "核心能力层",
                "topics": ["任务规划", "工具调用", "记忆管理", "多 Agent 协作"]
            },
            4: {
                "name": "工程实践层",
                "topics": ["项目经验", "性能优化", "部署运维", "安全合规"]
            },
            5: {
                "name": "面试准备层",
                "topics": ["算法题", "系统设计", "行为面试", "项目阐述"]
            }
        }
    
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        config_file = Path(config_path)
        if not config_file.exists():
            config_file = Path(__file__).parent / config_path
        
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        return {}
    
    def create_agents(self):
        """创建所有 Agent"""
        if not AUTOGEN_AVAILABLE:
            print("❌ AutoGen 不可用")
            return
        
        # 创建用户代理
        self.user_proxy = UserProxyAgent(
            name="User",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=0,
            code_execution_config=False
        )
        
        # 创建各层 Agent
        for agent_config in self.config.get('agents', []):
            layer = agent_config.get('layer')
            framework = self.knowledge_framework.get(layer, {})
            
            system_message = self._generate_system_message(agent_config, framework)
            
            agent = ConversableAgent(
                name=agent_config.get('name'),
                system_message=system_message,
                llm_config={
                    "config_list": [{
                        "model": self.config.get('llm', {}).get('model', 'qwen-plus'),
                        "api_key": os.getenv('DASHSCOPE_API_KEY', '')
                    }]
                },
                human_input_mode="NEVER",
                max_consecutive_auto_reply=10
            )
            
            self.agents[layer] = agent
            print(f"✅ 创建 Agent: {agent_config.get('name')} (第{layer}层)")
    
    def _generate_system_message(self, agent_config: Dict, framework: Dict) -> str:
        """生成 Agent 系统消息"""
        return f"""你是{agent_config.get('role')}，负责{agent_config.get('goal')}。

## 负责层级
{framework.get('name')}

## 主要主题
{', '.join(framework.get('topics', []))}

## 任务要求
1. 为每个主题生成详细的学习内容
2. 包含关键知识点（key_points）
3. 推荐学习资源（resources）
4. 估算学习时间（小时）
5. 标注难度级别（beginner/intermediate/advanced）

## 输出格式
请严格按照以下 JSON 格式输出：
{{
    "layer": 层级数字，
    "layer_name": "层级名称",
    "topics": [
        {{
            "name": "主题名称",
            "description": "主题描述",
            "subtopics": [
                {{
                    "name": "子主题",
                    "key_points": ["知识点 1", "知识点 2"],
                    "resources": ["资源链接 1", "资源链接 2"],
                    "estimated_hours": 10,
                    "difficulty": "intermediate"
                }}
            ],
            "estimated_hours": 40,
            "priority": "high"
        }}
    ],
    "total_hours": 总学习时长，
    "recommended_order": ["推荐学习顺序"]
}}

## 注意事项
- 内容要详细、实用
- 资源链接要真实有效
- 时间估算要合理
- 只输出 JSON，不要其他内容
"""
    
    def generate_knowledge(self, layer: int = None):
        """生成指定层级的知识内容"""
        if not AUTOGEN_AVAILABLE:
            return
        
        layers_to_generate = [layer] if layer else list(self.agents.keys())
        
        for layer_num in layers_to_generate:
            if layer_num not in self.agents:
                continue
            
            agent = self.agents[layer_num]
            framework = self.knowledge_framework.get(layer_num, {})
            
            print(f"\n{'='*60}")
            print(f"📚 生成第{layer_num}层知识：{framework.get('name')}")
            print(f"{'='*60}\n")
            
            # 生成学习内容的提示
            prompt = f"""请为"{framework.get('name')}"生成详细的学习内容。

包含的主题：{', '.join(framework.get('topics', []))}

请为每个主题生成：
1. 详细描述
2. 3-5 个子主题
3. 每个子主题的关键知识点（至少 3 个）
4. 推荐学习资源（书籍、课程、文档链接）
5. 估算学习时间（小时）
6. 难度级别

只输出 JSON 格式，不要其他内容。"""
            
            # 发起对话
            response = self.user_proxy.initiate_chat(
                agent,
                message=prompt,
                max_turns=2,
                summary_method="last_msg"
            )
            
            # 提取并保存结果
            knowledge_data = self._extract_json(response.chat_history)
            
            if knowledge_data:
                self._save_knowledge(layer_num, knowledge_data)
                print(f"✅ 第{layer_num}层知识已保存")
            else:
                print(f"❌ 第{layer_num}层知识生成失败")
    
    def _extract_json(self, chat_history: List[Dict]) -> Dict:
        """从对话历史中提取 JSON"""
        for msg in reversed(chat_history):
            content = msg.get('content', '')
            
            # 尝试提取 JSON
            start = content.find('{')
            end = content.rfind('}') + 1
            
            if start >= 0 and end > start:
                json_str = content[start:end]
                try:
                    return json.loads(json_str)
                except json.JSONDecodeError:
                    continue
        
        return {}
    
    def _save_knowledge(self, layer: int, data: Dict):
        """保存知识数据"""
        output_file = self.data_dir / f"layer_{layer}_knowledge.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"📄 已保存：{output_file}")
    
    def generate_all(self):
        """生成所有层级的知识"""
        print("🚀 开始生成完整学习架构...\n")
        
        for layer in sorted(self.knowledge_framework.keys()):
            self.generate_knowledge(layer)
        
        print("\n✅ 所有层级知识生成完成！")
    
    def generate_summary(self):
        """生成学习路线总结"""
        summary = {
            "generated_at": datetime.now().isoformat(),
            "total_layers": len(self.knowledge_framework),
            "layers": {}
        }
        
        total_hours = 0
        
        for layer in sorted(self.knowledge_framework.keys()):
            data_file = self.data_dir / f"layer_{layer}_knowledge.json"
            
            if data_file.exists():
                with open(data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                summary["layers"][layer] = {
                    "name": self.knowledge_framework[layer]["name"],
                    "topics_count": len(data.get("topics", [])),
                    "total_hours": data.get("total_hours", 0)
                }
                total_hours += data.get("total_hours", 0)
        
        summary["total_hours"] = total_hours
        
        # 保存总结
        summary_file = self.data_dir / "learning_summary.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        print(f"\n📊 学习路线总结已保存：{summary_file}")
        print(f"   总层级：{len(self.knowledge_framework)}")
        print(f"   预计总时长：{total_hours} 小时")
        
        return summary


def main():
    """主函数"""
    print("="*60)
    print("🤖 AutoGen 多 Agent 学习架构生成器")
    print("="*60)
    
    # 创建系统
    system = LearningAgentSystem()
    
    # 创建 Agent
    system.create_agents()
    
    # 生成所有知识
    system.generate_all()
    
    # 生成总结
    system.generate_summary()
    
    print("\n✅ 任务完成！")
    print(f"📁 数据目录：{system.data_dir.absolute()}")


if __name__ == "__main__":
    main()
