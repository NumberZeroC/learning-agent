#!/usr/bin/env python3
"""
知识生成任务执行器

功能：
- 主 Agent 接收学习架构图
- 分解任务并分配给子 Agent
- 多 Agent 并发执行
- 每个 Agent 内部知识点串行生成
- 保存结果供 Web 查看
"""

import os
import sys
import json
import yaml
import asyncio
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

from agents.config_manager import get_config_manager


class KnowledgeGenerator:
    """知识生成器（单个 Agent 使用）"""
    
    def __init__(self, agent_config: Dict, api_key: str, base_url: str):
        self.agent_config = agent_config
        self.api_key = api_key
        self.base_url = base_url
        self.model = agent_config.get('model', 'qwen3.5-plus')
        self.system_prompt = agent_config.get('system_prompt', '')
        self.layer = agent_config.get('layer', 0)
    
    async def generate_knowledge(self, topic: Dict, context: str = "") -> Dict:
        """
        生成单个主题的知识（使用同步 API 调用）
        
        Args:
            topic: 主题信息（包含名称、描述等）
            context: 上下文信息
        
        Returns:
            生成的知识内容
        """
        url = f"{self.base_url}/chat/completions"
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        # 构建用户消息
        user_message = f"""你是{self.agent_config.get('role', '专家')}。

## 任务
生成第{self.layer}层"{topic.get('name', '')}"主题的详细学习内容。

## 主题信息
- 名称：{topic.get('name', '')}
- 描述：{topic.get('description', '')}
- 优先级：{topic.get('priority', 'medium')}

{context}

## 输出要求
请严格按照以下 JSON 格式输出：
{{
    "topic_name": "主题名称",
    "description": "详细描述（300-500 字）",
    "subtopics": [
        {{
            "name": "子主题名称",
            "key_points": ["知识点 1", "知识点 2", "知识点 3"],
            "resources": [
                {{"type": "book", "title": "书名", "author": "作者"}},
                {{"type": "course", "title": "课程名", "platform": "平台"}},
                {{"type": "doc", "title": "文档名", "url": "链接"}}
            ],
            "estimated_hours": 10,
            "difficulty": "beginner"
        }}
    ],
    "total_hours": 总学习时长，
    "prerequisites": ["前置知识 1", "前置知识 2"],
    "learning_outcomes": ["学习成果 1", "学习成果 2"]
}}

注意：
1. 只输出 JSON，不要其他内容
2. 确保 JSON 格式正确
3. 内容要详细、实用
4. 资源要真实有效"""
        
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": self.system_prompt[:2000]  # 限制系统提示长度
                },
                {
                    "role": "user",
                    "content": user_message
                }
            ],
            "temperature": self.agent_config.get('llm_config', {}).get('temperature', 0.7),
            "max_tokens": 4000
        }
        
        try:
            # 使用同步 API 调用
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(url, data=data, headers=headers, method='POST')
            
            with urllib.request.urlopen(req, timeout=120) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if 'choices' in result and len(result['choices']) > 0:
                    content = result['choices'][0]['message']['content']
                    return self._extract_json(content)
                else:
                    return {
                        "error": f"API 请求失败：{result.get('error', {}).get('message', 'unknown')}",
                        "topic_name": topic.get('name', '')
                    }
                        
        except Exception as e:
            return {
                "error": f"生成失败：{str(e)}",
                "topic_name": topic.get('name', '')
            }
    
    def _extract_json(self, content: str) -> Dict:
        """从内容中提取 JSON"""
        import re
        # 查找 JSON 块
        match = re.search(r'\{[\s\S]*\}', content)
        if match:
            try:
                return json.loads(match.group())
            except:
                pass
        
        # 如果解析失败，返回原始内容
        return {
            "raw_content": content,
            "topic_name": "未知主题"
        }


class TaskExecutor:
    """任务执行器（主 Agent 使用）"""
    
    def __init__(self, config_path: str = "config/agent_config.yaml"):
        self.config_manager = get_config_manager()
        self.config_manager.config_path = Path(config_path)
        self.config_manager.load_config()
        
        # 获取 API 配置
        providers = self.config_manager.get_config("providers", {})
        dashscope = providers.get("dashscope", {})
        
        self.api_key = dashscope.get('api_key_value', os.getenv('DASHSCOPE_API_KEY', ''))
        self.base_url = dashscope.get('base_url', 'https://coding.dashscope.aliyuncs.com/v1')
        
        # 输出目录
        self.output_dir = Path("data/generated_knowledge")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 初始化 Agent 生成器
        self.agent_generators = {}
        self._init_generators()
    
    def _init_generators(self):
        """初始化所有 Agent 生成器"""
        agents_config = self.config_manager.get_config("agents", {})
        
        for agent_name, config in agents_config.items():
            if config.get('enabled', False) and config.get('layer', 0) > 0:
                self.agent_generators[agent_name] = KnowledgeGenerator(
                    config,
                    self.api_key,
                    self.base_url
                )
        
        print(f"✅ 初始化 {len(self.agent_generators)} 个子 Agent 生成器")
    
    def execute_task(self, architecture: Dict) -> Dict:
        """
        执行知识生成任务（同步版本）
        
        Args:
            architecture: 学习架构图
        
        Returns:
            执行结果
        """
        print("\n" + "="*60)
        print("🚀 开始执行知识生成任务")
        print("="*60)
        
        start_time = datetime.now()
        
        # 1. 解析架构图
        layers = architecture.get('layers', [])
        print(f"\n📋 解析架构图：{len(layers)} 个层级")
        
        # 2. 并发执行各层级（使用线程池）
        print(f"\n🤖 启动 {len(layers)} 个子 Agent 并发执行")
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = []
            for layer in layers:
                layer_num = layer.get('layer', 0)
                agent_name = self._get_agent_for_layer(layer_num)
                
                if agent_name and agent_name in self.agent_generators:
                    futures.append(executor.submit(self._execute_layer_sync, agent_name, layer))
            
            # 等待所有任务完成
            results = []
            for future in futures:
                try:
                    results.append(future.result())
                except Exception as e:
                    results.append(e)
        
        # 4. 汇总结果
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        summary = self._create_summary(results, duration)
        
        # 5. 保存结果
        self._save_results(summary)
        
        print(f"\n✅ 任务完成！总耗时：{duration:.2f}秒")
        
        return summary
    
    def _get_agent_for_layer(self, layer: int) -> Optional[str]:
        """根据层级获取对应的 Agent"""
        agents_config = self.config_manager.get_config("agents", {})
        
        for agent_name, config in agents_config.items():
            if config.get('layer') == layer and config.get('enabled', False):
                return agent_name
        
        return None
    
    def _execute_layer_sync(self, agent_name: str, layer_data: Dict) -> Dict:
        """执行单个层级的知识生成（同步版本）"""
        generator = self.agent_generators[agent_name]
        layer_num = layer_data.get('layer', 0)
        topics = layer_data.get('topics', [])
        
        print(f"\n  📚 开始生成第{layer_num}层知识（{agent_name}）")
        print(f"     主题数：{len(topics)}")
        
        layer_result = {
            "layer": layer_num,
            "layer_name": layer_data.get('name', ''),
            "agent": agent_name,
            "topics": [],
            "start_time": datetime.now().isoformat(),
            "status": "running"
        }
        
        # 串行生成每个主题的知识
        for i, topic in enumerate(topics, 1):
            print(f"     ├─ 生成主题 {i}/{len(topics)}: {topic.get('name', '')}")
            
            context = f"这是第{i}个主题，共{len(topics)}个主题。"
            
            # 生成知识（使用事件循环）
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                knowledge = loop.run_until_complete(generator.generate_knowledge(topic, context))
            finally:
                loop.close()
            
            # 添加元数据
            knowledge['topic_index'] = i
            knowledge['priority'] = topic.get('priority', 'medium')
            
            layer_result['topics'].append(knowledge)
            
            print(f"     │  ✅ 完成：{knowledge.get('topic_name', 'unknown')}")
        
        layer_result['end_time'] = datetime.now().isoformat()
        layer_result['status'] = "completed"
        
        print(f"  ✅ 第{layer_num}层生成完成")
        
        return layer_result
    
    def _create_summary(self, results: List, duration: float) -> Dict:
        """创建执行总结"""
        summary = {
            "generated_at": datetime.now().isoformat(),
            "duration_seconds": duration,
            "total_layers": len(results),
            "total_topics": 0,
            "layers": [],
            "statistics": {
                "success": 0,
                "failed": 0,
                "total_hours": 0
            }
        }
        
        for result in results:
            if isinstance(result, Exception):
                summary['layers'].append({
                    "error": str(result),
                    "status": "failed"
                })
                summary['statistics']['failed'] += 1
            else:
                summary['layers'].append(result)
                summary['total_topics'] += len(result.get('topics', []))
                summary['statistics']['success'] += 1
                
                # 统计总学习时长
                for topic in result.get('topics', []):
                    summary['statistics']['total_hours'] += topic.get('total_hours', 0)
        
        return summary
    
    def _save_results(self, summary: Dict):
        """保存生成结果"""
        # 保存完整结果
        output_file = self.output_dir / f"knowledge_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        print(f"\n📄 结果已保存：{output_file}")
        
        # 保存按层级分类的结果
        for layer_data in summary['layers']:
            if layer_data.get('status') == 'completed':
                layer_num = layer_data.get('layer', 0)
                layer_file = self.output_dir / f"layer_{layer_num}_generated.json"
                
                with open(layer_file, 'w', encoding='utf-8') as f:
                    json.dump(layer_data, f, ensure_ascii=False, indent=2)
                
                print(f"📄 第{layer_num}层已保存：{layer_file}")
        
        # 更新学习总结
        self._update_learning_summary(summary)
    
    def _update_learning_summary(self, summary: Dict):
        """更新学习总结文件"""
        summary_file = Path("data/knowledge/learning_summary.json")
        
        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                learning_summary = json.load(f)
        else:
            learning_summary = {
                "generated_at": datetime.now().isoformat(),
                "total_layers": 0,
                "total_topics": 0,
                "total_hours": 0,
                "layers": {}
            }
        
        # 更新统计
        learning_summary['total_layers'] = summary['total_layers']
        learning_summary['total_topics'] = summary['total_topics']
        learning_summary['total_hours'] = summary['statistics']['total_hours']
        learning_summary['last_generated'] = summary['generated_at']
        
        # 更新各层信息
        for layer_data in summary['layers']:
            if layer_data.get('status') == 'completed':
                layer_num = str(layer_data.get('layer', 0))
                learning_summary['layers'][layer_num] = {
                    "name": layer_data.get('layer_name', ''),
                    "agent": layer_data.get('agent', ''),
                    "topics_count": len(layer_data.get('topics', [])),
                    "status": "generated",
                    "generated_at": layer_data.get('end_time', '')
                }
        
        # 保存
        summary_file.parent.mkdir(parents=True, exist_ok=True)
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(learning_summary, f, ensure_ascii=False, indent=2)
        
        print(f"📊 学习总结已更新：{summary_file}")


# 学习架构图（ hardcoded，实际可以从文件读取）
LEARNING_ARCHITECTURE = {
    "name": "Agent 开发学习路线",
    "version": "1.0",
    "layers": [
        {
            "layer": 1,
            "name": "基础理论层",
            "topics": [
                {"name": "AI 基础", "description": "机器学习和深度学习基础", "priority": "high"},
                {"name": "LLM 原理", "description": "大语言模型核心原理", "priority": "high"},
                {"name": "Agent 概念", "description": "AI Agent 核心概念", "priority": "high"},
                {"name": "架构模式", "description": "常见 Agent 架构模式", "priority": "medium"}
            ]
        },
        {
            "layer": 2,
            "name": "技术栈层",
            "topics": [
                {"name": "Python 编程", "description": "Python 核心技能", "priority": "high"},
                {"name": "Agent 框架", "description": "主流 Agent 开发框架", "priority": "high"},
                {"name": "向量数据库", "description": "向量存储与检索", "priority": "high"}
            ]
        },
        {
            "layer": 3,
            "name": "核心能力层",
            "topics": [
                {"name": "任务规划", "description": "复杂任务分解与规划", "priority": "high"},
                {"name": "工具调用", "description": "Function Calling 技术", "priority": "high"},
                {"name": "记忆管理", "description": "短期与长期记忆", "priority": "high"},
                {"name": "多 Agent 协作", "description": "多 Agent 系统设计", "priority": "medium"}
            ]
        },
        {
            "layer": 4,
            "name": "工程实践层",
            "topics": [
                {"name": "项目经验", "description": "典型 Agent 项目", "priority": "high"},
                {"name": "性能优化", "description": "系统性能优化", "priority": "medium"},
                {"name": "部署运维", "description": "生产环境部署", "priority": "medium"}
            ]
        },
        {
            "layer": 5,
            "name": "面试准备层",
            "topics": [
                {"name": "算法题", "description": "编程算法准备", "priority": "high"},
                {"name": "系统设计", "description": "系统设计面试", "priority": "high"},
                {"name": "行为面试", "description": "软技能面试", "priority": "medium"}
            ]
        }
    ]
}


def main():
    """主函数"""
    print("="*60)
    print("🤖 知识生成任务执行器")
    print("="*60)
    
    # 创建执行器
    executor = TaskExecutor()
    
    # 执行任务
    summary = executor.execute_task(LEARNING_ARCHITECTURE)
    
    # 打印总结
    print("\n" + "="*60)
    print("📊 生成总结")
    print("="*60)
    print(f"   总层级：{summary['total_layers']}")
    print(f"   总主题：{summary['total_topics']}")
    print(f"   总时长：{summary['statistics']['total_hours']} 小时")
    print(f"   成功：{summary['statistics']['success']}")
    print(f"   失败：{summary['statistics']['failed']}")
    print(f"   耗时：{summary['duration_seconds']:.2f}秒")


if __name__ == "__main__":
    main()
