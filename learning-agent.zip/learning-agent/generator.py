#!/usr/bin/env python3
"""
学习架构生成器 - 简化版（无需 AutoGen）

模拟多 Agent 协作，生成完整学习路线
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List


class KnowledgeGenerator:
    """知识生成器（模拟多 Agent）"""
    
    def __init__(self):
        self.data_dir = Path("data/knowledge")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # 知识框架定义
        self.framework = {
            1: {
                "name": "基础理论层",
                "topics": self._get_theory_topics()
            },
            2: {
                "name": "技术栈层",
                "topics": self._get_tech_stack_topics()
            },
            3: {
                "name": "核心能力层",
                "topics": self._get_core_skill_topics()
            },
            4: {
                "name": "工程实践层",
                "topics": self._get_engineering_topics()
            },
            5: {
                "name": "面试准备层",
                "topics": self._get_interview_topics()
            }
        }
    
    def _get_theory_topics(self) -> List[Dict]:
        """基础理论层主题"""
        return [
            {
                "name": "AI 基础",
                "description": "机器学习和深度学习基础",
                "subtopics": [
                    {
                        "name": "机器学习基础",
                        "key_points": [
                            "监督学习 vs 无监督学习",
                            "常见算法（回归、分类、聚类）",
                            "评估指标（准确率、召回率、F1）",
                            "过拟合与欠拟合"
                        ],
                        "resources": [
                            "吴恩达 Coursera 机器学习课程",
                            "《机器学习》周志华",
                            "https://scikit-learn.org"
                        ],
                        "estimated_hours": 40,
                        "difficulty": "beginner"
                    },
                    {
                        "name": "深度学习基础",
                        "key_points": [
                            "神经网络原理",
                            "反向传播算法",
                            "激活函数（ReLU、Sigmoid）",
                            "优化器（SGD、Adam）"
                        ],
                        "resources": [
                            "吴恩达深度学习专项课程",
                            "《深度学习》花书",
                            "https://pytorch.org"
                        ],
                        "estimated_hours": 60,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "NLP 基础",
                        "key_points": [
                            "词嵌入（Word2Vec、GloVe）",
                            "序列建模（RNN、LSTM）",
                            "注意力机制",
                            "Transformer 架构"
                        ],
                        "resources": [
                            "Stanford CS224N",
                            "《自然语言处理综论》",
                            "https://huggingface.co"
                        ],
                        "estimated_hours": 50,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 150,
                "priority": "high"
            },
            {
                "name": "LLM 原理",
                "description": "大语言模型核心原理",
                "subtopics": [
                    {
                        "name": "Transformer 架构",
                        "key_points": [
                            "Self-Attention 机制",
                            "Multi-Head Attention",
                            "Position Encoding",
                            "Layer Normalization"
                        ],
                        "resources": [
                            "Attention Is All You Need 论文",
                            "The Illustrated Transformer",
                            "https://github.com/huggingface/transformers"
                        ],
                        "estimated_hours": 30,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "预训练与微调",
                        "key_points": [
                            "预训练目标（MLM、CLM）",
                            "监督微调（SFT）",
                            "指令微调",
                            "参数高效微调（LoRA、QLoRA）"
                        ],
                        "resources": [
                            "LLM University 课程",
                            "PEFT 官方文档",
                            "https://arxiv.org/abs/2106.09685"
                        ],
                        "estimated_hours": 40,
                        "difficulty": "advanced"
                    },
                    {
                        "name": "RLHF 与对齐",
                        "key_points": [
                            "人类反馈强化学习",
                            "PPO 算法",
                            "DPO（直接偏好优化）",
                            "模型对齐技术"
                        ],
                        "resources": [
                            "InstructGPT 论文",
                            "DPO 论文",
                            "https://huggingface.co/blog/rlhf"
                        ],
                        "estimated_hours": 35,
                        "difficulty": "advanced"
                    }
                ],
                "estimated_hours": 105,
                "priority": "high"
            },
            {
                "name": "Agent 概念",
                "description": "AI Agent 核心概念",
                "subtopics": [
                    {
                        "name": "Agent 定义与架构",
                        "key_points": [
                            "感知 - 规划 - 行动循环",
                            "Agent 组成要素",
                            "自主性程度",
                            "Agent vs 传统程序"
                        ],
                        "resources": [
                            "《AI Agent 导论》",
                            "https://lilianweng.github.io/posts/2023-06-23-agent/",
                            "LLM Powered Autonomous Agents"
                        ],
                        "estimated_hours": 20,
                        "difficulty": "beginner"
                    },
                    {
                        "name": "规划方法",
                        "key_points": [
                            "Chain of Thought",
                            "Tree of Thoughts",
                            "ReAct 框架",
                            "Reflexion"
                        ],
                        "resources": [
                            "CoT 论文",
                            "ReAct 论文",
                            "https://github.com/ysymyth/ReAct"
                        ],
                        "estimated_hours": 30,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 50,
                "priority": "high"
            },
            {
                "name": "架构模式",
                "description": "常见 Agent 架构模式",
                "subtopics": [
                    {
                        "name": "单 Agent 架构",
                        "key_points": [
                            "ReAct 模式",
                            "工具增强",
                            "记忆管理"
                        ],
                        "resources": [
                            "LangChain 文档",
                            "AutoGen 文档"
                        ],
                        "estimated_hours": 25,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "多 Agent 协作",
                        "key_points": [
                            "协作模式（顺序、并行、投票）",
                            "通信机制",
                            "角色设计",
                            "冲突解决"
                        ],
                        "resources": [
                            "AutoGen 论文",
                            "CrewAI 文档",
                            "https://github.com/microsoft/autogen"
                        ],
                        "estimated_hours": 40,
                        "difficulty": "advanced"
                    }
                ],
                "estimated_hours": 65,
                "priority": "medium"
            }
        ]
    
    def _get_tech_stack_topics(self) -> List[Dict]:
        """技术栈层主题"""
        return [
            {
                "name": "Python 编程",
                "description": "Python 核心技能",
                "subtopics": [
                    {
                        "name": "高级语法",
                        "key_points": ["装饰器", "生成器", "上下文管理器", "元类"],
                        "resources": ["《流畅的 Python》", "Python 官方文档"],
                        "estimated_hours": 30,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "异步编程",
                        "key_points": ["async/await", "asyncio", "并发控制"],
                        "resources": ["《Python 异步编程》", "asyncio 文档"],
                        "estimated_hours": 25,
                        "difficulty": "advanced"
                    }
                ],
                "estimated_hours": 55,
                "priority": "high"
            },
            {
                "name": "Agent 框架",
                "description": "主流 Agent 开发框架",
                "subtopics": [
                    {
                        "name": "LangChain",
                        "key_points": ["Chains", "Agents", "Tools", "Memory", "LangGraph"],
                        "resources": ["https://python.langchain.com", "LangChain 官方教程"],
                        "estimated_hours": 40,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "AutoGen",
                        "key_points": ["ConversableAgent", "GroupChat", "Tool Integration"],
                        "resources": ["https://microsoft.github.io/autogen/", "AutoGen GitHub"],
                        "estimated_hours": 35,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "LlamaIndex",
                        "key_points": ["数据连接", "索引构建", "查询引擎"],
                        "resources": ["https://docs.llamaindex.ai"],
                        "estimated_hours": 30,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 105,
                "priority": "high"
            },
            {
                "name": "向量数据库",
                "description": "向量存储与检索",
                "subtopics": [
                    {
                        "name": "向量检索原理",
                        "key_points": ["相似度计算", "HNSW 索引", "IVF 索引"],
                        "resources": ["《向量检索原理》", "FAISS 文档"],
                        "estimated_hours": 20,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "主流数据库",
                        "key_points": ["Milvus", "Pinecone", "Weaviate", "Chroma"],
                        "resources": ["各官方文档"],
                        "estimated_hours": 30,
                        "difficulty": "beginner"
                    }
                ],
                "estimated_hours": 50,
                "priority": "high"
            }
        ]
    
    def _get_core_skill_topics(self) -> List[Dict]:
        """核心能力层主题"""
        return [
            {
                "name": "任务规划",
                "description": "复杂任务分解与规划",
                "subtopics": [
                    {
                        "name": "任务分解",
                        "key_points": ["分解策略", "依赖关系", "并行执行"],
                        "resources": ["Task Decomposition 论文"],
                        "estimated_hours": 25,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "思维链",
                        "key_points": ["CoT", "Auto-CoT", "Self-Consistency"],
                        "resources": ["CoT 论文", "相关博客"],
                        "estimated_hours": 30,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 55,
                "priority": "high"
            },
            {
                "name": "工具调用",
                "description": "Function Calling 技术",
                "subtopics": [
                    {
                        "name": "Function Calling 原理",
                        "key_points": ["Prompt 设计", "JSON Schema", "参数提取"],
                        "resources": ["OpenAI Function Calling 文档"],
                        "estimated_hours": 20,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "工具集成",
                        "key_points": ["API 调用", "代码执行", "数据库查询"],
                        "resources": ["LangChain Tools 文档"],
                        "estimated_hours": 35,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 55,
                "priority": "high"
            },
            {
                "name": "记忆管理",
                "description": "短期与长期记忆",
                "subtopics": [
                    {
                        "name": "对话历史管理",
                        "key_points": ["滑动窗口", "摘要压缩", "重要性评分"],
                        "resources": ["LangChain Memory 文档"],
                        "estimated_hours": 25,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "长期记忆",
                        "key_points": ["向量存储", "检索增强", "记忆更新"],
                        "resources": ["RAG 相关论文"],
                        "estimated_hours": 35,
                        "difficulty": "advanced"
                    }
                ],
                "estimated_hours": 60,
                "priority": "high"
            },
            {
                "name": "多 Agent 协作",
                "description": "多 Agent 系统设计",
                "subtopics": [
                    {
                        "name": "协作模式",
                        "key_points": ["顺序执行", "并行执行", "投票决策", "辩论模式"],
                        "resources": ["AutoGen GroupChat 文档"],
                        "estimated_hours": 30,
                        "difficulty": "advanced"
                    },
                    {
                        "name": "通信机制",
                        "key_points": ["消息传递", "共享状态", "事件驱动"],
                        "resources": ["分布式系统相关"],
                        "estimated_hours": 25,
                        "difficulty": "advanced"
                    }
                ],
                "estimated_hours": 55,
                "priority": "medium"
            }
        ]
    
    def _get_engineering_topics(self) -> List[Dict]:
        """工程实践层主题"""
        return [
            {
                "name": "项目经验",
                "description": "典型 Agent 项目",
                "subtopics": [
                    {
                        "name": "RAG 系统",
                        "key_points": ["文档问答", "知识库检索", "企业助手"],
                        "resources": ["RAG 实战项目"],
                        "estimated_hours": 40,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "智能客服",
                        "key_points": ["多轮对话", "意图识别", "工单生成"],
                        "resources": ["客服系统案例"],
                        "estimated_hours": 35,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "代码助手",
                        "key_points": ["代码生成", "代码审查", "Bug 修复"],
                        "resources": ["Copilot 相关"],
                        "estimated_hours": 40,
                        "difficulty": "advanced"
                    }
                ],
                "estimated_hours": 115,
                "priority": "high"
            },
            {
                "name": "性能优化",
                "description": "系统性能优化",
                "subtopics": [
                    {
                        "name": "响应时间优化",
                        "key_points": ["流式输出", "缓存策略", "并发处理"],
                        "resources": ["性能优化最佳实践"],
                        "estimated_hours": 25,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "成本优化",
                        "key_points": ["模型选择", "Token 优化", "缓存复用"],
                        "resources": ["LLM 成本优化指南"],
                        "estimated_hours": 20,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 45,
                "priority": "medium"
            },
            {
                "name": "部署运维",
                "description": "生产环境部署",
                "subtopics": [
                    {
                        "name": "部署方式",
                        "key_points": ["云服务", "容器化", "本地部署"],
                        "resources": ["Docker/K8s文档"],
                        "estimated_hours": 30,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "监控告警",
                        "key_points": ["日志收集", "指标监控", "异常告警"],
                        "resources": ["Prometheus/Grafana"],
                        "estimated_hours": 25,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 55,
                "priority": "medium"
            }
        ]
    
    def _get_interview_topics(self) -> List[Dict]:
        """面试准备层主题"""
        return [
            {
                "name": "算法题",
                "description": "编程算法准备",
                "subtopics": [
                    {
                        "name": "数据结构",
                        "key_points": ["数组/链表", "树/图", "堆/栈/队列", "哈希表"],
                        "resources": ["LeetCode", "剑指 Offer"],
                        "estimated_hours": 60,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "算法",
                        "key_points": ["排序/搜索", "动态规划", "贪心", "回溯"],
                        "resources": ["LeetCode Hot 100"],
                        "estimated_hours": 80,
                        "difficulty": "intermediate"
                    }
                ],
                "estimated_hours": 140,
                "priority": "high"
            },
            {
                "name": "系统设计",
                "description": "系统设计面试",
                "subtopics": [
                    {
                        "name": "设计模式",
                        "key_points": ["工厂", "单例", "观察者", "策略"],
                        "resources": ["《设计模式》"],
                        "estimated_hours": 30,
                        "difficulty": "intermediate"
                    },
                    {
                        "name": "Agent 系统设计",
                        "key_points": ["对话系统", "任务规划", "多 Agent 协作"],
                        "resources": ["系统设计案例"],
                        "estimated_hours": 40,
                        "difficulty": "advanced"
                    }
                ],
                "estimated_hours": 70,
                "priority": "high"
            },
            {
                "name": "行为面试",
                "description": "软技能面试",
                "subtopics": [
                    {
                        "name": "常见问题",
                        "key_points": ["自我介绍", "项目经历", "技术难点", "职业规划"],
                        "resources": ["面试准备指南"],
                        "estimated_hours": 15,
                        "difficulty": "beginner"
                    },
                    {
                        "name": "STAR 法则",
                        "key_points": ["Situation", "Task", "Action", "Result"],
                        "resources": ["STAR 法则指南"],
                        "estimated_hours": 10,
                        "difficulty": "beginner"
                    }
                ],
                "estimated_hours": 25,
                "priority": "medium"
            }
        ]
    
    def generate_all(self):
        """生成所有层级知识"""
        print("="*60)
        print("🤖 学习架构生成器 - 多 Agent 模拟")
        print("="*60)
        
        summary = {
            "generated_at": datetime.now().isoformat(),
            "version": "1.0",
            "total_layers": len(self.framework),
            "layers": {},
            "total_hours": 0
        }
        
        for layer_num, layer_data in sorted(self.framework.items()):
            print(f"\n{'='*60}")
            print(f"📚 生成第{layer_num}层：{layer_data['name']}")
            print(f"{'='*60}")
            
            # 构建完整数据
            knowledge_data = {
                "layer": layer_num,
                "layer_name": layer_data['name'],
                "topics": layer_data['topics'],
                "total_hours": sum(t.get('estimated_hours', 0) for t in layer_data['topics']),
                "recommended_order": [t['name'] for t in layer_data['topics']]
            }
            
            # 保存文件
            output_file = self.data_dir / f"layer_{layer_num}_knowledge.json"
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(knowledge_data, f, ensure_ascii=False, indent=2)
            
            print(f"✅ 已保存：{output_file}")
            print(f"   主题数：{len(layer_data['topics'])}")
            print(f"   预计时长：{knowledge_data['total_hours']} 小时")
            
            # 更新总结
            summary["layers"][str(layer_num)] = {
                "name": layer_data['name'],
                "topics_count": len(layer_data['topics']),
                "total_hours": knowledge_data['total_hours']
            }
            summary["total_hours"] += knowledge_data['total_hours']
        
        # 保存总结
        summary_file = self.data_dir / "learning_summary.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        print(f"\n{'='*60}")
        print("✅ 所有层级知识生成完成！")
        print(f"{'='*60}")
        print(f"📊 总计:")
        print(f"   层级数：{len(self.framework)}")
        print(f"   总主题数：{sum(len(l['topics']) for l in self.framework.values())}")
        print(f"   预计总时长：{summary['total_hours']} 小时")
        print(f"   数据目录：{self.data_dir.absolute()}")
        
        return summary


def main():
    """主函数"""
    generator = KnowledgeGenerator()
    generator.generate_all()


if __name__ == "__main__":
    main()
