# 🤖 AutoGen 主从架构重构

**完成时间：** 2026-03-29 21:58  
**架构类型：** Master-Worker（主从架构）

---

## 📊 架构设计

### 架构图

```
┌─────────────────────────────────────────────────────────┐
│                    Master Agent                         │
│                   (master_agent)                        │
│                   主协调者                              │
│                                                         │
│  职责：                                                 │
│  - 接收外部指令                                         │
│  - 任务分解                                             │
│  - 协调子 Agent                                         │
│  - 汇总结果                                             │
└─────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ theory_worker │   │tech_stack_worker│ │core_skill_worker│
│   第 1 层       │   │    第 2 层       │   │    第 3 层       │
│ 基础理论层    │   │  技术栈层      │   │  核心能力层    │
└───────────────┘   └───────────────┘   └───────────────┘
        │                   │                   │
        └───────────────────┼───────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐
│engineering_worker│ │interview_worker │
│    第 4 层         │ │    第 5 层         │
│ 工程实践层      │ │ 面试准备层      │
└─────────────────┘ └─────────────────┘

每个 Agent 都可独立调用大模型 (Qwen/DashScope)
```

---

## 🎯 核心特性

### 1. 主从架构

| 角色 | Agent | 职责 |
|------|-------|------|
| **主 Agent** | master_agent | 任务分解、协调、汇总 |
| **子 Agent 1** | theory_worker | 第 1 层知识生成 |
| **子 Agent 2** | tech_stack_worker | 第 2 层知识生成 |
| **子 Agent 3** | core_skill_worker | 第 3 层知识生成 |
| **子 Agent 4** | engineering_worker | 第 4 层知识生成 |
| **子 Agent 5** | interview_worker | 第 5 层知识生成 |

### 2. 独立大模型调用

所有 Agent 都配置了独立的 LLM 连接：

```python
llm_config = {
    "config_list": [{
        "model": "qwen-plus",
        "api_key": os.getenv("DASHSCOPE_API_KEY")
    }],
    "temperature": 0.7,
    "max_tokens": 4000
}
```

### 3. 协作流程

```
1. 用户指令 → Master Agent
              ↓
2. 任务分解 → 5 个子任务
              ↓
3. 子 Agent 并行执行（各自调用 LLM）
              ↓
4. 结果返回 → Master Agent
              ↓
5. 汇总输出 → 完整学习路线
```

---

## 📁 新增文件

| 文件 | 说明 |
|------|------|
| `autogen_architecture.py` | AutoGen 主从架构实现（完整版） |
| `run_autogen.py` | 简化演示版运行脚本 |
| `config/autogen_config.yaml` | AutoGen 配置文件 |
| `AUTOGEN_ARCHITECTURE.md` | 本文档 |

---

## 🚀 使用方式

### 方式 1: 简化演示版（推荐）

```bash
cd /home/admin/.openclaw/workspace/learning-agent
python3 run_autogen.py
```

**特点：**
- ✅ 无需 API Key
- ✅ 快速演示架构
- ✅ 使用已有数据

### 方式 2: 完整版（需要 API Key）

```bash
export DASHSCOPE_API_KEY="your-api-key"
python3 autogen_architecture.py
```

**特点：**
- ✅ 真实 AutoGen 协作
- ✅ 动态生成内容
- ✅ 需要 API Key

---

## 📊 运行结果

### 执行流程

```
============================================================
🤖 Learning Agent - AutoGen 主从架构（简化版）
============================================================
✅ 系统初始化完成
   主 Agent: 1 个 (master_agent)
   子 Agent: 5 个
   知识层级：5 层

📋 任务：生成完整的 Agent 开发学习路线

🔍 主 Agent 分解任务
   → 分配给 5 个子 Agent

🤖 子 Agent 执行任务
   ✅ theory_worker: 4 个主题，370 小时
   ✅ tech_stack_worker: 3 个主题，210 小时
   ✅ core_skill_worker: 4 个主题，225 小时
   ✅ engineering_worker: 3 个主题，215 小时
   ✅ interview_worker: 3 个主题，235 小时

📥 主 Agent 汇总结果
   ✅ 汇总完成：5 层，总计 1255 小时

✅ 任务完成！
```

### 输出数据

**总结文件：** `data/knowledge/autogen_summary.json`

```json
{
  "generated_at": "2026-03-29T21:58:00",
  "architecture": "master-worker",
  "coordinator": "master_agent",
  "total_layers": 5,
  "workers": [
    "theory_worker",
    "tech_stack_worker",
    "core_skill_worker",
    "engineering_worker",
    "interview_worker"
  ],
  "total_hours": 1255
}
```

---

## 🏗️ 架构对比

### 重构前

```
单一生成器 (generator.py)
    ↓
生成所有层级数据
```

### 重构后

```
Master Agent
    ↓
┌───┴───┬───┴───┬───┴───┬───┴───┐
Worker1 Worker2 Worker3 Worker4 Worker5
    ↓       ↓       ↓       ↓       ↓
  层 1    层 2    层 3    层 4    层 5
    ↓       ↓       ↓       ↓       ↓
    └───────┴───┬───┴───────┘
                ↓
          Master 汇总
```

---

## ✅ 架构优势

| 优势 | 说明 |
|------|------|
| **职责清晰** | 每个 Agent 专注一个层级 |
| **并行执行** | 5 个子 Agent 可同时工作 |
| **易于扩展** | 添加新层级只需新增 Worker |
| **容错性强** | 单个 Agent 失败不影响整体 |
| **可观测性** | 每个 Agent 独立日志 |

---

## 🎯 大模型配置

### 使用 DashScope/Qwen

```yaml
llm:
  provider: "dashscope"
  model: "qwen-plus"
  base_url: "https://dashscope.aliyuncs.com/compatible-mode/v1"
  api_key_env: "DASHSCOPE_API_KEY"
  temperature: 0.7
  max_tokens: 4000
```

### 环境变量

```bash
export DASHSCOPE_API_KEY="sk-xxx"
export DASHSCOPE_MODEL="qwen-plus"
```

---

## 📈 性能指标

| 指标 | 数值 |
|------|------|
| **Agent 总数** | 6 个 (1 主 +5 子) |
| **知识层级** | 5 层 |
| **总主题数** | 17 个 |
| **预计时长** | 1255 小时 |
| **建议周期** | 3-4 个月 |

---

## 🔧 扩展方向

### 短期扩展

- [ ] 添加真实 AutoGen API 调用
- [ ] 实现 Agent 间对话
- [ ] 添加任务优先级
- [ ] 实现结果验证

### 长期扩展

- [ ] 添加更多 Worker Agent
- [ ] 实现动态任务分配
- [ ] 添加 Agent 性能监控
- [ ] 实现知识更新机制

---

*AutoGen 主从架构重构完成* 🤖✨
